#include <stdint.h>
#include <stdbool.h>
#include <math.h>

void k_cell_integral(double *__restrict__ A, double const *__restrict__ coords_0)
{
  double t0;
  double t1;
  double t10[2] = { 0.21132486540518713, 0.7886751345948128 };
  double t100;
  double t101;
  double t102;
  double t103;
  double t104[2 * 2];
  double t105[2 * 2];
  double t106[2 * 2];
  double t107[2 * 2];
  double t108[2 * 2];
  double t109[2 * 2];
  double t11;
  double t110[2 * 2];
  double t111[2 * 2];
  double t112[2 * 2 * 2];
  double t113[2 * 2 * 2];
  double t114[2 * 2 * 2];
  double t115[2 * 2 * 2];
  double t116[2 * 2];
  double t117[2 * 2];
  double t118[2 * 2];
  double t119[2 * 2];
  double t12[2] = { 0.7886751345948128, 0.21132486540518713 };
  double t13[2];
  double t14[2];
  double t15;
  double t16;
  double t17;
  double t18;
  double t19[2 * 2];
  double t2;
  double t20[2 * 2];
  double t21[2 * 2];
  double t22;
  double t23[2 * 2];
  double t24[2 * 2];
  double t25;
  double t26;
  double t27[2];
  double t28;
  double t29;
  double t3;
  double t30;
  double t31[2];
  double t32;
  double t33[2];
  double t34;
  double t35[2 * 2];
  double t36[2];
  double t37[2] = { -1.0, 1.0 };
  double t38[2 * 2] = { 0.7886751345948128, 0.21132486540518713, 0.21132486540518713, 0.7886751345948128 };
  double t39[2];
  double t4;
  double t40;
  double t41;
  double t42;
  double t43;
  double t44[2 * 2];
  double t45[2 * 2];
  double t46[2 * 2];
  double t47[2 * 2];
  double t48;
  double t49;
  double t5;
  double t50;
  double t51;
  double t52;
  double t53;
  double t54;
  double t55;
  double t56;
  double t57;
  double t58;
  double t59;
  double t6[2] = { 0.4999999999999999, 0.4999999999999999 };
  double t60;
  double t61;
  double t62;
  double t63;
  double t64;
  double t65;
  double t66;
  double t67;
  double t68;
  double t69;
  double t7;
  double t70;
  double t71;
  double t72;
  double t73;
  double t74;
  double t75;
  double t76;
  double t77;
  double t78;
  double t79;
  double t8;
  double t80;
  double t81;
  double t82;
  double t83;
  double t84;
  double t85;
  double t86;
  double t87;
  double t88[2];
  double t89[2];
  double t9;
  double t90[2];
  double t91[2];
  double t92[2];
  double t93[2];
  double t94[2];
  double t95[2];
  double t96[2 * 2];
  double t97[2 * 2];
  double t98[2 * 2];
  double t99[2 * 2];

  t0 = -1.0 * coords_0[5] + coords_0[7];
  t1 = -1.0 * coords_0[1];
  t2 = t1 + coords_0[3];
  t3 = -1.0 * coords_0[4] + coords_0[6];
  t4 = -1.0 * coords_0[0];
  t5 = t4 + coords_0[2];
  t7 = -1.0 * coords_0[2] + coords_0[6];
  t8 = t4 + coords_0[4];
  t9 = -1.0 * coords_0[3] + coords_0[7];
  t11 = t1 + coords_0[5];
  for (int32_t ip1 = 0; ip1 <= 1; ++ip1)
  {
    t36[ip1] = (double) (0.0);
    t33[ip1] = (double) (0.0);
    t31[ip1] = (double) (0.0);
    t27[ip1] = (double) (0.0);
    t13[ip1] = t12[ip1] * t11 + t10[ip1] * t9;
    t14[ip1] = t12[ip1] * t8 + t10[ip1] * t7;
  }
  for (int32_t ip0 = 0; ip0 <= 1; ++ip0)
  {
    t15 = t12[ip0] * t5 + t10[ip0] * t3;
    t16 = -1.0 * t15;
    t17 = t12[ip0] * t2 + t10[ip0] * t0;
    for (int32_t ip1_0 = 0; ip1_0 <= 1; ++ip1_0)
    {
      t18 = t14[ip1_0] * t17 + -1.0 * t15 * t13[ip1_0];
      t19[2 * ip0 + ip1_0] = t6[ip0] * t6[ip1_0] * fabs(t18);
      t20[2 * ip0 + ip1_0] = 1.0 / t18;
      t21[2 * ip0 + ip1_0] = t17 * t20[2 * ip0 + ip1_0];
      t22 = t21[2 * ip0 + ip1_0] * t21[2 * ip0 + ip1_0];
      t23[2 * ip0 + ip1_0] = t21[2 * ip0 + ip1_0] + t21[2 * ip0 + ip1_0];
      t24[2 * ip0 + ip1_0] = t16 * t20[2 * ip0 + ip1_0];
      t25 = t24[2 * ip0 + ip1_0] * t24[2 * ip0 + ip1_0];
      t26 = 0.25 * t25;
      t27[ip1_0] = t27[ip1_0] + t19[2 * ip0 + ip1_0] * (t22 + 0.25 * t23[2 * ip0 + ip1_0] * t23[2 * ip0 + ip1_0] + t26 + t26);
      t28 = t24[2 * ip0 + ip1_0] * t21[2 * ip0 + ip1_0];
      t29 = t21[2 * ip0 + ip1_0] * t24[2 * ip0 + ip1_0];
      t30 = 0.25 * t29;
      t31[ip1_0] = t31[ip1_0] + t19[2 * ip0 + ip1_0] * (t28 + t30 + t30);
      t32 = 0.25 * t28;
      t33[ip1_0] = t33[ip1_0] + t19[2 * ip0 + ip1_0] * (t29 + t32 + t32);
      t34 = 0.25 * t22;
      t35[2 * ip0 + ip1_0] = t24[2 * ip0 + ip1_0] + t24[2 * ip0 + ip1_0];
      t36[ip1_0] = t36[ip1_0] + t19[2 * ip0 + ip1_0] * (t25 + t34 + t34 + 0.25 * t35[2 * ip0 + ip1_0] * t35[2 * ip0 + ip1_0]);
    }
  }
  for (int32_t j1 = 0; j1 <= 1; ++j1)
  {
    for (int32_t k1 = 0; k1 <= 1; ++k1)
    {
      t47[2 * j1 + k1] = (double) (0.0);
      t46[2 * j1 + k1] = (double) (0.0);
      t45[2 * j1 + k1] = (double) (0.0);
      t44[2 * j1 + k1] = (double) (0.0);
    }
    for (int32_t k0 = 0; k0 <= 1; ++k0)
    {
      t99[2 * j1 + k0] = (double) (0.0);
      t98[2 * j1 + k0] = (double) (0.0);
      t97[2 * j1 + k0] = (double) (0.0);
      t96[2 * j1 + k0] = (double) (0.0);
    }
  }
  for (int32_t j0 = 0; j0 <= 1; ++j0)
  {
    for (int32_t k1_0 = 0; k1_0 <= 1; ++k1_0)
    {
      t107[2 * j0 + k1_0] = (double) (0.0);
      t106[2 * j0 + k1_0] = (double) (0.0);
      t105[2 * j0 + k1_0] = (double) (0.0);
      t104[2 * j0 + k1_0] = (double) (0.0);
    }
    for (int32_t k0_0 = 0; k0_0 <= 1; ++k0_0)
    {
      t111[2 * j0 + k0_0] = (double) (0.0);
      t110[2 * j0 + k0_0] = (double) (0.0);
      t109[2 * j0 + k0_0] = (double) (0.0);
      t108[2 * j0 + k0_0] = (double) (0.0);
    }
  }
  for (int32_t ip1_1 = 0; ip1_1 <= 1; ++ip1_1)
  {
    t39[ip1_1] = -1.0 * t13[ip1_1];
    for (int32_t j1_0 = 0; j1_0 <= 1; ++j1_0)
    {
      t40 = t38[ip1_1 + 2 * j1_0] * t27[ip1_1];
      t41 = t38[ip1_1 + 2 * j1_0] * t31[ip1_1];
      t42 = t38[ip1_1 + 2 * j1_0] * t33[ip1_1];
      t43 = t38[ip1_1 + 2 * j1_0] * t36[ip1_1];
      for (int32_t k1_1 = 0; k1_1 <= 1; ++k1_1)
      {
        t44[2 * j1_0 + k1_1] = t44[2 * j1_0 + k1_1] + t38[ip1_1 + 2 * k1_1] * t43;
        t45[2 * j1_0 + k1_1] = t45[2 * j1_0 + k1_1] + t38[ip1_1 + 2 * k1_1] * t42;
        t46[2 * j1_0 + k1_1] = t46[2 * j1_0 + k1_1] + t38[ip1_1 + 2 * k1_1] * t41;
        t47[2 * j1_0 + k1_1] = t47[2 * j1_0 + k1_1] + t38[ip1_1 + 2 * k1_1] * t40;
      }
    }
  }
  for (int32_t ip0_0 = 0; ip0_0 <= 1; ++ip0_0)
  {
    t63 = (double) (0.0);
    t60 = (double) (0.0);
    t58 = (double) (0.0);
    t54 = (double) (0.0);
    for (int32_t k1_2 = 0; k1_2 <= 1; ++k1_2)
    {
      t91[k1_2] = (double) (0.0);
      t90[k1_2] = (double) (0.0);
      t89[k1_2] = (double) (0.0);
      t88[k1_2] = (double) (0.0);
    }
    for (int32_t j1_1 = 0; j1_1 <= 1; ++j1_1)
    {
      t95[j1_1] = (double) (0.0);
      t94[j1_1] = (double) (0.0);
      t93[j1_1] = (double) (0.0);
      t92[j1_1] = (double) (0.0);
    }
    for (int32_t ip1_2 = 0; ip1_2 <= 1; ++ip1_2)
    {
      t48 = t39[ip1_2] * t20[2 * ip0_0 + ip1_2];
      t49 = t48 * t48;
      t50 = t48 + t48;
      t51 = t14[ip1_2] * t20[2 * ip0_0 + ip1_2];
      t52 = t51 * t51;
      t53 = 0.25 * t52;
      t54 = t54 + t19[2 * ip0_0 + ip1_2] * (t49 + 0.25 * t50 * t50 + t53 + t53);
      t55 = t51 * t48;
      t56 = t48 * t51;
      t57 = 0.25 * t56;
      t58 = t58 + t19[2 * ip0_0 + ip1_2] * (t55 + t57 + t57);
      t59 = 0.25 * t55;
      t60 = t60 + t19[2 * ip0_0 + ip1_2] * (t56 + t59 + t59);
      t61 = 0.25 * t49;
      t62 = t51 + t51;
      t63 = t63 + t19[2 * ip0_0 + ip1_2] * (t52 + t61 + t61 + 0.25 * t62 * t62);
      t64 = t48 * t21[2 * ip0_0 + ip1_2];
      t65 = t51 * t24[2 * ip0_0 + ip1_2];
      t66 = 0.25 * t65;
      t67 = t19[2 * ip0_0 + ip1_2] * (t64 + 0.25 * t50 * t23[2 * ip0_0 + ip1_2] + t66 + t66);
      t68 = t51 * t21[2 * ip0_0 + ip1_2];
      t69 = t48 * t24[2 * ip0_0 + ip1_2];
      t70 = 0.25 * t69;
      t71 = t19[2 * ip0_0 + ip1_2] * (t68 + t70 + t70);
      t72 = 0.25 * t68;
      t73 = t19[2 * ip0_0 + ip1_2] * (t69 + t72 + t72);
      t74 = 0.25 * t64;
      t75 = t19[2 * ip0_0 + ip1_2] * (t65 + t74 + t74 + 0.25 * t62 * t35[2 * ip0_0 + ip1_2]);
      t76 = t21[2 * ip0_0 + ip1_2] * t48;
      t77 = t24[2 * ip0_0 + ip1_2] * t51;
      t78 = 0.25 * t77;
      t79 = t19[2 * ip0_0 + ip1_2] * (t76 + 0.25 * t23[2 * ip0_0 + ip1_2] * t50 + t78 + t78);
      t80 = t24[2 * ip0_0 + ip1_2] * t48;
      t81 = t21[2 * ip0_0 + ip1_2] * t51;
      t82 = 0.25 * t81;
      t83 = t19[2 * ip0_0 + ip1_2] * (t80 + t82 + t82);
      t84 = 0.25 * t80;
      t85 = t19[2 * ip0_0 + ip1_2] * (t81 + t84 + t84);
      t86 = 0.25 * t76;
      t87 = t19[2 * ip0_0 + ip1_2] * (t77 + t86 + t86 + 0.25 * t35[2 * ip0_0 + ip1_2] * t62);
      for (int32_t k1_3 = 0; k1_3 <= 1; ++k1_3)
      {
        t88[k1_3] = t88[k1_3] + t38[ip1_2 + 2 * k1_3] * t87;
        t89[k1_3] = t89[k1_3] + t38[ip1_2 + 2 * k1_3] * t85;
        t90[k1_3] = t90[k1_3] + t38[ip1_2 + 2 * k1_3] * t83;
        t91[k1_3] = t91[k1_3] + t38[ip1_2 + 2 * k1_3] * t79;
      }
      for (int32_t j1_2 = 0; j1_2 <= 1; ++j1_2)
      {
        t92[j1_2] = t92[j1_2] + t38[ip1_2 + 2 * j1_2] * t75;
        t93[j1_2] = t93[j1_2] + t38[ip1_2 + 2 * j1_2] * t73;
        t94[j1_2] = t94[j1_2] + t38[ip1_2 + 2 * j1_2] * t71;
        t95[j1_2] = t95[j1_2] + t38[ip1_2 + 2 * j1_2] * t67;
      }
    }
    for (int32_t j1_3 = 0; j1_3 <= 1; ++j1_3)
      for (int32_t k0_1 = 0; k0_1 <= 1; ++k0_1)
      {
        t96[2 * j1_3 + k0_1] = t96[2 * j1_3 + k0_1] + t38[ip0_0 + 2 * k0_1] * t92[j1_3];
        t97[2 * j1_3 + k0_1] = t97[2 * j1_3 + k0_1] + t38[ip0_0 + 2 * k0_1] * t93[j1_3];
        t98[2 * j1_3 + k0_1] = t98[2 * j1_3 + k0_1] + t38[ip0_0 + 2 * k0_1] * t94[j1_3];
        t99[2 * j1_3 + k0_1] = t99[2 * j1_3 + k0_1] + t38[ip0_0 + 2 * k0_1] * t95[j1_3];
      }
    for (int32_t j0_0 = 0; j0_0 <= 1; ++j0_0)
    {
      t100 = t38[ip0_0 + 2 * j0_0] * t54;
      t101 = t38[ip0_0 + 2 * j0_0] * t58;
      t102 = t38[ip0_0 + 2 * j0_0] * t60;
      t103 = t38[ip0_0 + 2 * j0_0] * t63;
      for (int32_t k1_4 = 0; k1_4 <= 1; ++k1_4)
      {
        t104[2 * j0_0 + k1_4] = t104[2 * j0_0 + k1_4] + t38[ip0_0 + 2 * j0_0] * t88[k1_4];
        t105[2 * j0_0 + k1_4] = t105[2 * j0_0 + k1_4] + t38[ip0_0 + 2 * j0_0] * t89[k1_4];
        t106[2 * j0_0 + k1_4] = t106[2 * j0_0 + k1_4] + t38[ip0_0 + 2 * j0_0] * t90[k1_4];
        t107[2 * j0_0 + k1_4] = t107[2 * j0_0 + k1_4] + t38[ip0_0 + 2 * j0_0] * t91[k1_4];
      }
      for (int32_t k0_2 = 0; k0_2 <= 1; ++k0_2)
      {
        t108[2 * j0_0 + k0_2] = t108[2 * j0_0 + k0_2] + t38[ip0_0 + 2 * k0_2] * t103;
        t109[2 * j0_0 + k0_2] = t109[2 * j0_0 + k0_2] + t38[ip0_0 + 2 * k0_2] * t102;
        t110[2 * j0_0 + k0_2] = t110[2 * j0_0 + k0_2] + t38[ip0_0 + 2 * k0_2] * t101;
        t111[2 * j0_0 + k0_2] = t111[2 * j0_0 + k0_2] + t38[ip0_0 + 2 * k0_2] * t100;
      }
    }
  }
  for (int32_t j1_4 = 0; j1_4 <= 1; ++j1_4)
    for (int32_t k0_3 = 0; k0_3 <= 1; ++k0_3)
      for (int32_t k1_5 = 0; k1_5 <= 1; ++k1_5)
      {
        t112[4 * j1_4 + 2 * k0_3 + k1_5] = t37[k0_3] * t44[2 * j1_4 + k1_5] + t37[k1_5] * t96[2 * j1_4 + k0_3];
        t113[4 * j1_4 + 2 * k0_3 + k1_5] = t37[k0_3] * t45[2 * j1_4 + k1_5] + t37[k1_5] * t97[2 * j1_4 + k0_3];
        t114[4 * j1_4 + 2 * k0_3 + k1_5] = t37[k0_3] * t46[2 * j1_4 + k1_5] + t37[k1_5] * t98[2 * j1_4 + k0_3];
        t115[4 * j1_4 + 2 * k0_3 + k1_5] = t37[k0_3] * t47[2 * j1_4 + k1_5] + t37[k1_5] * t99[2 * j1_4 + k0_3];
      }
  for (int32_t j0_1 = 0; j0_1 <= 1; ++j0_1)
  {
    for (int32_t k0_4 = 0; k0_4 <= 1; ++k0_4)
      for (int32_t k1_6 = 0; k1_6 <= 1; ++k1_6)
      {
        t116[2 * k0_4 + k1_6] = t37[k0_4] * t104[2 * j0_1 + k1_6] + t37[k1_6] * t108[2 * j0_1 + k0_4];
        t117[2 * k0_4 + k1_6] = t37[k0_4] * t105[2 * j0_1 + k1_6] + t37[k1_6] * t109[2 * j0_1 + k0_4];
        t118[2 * k0_4 + k1_6] = t37[k0_4] * t106[2 * j0_1 + k1_6] + t37[k1_6] * t110[2 * j0_1 + k0_4];
        t119[2 * k0_4 + k1_6] = t37[k0_4] * t107[2 * j0_1 + k1_6] + t37[k1_6] * t111[2 * j0_1 + k0_4];
      }
    for (int32_t j1_5 = 0; j1_5 <= 1; ++j1_5)
      for (int32_t k0_5 = 0; k0_5 <= 1; ++k0_5)
        for (int32_t k1_7 = 0; k1_7 <= 1; ++k1_7)
        {
          A[32 * j0_1 + 16 * j1_5 + 4 * k0_5 + 2 * k1_7] = A[32 * j0_1 + 16 * j1_5 + 4 * k0_5 + 2 * k1_7] + t115[4 * j1_5 + 2 * k0_5 + k1_7] * t37[j0_1] + t119[2 * k0_5 + k1_7] * t37[j1_5];
          A[1 + 32 * j0_1 + 16 * j1_5 + 4 * k0_5 + 2 * k1_7] = A[1 + 32 * j0_1 + 16 * j1_5 + 4 * k0_5 + 2 * k1_7] + t114[4 * j1_5 + 2 * k0_5 + k1_7] * t37[j0_1] + t118[2 * k0_5 + k1_7] * t37[j1_5];
          A[8 + 32 * j0_1 + 16 * j1_5 + 4 * k0_5 + 2 * k1_7] = A[8 + 32 * j0_1 + 16 * j1_5 + 4 * k0_5 + 2 * k1_7] + t113[4 * j1_5 + 2 * k0_5 + k1_7] * t37[j0_1] + t117[2 * k0_5 + k1_7] * t37[j1_5];
          A[9 + 32 * j0_1 + 16 * j1_5 + 4 * k0_5 + 2 * k1_7] = A[9 + 32 * j0_1 + 16 * j1_5 + 4 * k0_5 + 2 * k1_7] + t112[4 * j1_5 + 2 * k0_5 + k1_7] * t37[j0_1] + t116[2 * k0_5 + k1_7] * t37[j1_5];
        }
  }

}