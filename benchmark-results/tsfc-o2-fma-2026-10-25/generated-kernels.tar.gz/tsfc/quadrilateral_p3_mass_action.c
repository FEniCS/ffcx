#include <stdint.h>
#include <stdbool.h>
#include <math.h>

void k_cell_integral(double *__restrict__ A, double const *__restrict__ coords_0, double const *__restrict__ w_0)
{
  double t0;
  double t1;
  double t10[4] = { 0.06943184420297377, 0.3300094782075718, 0.6699905217924281, 0.9305681557970262 };
  double t11;
  double t12[4] = { 0.9305681557970262, 0.6699905217924282, 0.33000947820757176, 0.06943184420297377 };
  double t13[4 * 4] = { 0.6299431661034453, -0.07069479527385578, -0.034821317229834114, 0.04700151782881608, 0.47255874711381834, 0.9729761862582632, 0.13253992624542665, -0.14950343104607963, -0.14950343104607966, 0.13253992624542685, 0.9729761862582631, 0.4725587471138183, 0.04700151782881609, -0.034821317229834156, -0.07069479527385569, 0.6299431661034451 };
  double t14[4];
  double t15[4];
  double t16[4];
  double t17;
  double t18;
  double t19;
  double t2;
  double t20;
  double t21[4];
  double t3;
  double t4;
  double t5;
  double t6[4] = { 0.17392742256872712, 0.32607257743127305, 0.32607257743127305, 0.17392742256872712 };
  double t7;
  double t8;
  double t9;

  t0 = -1.0 * coords_0[5] + coords_0[7];
  t1 = -1.0 * coords_0[1];
  t2 = t1 + coords_0[3];
  t3 = -1.0 * coords_0[4] + coords_0[6];
  t4 = -1.0 * coords_0[0];
  t5 = t4 + coords_0[2];
  t7 = -1.0 * coords_0[2] + coords_0[6];
  t8 = t4 + coords_0[4];
  t9 = -1.0 * coords_0[3] + coords_0[7];
  t11 = t1 + coords_0[5];
  for (int32_t ip1 = 0; ip1 <= 3; ++ip1)
  {
    t14[ip1] = t12[ip1] * t11 + t10[ip1] * t9;
    t15[ip1] = t12[ip1] * t8 + t10[ip1] * t7;
  }
  for (int32_t ip0 = 0; ip0 <= 3; ++ip0)
  {
    for (int32_t i = 0; i <= 3; ++i)
    {
      t16[i] = (double) (0.0);
      for (int32_t i_0 = 0; i_0 <= 3; ++i_0)
        t16[i] = t16[i] + t13[ip0 + 4 * i_0] * w_0[i + 4 * i_0];
    }
    t17 = t12[ip0] * t5 + t10[ip0] * t3;
    t18 = t12[ip0] * t2 + t10[ip0] * t0;
    for (int32_t j1 = 0; j1 <= 3; ++j1)
      t21[j1] = (double) (0.0);
    for (int32_t ip1_0 = 0; ip1_0 <= 3; ++ip1_0)
    {
      t19 = (double) (0.0);
      for (int32_t i_1 = 0; i_1 <= 3; ++i_1)
        t19 = t19 + t13[ip1_0 + 4 * i_1] * t16[i_1];
      t20 = t6[ip0] * t6[ip1_0] * fabs(t15[ip1_0] * t18 + -1.0 * t17 * t14[ip1_0]) * t19;
      for (int32_t j1_0 = 0; j1_0 <= 3; ++j1_0)
        t21[j1_0] = t21[j1_0] + t13[ip1_0 + 4 * j1_0] * t20;
    }
    for (int32_t j0 = 0; j0 <= 3; ++j0)
      for (int32_t j1_1 = 0; j1_1 <= 3; ++j1_1)
        A[4 * j0 + j1_1] = A[4 * j0 + j1_1] + t13[ip0 + 4 * j0] * t21[j1_1];
  }

}