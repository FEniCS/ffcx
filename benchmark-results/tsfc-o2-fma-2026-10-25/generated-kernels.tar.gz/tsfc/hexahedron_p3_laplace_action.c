#include <stdint.h>
#include <stdbool.h>
#include <math.h>

void k_cell_integral(double *__restrict__ A, double const *__restrict__ coords_0, double const *__restrict__ w_0)
{
  double t0;
  double t1;
  double t10;
  double t100;
  double t101;
  double t102;
  double t103;
  double t104;
  double t105;
  double t106;
  double t107;
  double t108;
  double t109;
  double t11;
  double t110;
  double t111;
  double t112;
  double t113[4];
  double t114[4];
  double t115[4];
  double t116[4 * 4];
  double t117[4 * 4];
  double t12;
  double t13;
  double t14;
  double t15;
  double t16;
  double t17;
  double t18;
  double t19;
  double t2;
  double t20;
  double t21;
  double t22;
  double t23;
  double t24;
  double t25;
  double t26;
  double t27;
  double t28;
  double t29;
  double t3;
  double t30;
  double t31;
  double t32;
  double t33;
  double t34;
  double t35;
  double t36;
  double t37;
  double t38;
  double t39;
  double t4;
  double t40;
  double t41;
  double t42;
  double t43;
  double t44;
  double t45;
  double t46;
  double t47;
  double t48[4] = { 0.9305681557970262, 0.6699905217924282, 0.33000947820757176, 0.06943184420297377 };
  double t49[4] = { 0.06943184420297377, 0.3300094782075718, 0.6699905217924281, 0.9305681557970262 };
  double t5;
  double t50[4] = { 0.17392742256872712, 0.32607257743127305, 0.32607257743127305, 0.17392742256872712 };
  double t51[4 * 4] = { -4.683674830781916, -1.0334042714510712, 0.6665009464732109, -0.37799327281165257, 5.575889781074175, -0.9759049806270532, -2.6758101985513343, 1.2702082231039116, -1.2702082231039118, 2.675810198551335, 0.975904980627052, -5.575889781074173, 0.3779932728116526, -0.666500946473211, 1.0334042714510716, 4.683674830781914 };
  double t52[4 * 4] = { 0.6299431661034453, -0.07069479527385578, -0.034821317229834114, 0.04700151782881608, 0.47255874711381834, 0.9729761862582632, 0.13253992624542665, -0.14950343104607963, -0.14950343104607966, 0.13253992624542685, 0.9729761862582631, 0.4725587471138183, 0.04700151782881609, -0.034821317229834156, -0.07069479527385569, 0.6299431661034451 };
  double t53;
  double t54;
  double t55;
  double t56;
  double t57;
  double t58;
  double t59[4 * 4];
  double t6;
  double t60[4 * 4];
  double t61[4 * 4];
  double t62[4 * 4];
  double t63[4 * 4];
  double t64;
  double t65;
  double t66;
  double t67;
  double t68;
  double t69;
  double t7;
  double t70;
  double t71;
  double t72;
  double t73;
  double t74;
  double t75;
  double t76[4];
  double t77[4];
  double t78[4];
  double t79[4];
  double t8;
  double t80[4];
  double t81[4];
  double t82[4];
  double t83;
  double t84;
  double t85;
  double t86;
  double t87;
  double t88;
  double t89;
  double t9;
  double t90;
  double t91;
  double t92;
  double t93;
  double t94;
  double t95;
  double t96;
  double t97;
  double t98;
  double t99;

  t0 = -1.0 * coords_0[12];
  t1 = t0 + coords_0[18];
  t2 = -1.0 * coords_0[0];
  t3 = t2 + coords_0[6];
  t4 = -1.0 * coords_0[15] + coords_0[21];
  t5 = -1.0 * coords_0[3];
  t6 = t5 + coords_0[9];
  t7 = -1.0 * coords_0[14];
  t8 = t7 + coords_0[20];
  t9 = -1.0 * coords_0[2];
  t10 = t9 + coords_0[8];
  t11 = -1.0 * coords_0[17] + coords_0[23];
  t12 = -1.0 * coords_0[5];
  t13 = t12 + coords_0[11];
  t14 = -1.0 * coords_0[13];
  t15 = t14 + coords_0[19];
  t16 = -1.0 * coords_0[1];
  t17 = t16 + coords_0[7];
  t18 = -1.0 * coords_0[16] + coords_0[22];
  t19 = -1.0 * coords_0[4];
  t20 = t19 + coords_0[10];
  t21 = t0 + coords_0[15];
  t22 = t2 + coords_0[3];
  t23 = -1.0 * coords_0[18] + coords_0[21];
  t24 = -1.0 * coords_0[6];
  t25 = t24 + coords_0[9];
  t26 = t7 + coords_0[17];
  t27 = t9 + coords_0[5];
  t28 = -1.0 * coords_0[20] + coords_0[23];
  t29 = -1.0 * coords_0[8];
  t30 = t29 + coords_0[11];
  t31 = t14 + coords_0[16];
  t32 = t16 + coords_0[4];
  t33 = -1.0 * coords_0[19] + coords_0[22];
  t34 = -1.0 * coords_0[7];
  t35 = t34 + coords_0[10];
  t36 = t29 + coords_0[20];
  t37 = t9 + coords_0[14];
  t38 = -1.0 * coords_0[11] + coords_0[23];
  t39 = t12 + coords_0[17];
  t40 = t34 + coords_0[19];
  t41 = t16 + coords_0[13];
  t42 = -1.0 * coords_0[10] + coords_0[22];
  t43 = t19 + coords_0[16];
  t44 = t24 + coords_0[18];
  t45 = t2 + coords_0[12];
  t46 = -1.0 * coords_0[9] + coords_0[21];
  t47 = t5 + coords_0[15];
  for (int32_t ip1 = 0; ip1 <= 3; ++ip1)
  {
    t53 = t48[ip1] * t47 + t49[ip1] * t46;
    t54 = t48[ip1] * t45 + t49[ip1] * t44;
    t55 = t48[ip1] * t43 + t49[ip1] * t42;
    t56 = t48[ip1] * t41 + t49[ip1] * t40;
    t57 = t48[ip1] * t39 + t49[ip1] * t38;
    t58 = t48[ip1] * t37 + t49[ip1] * t36;
    for (int32_t ip2 = 0; ip2 <= 3; ++ip2)
    {
      t59[4 * ip1 + ip2] = t48[ip2] * t58 + t49[ip2] * t57;
      t60[4 * ip1 + ip2] = t48[ip2] * t56 + t49[ip2] * t55;
      t61[4 * ip1 + ip2] = t48[ip2] * t54 + t49[ip2] * t53;
    }
  }
  for (int32_t ip0 = 0; ip0 <= 3; ++ip0)
  {
    for (int32_t i = 0; i <= 3; ++i)
      for (int32_t i_0 = 0; i_0 <= 3; ++i_0)
      {
        t63[4 * i + i_0] = (double) (0.0);
        t62[4 * i + i_0] = (double) (0.0);
        for (int32_t i_1 = 0; i_1 <= 3; ++i_1)
        {
          t62[4 * i + i_0] = t62[4 * i + i_0] + t52[ip0 + 4 * i_1] * w_0[i + 4 * i_0 + 16 * i_1];
          t63[4 * i + i_0] = t63[4 * i + i_0] + t51[ip0 + 4 * i_1] * w_0[i + 4 * i_0 + 16 * i_1];
        }
      }
    t64 = t48[ip0] * t35 + t49[ip0] * t33;
    t65 = t48[ip0] * t32 + t49[ip0] * t31;
    t66 = t48[ip0] * t30 + t49[ip0] * t28;
    t67 = t48[ip0] * t27 + t49[ip0] * t26;
    t68 = t48[ip0] * t25 + t49[ip0] * t23;
    t69 = t48[ip0] * t22 + t49[ip0] * t21;
    t70 = t48[ip0] * t20 + t49[ip0] * t18;
    t71 = t48[ip0] * t17 + t49[ip0] * t15;
    t72 = t48[ip0] * t13 + t49[ip0] * t11;
    t73 = t48[ip0] * t10 + t49[ip0] * t8;
    t74 = t48[ip0] * t6 + t49[ip0] * t4;
    t75 = t48[ip0] * t3 + t49[ip0] * t1;
    for (int32_t ip2_0 = 0; ip2_0 <= 3; ++ip2_0)
    {
      t76[ip2_0] = t48[ip2_0] * t75 + t49[ip2_0] * t74;
      t77[ip2_0] = -1.0 * t76[ip2_0];
      t78[ip2_0] = t48[ip2_0] * t73 + t49[ip2_0] * t72;
      t79[ip2_0] = t48[ip2_0] * t71 + t49[ip2_0] * t70;
    }
    for (int32_t j1 = 0; j1 <= 3; ++j1)
      for (int32_t j2 = 0; j2 <= 3; ++j2)
      {
        t117[4 * j1 + j2] = (double) (0.0);
        t116[4 * j1 + j2] = (double) (0.0);
      }
    for (int32_t ip1_0 = 0; ip1_0 <= 3; ++ip1_0)
    {
      for (int32_t i_2 = 0; i_2 <= 3; ++i_2)
      {
        t82[i_2] = (double) (0.0);
        t81[i_2] = (double) (0.0);
        t80[i_2] = (double) (0.0);
        for (int32_t i_3 = 0; i_3 <= 3; ++i_3)
        {
          t80[i_2] = t80[i_2] + t52[ip1_0 + 4 * i_3] * t62[4 * i_2 + i_3];
          t81[i_2] = t81[i_2] + t51[ip1_0 + 4 * i_3] * t62[4 * i_2 + i_3];
          t82[i_2] = t82[i_2] + t52[ip1_0 + 4 * i_3] * t63[4 * i_2 + i_3];
        }
      }
      t83 = t48[ip1_0] * t69 + t49[ip1_0] * t68;
      t84 = -1.0 * t83;
      t85 = t48[ip1_0] * t67 + t49[ip1_0] * t66;
      t86 = -1.0 * t85;
      t87 = t48[ip1_0] * t65 + t49[ip1_0] * t64;
      t88 = t50[ip0] * t50[ip1_0];
      for (int32_t j2_0 = 0; j2_0 <= 3; ++j2_0)
      {
        t115[j2_0] = (double) (0.0);
        t114[j2_0] = (double) (0.0);
        t113[j2_0] = (double) (0.0);
      }
      for (int32_t ip2_1 = 0; ip2_1 <= 3; ++ip2_1)
      {
        t91 = (double) (0.0);
        t90 = (double) (0.0);
        t89 = (double) (0.0);
        for (int32_t i_4 = 0; i_4 <= 3; ++i_4)
        {
          t89 = t89 + t51[ip2_1 + 4 * i_4] * t80[i_4];
          t90 = t90 + t52[ip2_1 + 4 * i_4] * t81[i_4];
          t91 = t91 + t52[ip2_1 + 4 * i_4] * t82[i_4];
        }
        t92 = t79[ip2_1] * t85 + -1.0 * t87 * t78[ip2_1];
        t93 = t87 * t59[4 * ip1_0 + ip2_1];
        t94 = t60[4 * ip1_0 + ip2_1] * t78[ip2_1] + -1.0 * t79[ip2_1] * t59[4 * ip1_0 + ip2_1];
        t95 = t61[4 * ip1_0 + ip2_1] * t92 + (t60[4 * ip1_0 + ip2_1] * t85 + -1.0 * t93) * t77[ip2_1] + t83 * t94;
        t96 = t88 * t50[ip2_1] * fabs(t95);
        t97 = 1.0 / t95;
        t98 = t92 * t97;
        t99 = (t93 + t60[4 * ip1_0 + ip2_1] * t86) * t97;
        t100 = t94 * t97;
        t101 = t98 * t91 + t99 * t90 + t100 * t89;
        t102 = (t83 * t78[ip2_1] + t85 * t77[ip2_1]) * t97;
        t103 = (t61[4 * ip1_0 + ip2_1] * t85 + t59[4 * ip1_0 + ip2_1] * t84) * t97;
        t104 = (t76[ip2_1] * t59[4 * ip1_0 + ip2_1] + -1.0 * t61[4 * ip1_0 + ip2_1] * t78[ip2_1]) * t97;
        t105 = t102 * t91 + t103 * t90 + t104 * t89;
        t106 = (t76[ip2_1] * t87 + -1.0 * t83 * t79[ip2_1]) * t97;
        t107 = (t83 * t60[4 * ip1_0 + ip2_1] + -1.0 * t61[4 * ip1_0 + ip2_1] * t87) * t97;
        t108 = (t61[4 * ip1_0 + ip2_1] * t79[ip2_1] + -1.0 * t76[ip2_1] * t60[4 * ip1_0 + ip2_1]) * t97;
        t109 = t106 * t91 + t107 * t90 + t108 * t89;
        t110 = t96 * (t101 * t100 + t105 * t104 + t109 * t108);
        t111 = t96 * (t101 * t99 + t105 * t103 + t109 * t107);
        t112 = t96 * (t101 * t98 + t105 * t102 + t109 * t106);
        for (int32_t j2_1 = 0; j2_1 <= 3; ++j2_1)
        {
          t113[j2_1] = t113[j2_1] + t52[ip2_1 + 4 * j2_1] * t112;
          t114[j2_1] = t114[j2_1] + t52[ip2_1 + 4 * j2_1] * t111;
          t115[j2_1] = t115[j2_1] + t51[ip2_1 + 4 * j2_1] * t110;
        }
      }
      for (int32_t j1_0 = 0; j1_0 <= 3; ++j1_0)
        for (int32_t j2_2 = 0; j2_2 <= 3; ++j2_2)
        {
          t116[4 * j1_0 + j2_2] = t116[4 * j1_0 + j2_2] + t52[ip1_0 + 4 * j1_0] * t113[j2_2];
          t117[4 * j1_0 + j2_2] = t117[4 * j1_0 + j2_2] + t51[ip1_0 + 4 * j1_0] * t114[j2_2] + t52[ip1_0 + 4 * j1_0] * t115[j2_2];
        }
    }
    for (int32_t j0 = 0; j0 <= 3; ++j0)
      for (int32_t j1_1 = 0; j1_1 <= 3; ++j1_1)
        for (int32_t j2_3 = 0; j2_3 <= 3; ++j2_3)
          A[16 * j0 + 4 * j1_1 + j2_3] = A[16 * j0 + 4 * j1_1 + j2_3] + t51[ip0 + 4 * j0] * t116[4 * j1_1 + j2_3] + t52[ip0 + 4 * j0] * t117[4 * j1_1 + j2_3];
  }

}