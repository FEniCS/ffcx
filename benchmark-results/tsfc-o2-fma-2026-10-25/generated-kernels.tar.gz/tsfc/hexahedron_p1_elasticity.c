#include <stdint.h>
#include <stdbool.h>
#include <math.h>

void k_cell_integral(double *__restrict__ A, double const *__restrict__ coords_0)
{
  double t0;
  double t1;
  double t10;
  double t100[2 * 2];
  double t101;
  double t102;
  double t103;
  double t104[2 * 2];
  double t105;
  double t106[2 * 2];
  double t107[2 * 2 * 2];
  double t108;
  double t109[2 * 2];
  double t11;
  double t110;
  double t111;
  double t112;
  double t113[2 * 2];
  double t114;
  double t115[2 * 2];
  double t116;
  double t117[2 * 2];
  double t118[2 * 2 * 2];
  double t119[2 * 2];
  double t12;
  double t120[2 * 2 * 2];
  double t121[2] = { -1.0, 1.0 };
  double t122[2 * 2];
  double t123[2 * 2];
  double t124[2 * 2];
  double t125[2 * 2];
  double t126[2 * 2];
  double t127[2 * 2];
  double t128[2 * 2];
  double t129[2 * 2];
  double t13;
  double t130[2 * 2];
  double t131[2 * 2 * 2];
  double t132[2 * 2 * 2 * 2];
  double t133[2 * 2 * 2 * 2];
  double t134[2 * 2 * 2 * 2];
  double t135[2 * 2 * 2 * 2];
  double t136[2 * 2 * 2 * 2];
  double t137[2 * 2 * 2 * 2];
  double t138[2 * 2 * 2 * 2];
  double t139[2 * 2 * 2 * 2];
  double t14;
  double t140[2 * 2 * 2 * 2];
  double t141;
  double t142;
  double t143[2 * 2];
  double t144;
  double t145[2 * 2];
  double t146;
  double t147;
  double t148[2 * 2];
  double t149;
  double t15;
  double t150;
  double t151[2 * 2];
  double t152[2];
  double t153;
  double t154;
  double t155;
  double t156[2];
  double t157;
  double t158;
  double t159;
  double t16;
  double t160[2];
  double t161;
  double t162[2];
  double t163[2 * 2];
  double t164;
  double t165[2];
  double t166;
  double t167;
  double t168;
  double t169[2];
  double t17;
  double t170;
  double t171[2];
  double t172;
  double t173[2];
  double t174[2 * 2];
  double t175[2];
  double t176[2 * 2];
  double t177[2 * 2];
  double t178[2 * 2];
  double t179[2 * 2];
  double t18;
  double t180[2 * 2];
  double t181[2 * 2];
  double t182[2 * 2];
  double t183[2 * 2];
  double t184[2 * 2];
  double t185;
  double t186;
  double t187;
  double t188;
  double t189;
  double t19;
  double t190;
  double t191;
  double t192;
  double t193;
  double t194;
  double t195;
  double t196;
  double t197;
  double t198;
  double t199;
  double t2;
  double t20;
  double t200;
  double t201;
  double t202;
  double t203;
  double t204;
  double t205;
  double t206;
  double t207;
  double t208;
  double t209;
  double t21[2] = { 0.7886751345948128, 0.21132486540518713 };
  double t210;
  double t211;
  double t212;
  double t213;
  double t214;
  double t215;
  double t216;
  double t217;
  double t218;
  double t219;
  double t22[2] = { 0.21132486540518713, 0.7886751345948128 };
  double t220;
  double t221;
  double t222;
  double t223;
  double t224;
  double t225;
  double t226;
  double t227;
  double t228;
  double t229;
  double t23[2] = { 0.4999999999999999, 0.4999999999999999 };
  double t230;
  double t231;
  double t232;
  double t233;
  double t234;
  double t235;
  double t236;
  double t237;
  double t238;
  double t239;
  double t24;
  double t240;
  double t241;
  double t242;
  double t243;
  double t244;
  double t245[2];
  double t246[2];
  double t247[2];
  double t248[2];
  double t249[2];
  double t25;
  double t250[2];
  double t251[2];
  double t252[2];
  double t253[2];
  double t254[2];
  double t255[2];
  double t256[2];
  double t257[2];
  double t258[2];
  double t259[2];
  double t26;
  double t260[2];
  double t261[2];
  double t262[2];
  double t263;
  double t264;
  double t265;
  double t266;
  double t267;
  double t268;
  double t269;
  double t27;
  double t270;
  double t271;
  double t272;
  double t273;
  double t274;
  double t275;
  double t276;
  double t277;
  double t278;
  double t279;
  double t28;
  double t280;
  double t281;
  double t282;
  double t283;
  double t284;
  double t285;
  double t286;
  double t287;
  double t288;
  double t289;
  double t29;
  double t290;
  double t291;
  double t292;
  double t293;
  double t294;
  double t295;
  double t296;
  double t297;
  double t298;
  double t299;
  double t3;
  double t30[2 * 2];
  double t300;
  double t301;
  double t302;
  double t303;
  double t304;
  double t305;
  double t306;
  double t307;
  double t308;
  double t309;
  double t31[2 * 2];
  double t310;
  double t311;
  double t312;
  double t313;
  double t314;
  double t315;
  double t316;
  double t317;
  double t318;
  double t319;
  double t32[2 * 2];
  double t320;
  double t321;
  double t322;
  double t323;
  double t324;
  double t325;
  double t326;
  double t327;
  double t328;
  double t329;
  double t33[2 * 2] = { 0.7886751345948128, 0.21132486540518713, 0.21132486540518713, 0.7886751345948128 };
  double t330;
  double t331;
  double t332;
  double t333;
  double t334;
  double t335;
  double t336;
  double t337;
  double t338;
  double t339;
  double t34;
  double t340;
  double t341;
  double t342;
  double t343;
  double t344;
  double t345;
  double t346;
  double t347;
  double t348;
  double t349;
  double t35;
  double t350;
  double t351;
  double t352;
  double t353;
  double t354;
  double t355;
  double t356;
  double t357;
  double t358;
  double t359;
  double t36;
  double t360;
  double t361;
  double t362;
  double t363;
  double t364;
  double t365;
  double t366;
  double t367;
  double t368;
  double t369;
  double t37;
  double t370;
  double t371;
  double t372;
  double t373;
  double t374;
  double t375;
  double t376;
  double t377;
  double t378;
  double t379;
  double t38;
  double t380;
  double t381;
  double t382;
  double t383;
  double t384;
  double t385;
  double t386;
  double t387;
  double t388;
  double t389;
  double t39;
  double t390;
  double t391;
  double t392;
  double t393;
  double t394;
  double t395;
  double t396;
  double t397;
  double t398[2 * 2];
  double t399[2 * 2];
  double t4;
  double t40;
  double t400[2 * 2];
  double t401[2 * 2];
  double t402[2 * 2];
  double t403[2 * 2];
  double t404[2 * 2];
  double t405[2 * 2];
  double t406[2 * 2];
  double t407[2 * 2];
  double t408[2 * 2];
  double t409[2 * 2];
  double t41;
  double t410[2 * 2];
  double t411[2 * 2];
  double t412[2 * 2];
  double t413[2 * 2];
  double t414[2 * 2];
  double t415[2 * 2];
  double t416[2];
  double t417[2];
  double t418[2];
  double t419[2];
  double t42;
  double t420[2];
  double t421[2];
  double t422[2];
  double t423[2];
  double t424[2];
  double t425[2];
  double t426[2];
  double t427[2];
  double t428[2];
  double t429[2];
  double t43;
  double t430[2];
  double t431[2];
  double t432[2];
  double t433[2];
  double t434[2 * 2 * 2];
  double t435[2 * 2 * 2];
  double t436[2 * 2 * 2];
  double t437[2 * 2 * 2];
  double t438[2 * 2 * 2];
  double t439[2 * 2 * 2];
  double t44;
  double t440[2 * 2 * 2];
  double t441[2 * 2 * 2];
  double t442[2 * 2 * 2];
  double t443[2 * 2];
  double t444[2 * 2];
  double t445[2 * 2];
  double t446[2 * 2];
  double t447[2 * 2];
  double t448[2 * 2];
  double t449[2 * 2];
  double t45;
  double t450[2 * 2];
  double t451[2 * 2];
  double t452[2 * 2];
  double t453[2 * 2];
  double t454[2 * 2];
  double t455[2 * 2];
  double t456[2 * 2];
  double t457[2 * 2];
  double t458[2 * 2];
  double t459[2 * 2];
  double t46;
  double t460[2 * 2];
  double t461[2 * 2 * 2];
  double t462[2 * 2 * 2];
  double t463[2 * 2 * 2];
  double t464[2 * 2 * 2];
  double t465[2 * 2 * 2];
  double t466[2 * 2 * 2];
  double t467[2 * 2 * 2];
  double t468[2 * 2 * 2];
  double t469[2 * 2 * 2];
  double t47;
  double t470[2 * 2];
  double t471[2 * 2];
  double t472[2 * 2];
  double t473[2 * 2];
  double t474[2 * 2];
  double t475[2 * 2];
  double t476[2 * 2];
  double t477[2 * 2];
  double t478[2 * 2];
  double t479[2 * 2 * 2];
  double t48;
  double t480[2 * 2 * 2];
  double t481[2 * 2 * 2];
  double t482[2 * 2 * 2];
  double t483[2 * 2 * 2];
  double t484[2 * 2 * 2];
  double t485[2 * 2 * 2];
  double t486[2 * 2 * 2];
  double t487[2 * 2 * 2];
  double t488[2 * 2 * 2];
  double t489[2 * 2 * 2];
  double t49;
  double t490[2 * 2 * 2];
  double t491[2 * 2 * 2];
  double t492[2 * 2 * 2];
  double t493[2 * 2 * 2];
  double t494[2 * 2 * 2];
  double t495[2 * 2 * 2];
  double t496[2 * 2 * 2];
  double t497[2 * 2 * 2 * 2];
  double t498[2 * 2 * 2 * 2];
  double t499[2 * 2 * 2 * 2];
  double t5;
  double t50;
  double t500[2 * 2 * 2 * 2];
  double t501[2 * 2 * 2 * 2];
  double t502[2 * 2 * 2 * 2];
  double t503[2 * 2 * 2 * 2];
  double t504[2 * 2 * 2 * 2];
  double t505[2 * 2 * 2 * 2];
  double t506[2 * 2 * 2 * 2];
  double t507[2 * 2 * 2 * 2];
  double t508[2 * 2 * 2 * 2];
  double t509[2 * 2 * 2 * 2];
  double t51;
  double t510[2 * 2 * 2 * 2];
  double t511[2 * 2 * 2 * 2];
  double t512[2 * 2 * 2 * 2];
  double t513[2 * 2 * 2 * 2];
  double t514[2 * 2 * 2 * 2];
  double t515[2];
  double t516[2 * 2 * 2 * 2];
  double t517[2 * 2 * 2 * 2];
  double t518[2 * 2 * 2 * 2];
  double t519[2 * 2 * 2 * 2];
  double t52;
  double t520[2 * 2 * 2 * 2];
  double t521[2 * 2 * 2 * 2];
  double t522[2 * 2 * 2 * 2];
  double t523[2 * 2 * 2 * 2];
  double t524[2 * 2 * 2 * 2];
  double t525[2 * 2 * 2 * 2];
  double t526[2 * 2 * 2 * 2];
  double t527[2 * 2 * 2 * 2];
  double t528[2 * 2 * 2 * 2];
  double t529[2 * 2 * 2 * 2];
  double t53;
  double t530[2 * 2 * 2 * 2];
  double t531[2 * 2 * 2 * 2];
  double t532[2 * 2 * 2 * 2];
  double t533[2 * 2 * 2 * 2];
  double t534[2 * 2 * 2 * 2];
  double t535[2 * 2 * 2 * 2];
  double t536[2 * 2 * 2 * 2];
  double t537[2 * 2 * 2 * 2];
  double t538[2 * 2 * 2 * 2];
  double t539[2 * 2 * 2 * 2];
  double t54;
  double t540[2 * 2 * 2 * 2];
  double t541[2 * 2 * 2 * 2];
  double t542[2 * 2 * 2 * 2];
  double t543[2 * 2 * 2 * 2];
  double t544[2 * 2 * 2 * 2];
  double t545[2 * 2 * 2 * 2];
  double t546[2 * 2 * 2 * 2];
  double t547[2 * 2 * 2 * 2];
  double t548[2 * 2 * 2 * 2];
  double t549[2 * 2 * 2 * 2];
  double t55;
  double t550[2 * 2 * 2 * 2];
  double t551[2 * 2 * 2 * 2];
  double t552[2 * 2 * 2 * 2];
  double t553[2 * 2 * 2 * 2];
  double t554[2 * 2 * 2 * 2];
  double t555[2 * 2 * 2 * 2];
  double t556[2 * 2 * 2 * 2];
  double t557[2 * 2 * 2 * 2];
  double t558[2 * 2 * 2 * 2];
  double t559[2 * 2 * 2 * 2];
  double t56;
  double t560[2 * 2 * 2 * 2];
  double t561[2 * 2 * 2 * 2];
  double t562[2 * 2 * 2 * 2];
  double t563[2 * 2 * 2 * 2];
  double t564[2 * 2 * 2 * 2];
  double t565[2 * 2 * 2 * 2];
  double t566[2 * 2 * 2 * 2];
  double t567[2 * 2 * 2 * 2];
  double t568[2 * 2 * 2 * 2];
  double t569[2 * 2 * 2 * 2];
  double t57;
  double t570[2 * 2 * 2 * 2 * 2];
  double t571[2 * 2 * 2 * 2 * 2];
  double t572[2 * 2 * 2 * 2 * 2];
  double t573[2 * 2 * 2 * 2 * 2];
  double t574[2 * 2 * 2 * 2 * 2];
  double t575[2 * 2 * 2 * 2 * 2];
  double t576[2 * 2 * 2 * 2 * 2];
  double t577[2 * 2 * 2 * 2 * 2];
  double t578[2 * 2 * 2 * 2 * 2];
  double t579[2 * 2 * 2 * 2];
  double t58;
  double t580[2 * 2 * 2 * 2];
  double t581[2 * 2 * 2 * 2];
  double t582[2 * 2 * 2 * 2];
  double t583[2 * 2 * 2 * 2];
  double t584[2 * 2 * 2 * 2];
  double t585[2 * 2 * 2 * 2];
  double t586[2 * 2 * 2 * 2];
  double t587[2 * 2 * 2 * 2];
  double t588[2 * 2 * 2];
  double t589[2 * 2 * 2];
  double t59;
  double t590[2 * 2 * 2];
  double t591[2 * 2 * 2];
  double t592[2 * 2 * 2];
  double t593[2 * 2 * 2];
  double t594[2 * 2 * 2];
  double t595[2 * 2 * 2];
  double t596[2 * 2 * 2];
  double t6;
  double t60;
  double t61;
  double t62;
  double t63;
  double t64;
  double t65;
  double t66;
  double t67;
  double t68;
  double t69;
  double t7;
  double t70;
  double t71;
  double t72;
  double t73[2 * 2];
  double t74[2];
  double t75[2 * 2];
  double t76[2 * 2];
  double t77[2 * 2];
  double t78[2 * 2];
  double t79[2 * 2];
  double t8;
  double t80;
  double t81;
  double t82[2 * 2 * 2];
  double t83[2 * 2 * 2];
  double t84;
  double t85[2 * 2 * 2];
  double t86[2 * 2 * 2];
  double t87[2 * 2 * 2];
  double t88;
  double t89[2 * 2 * 2];
  double t9;
  double t90;
  double t91;
  double t92[2 * 2 * 2];
  double t93;
  double t94;
  double t95[2 * 2 * 2];
  double t96[2 * 2];
  double t97;
  double t98;
  double t99;

  t0 = -1.0 * coords_0[8];
  t1 = t0 + coords_0[20];
  t2 = -1.0 * coords_0[2];
  t3 = t2 + coords_0[14];
  t4 = -1.0 * coords_0[11] + coords_0[23];
  t5 = -1.0 * coords_0[5];
  t6 = t5 + coords_0[17];
  t7 = -1.0 * coords_0[7];
  t8 = t7 + coords_0[19];
  t9 = -1.0 * coords_0[1];
  t10 = t9 + coords_0[13];
  t11 = -1.0 * coords_0[10] + coords_0[22];
  t12 = -1.0 * coords_0[4];
  t13 = t12 + coords_0[16];
  t14 = -1.0 * coords_0[6];
  t15 = t14 + coords_0[18];
  t16 = -1.0 * coords_0[0];
  t17 = t16 + coords_0[12];
  t18 = -1.0 * coords_0[9] + coords_0[21];
  t19 = -1.0 * coords_0[3];
  t20 = t19 + coords_0[15];
  for (int32_t ip1 = 0; ip1 <= 1; ++ip1)
  {
    t24 = t21[ip1] * t20 + t22[ip1] * t18;
    t25 = t21[ip1] * t17 + t22[ip1] * t15;
    t26 = t21[ip1] * t13 + t22[ip1] * t11;
    t27 = t21[ip1] * t10 + t22[ip1] * t8;
    t28 = t21[ip1] * t6 + t22[ip1] * t4;
    t29 = t21[ip1] * t3 + t22[ip1] * t1;
    for (int32_t ip2 = 0; ip2 <= 1; ++ip2)
    {
      t119[2 * ip1 + ip2] = (double) (0.0);
      t117[2 * ip1 + ip2] = (double) (0.0);
      t115[2 * ip1 + ip2] = (double) (0.0);
      t113[2 * ip1 + ip2] = (double) (0.0);
      t109[2 * ip1 + ip2] = (double) (0.0);
      t106[2 * ip1 + ip2] = (double) (0.0);
      t104[2 * ip1 + ip2] = (double) (0.0);
      t100[2 * ip1 + ip2] = (double) (0.0);
      t96[2 * ip1 + ip2] = (double) (0.0);
      t30[2 * ip1 + ip2] = t21[ip2] * t29 + t22[ip2] * t28;
      t31[2 * ip1 + ip2] = t21[ip2] * t27 + t22[ip2] * t26;
      t32[2 * ip1 + ip2] = t21[ip2] * t25 + t22[ip2] * t24;
    }
  }
  t34 = -1.0 * coords_0[12];
  t35 = t34 + coords_0[18];
  t36 = t16 + coords_0[6];
  t37 = -1.0 * coords_0[15] + coords_0[21];
  t38 = t19 + coords_0[9];
  t39 = -1.0 * coords_0[14];
  t40 = t39 + coords_0[20];
  t41 = t2 + coords_0[8];
  t42 = -1.0 * coords_0[17] + coords_0[23];
  t43 = t5 + coords_0[11];
  t44 = -1.0 * coords_0[13];
  t45 = t44 + coords_0[19];
  t46 = t9 + coords_0[7];
  t47 = -1.0 * coords_0[16] + coords_0[22];
  t48 = t12 + coords_0[10];
  t49 = t34 + coords_0[15];
  t50 = t16 + coords_0[3];
  t51 = -1.0 * coords_0[18] + coords_0[21];
  t52 = t14 + coords_0[9];
  t53 = t44 + coords_0[16];
  t54 = t9 + coords_0[4];
  t55 = -1.0 * coords_0[19] + coords_0[22];
  t56 = t7 + coords_0[10];
  t57 = t39 + coords_0[17];
  t58 = t2 + coords_0[5];
  t59 = -1.0 * coords_0[20] + coords_0[23];
  t60 = t0 + coords_0[11];
  for (int32_t ip0 = 0; ip0 <= 1; ++ip0)
  {
    t61 = t21[ip0] * t60 + t22[ip0] * t59;
    t62 = t21[ip0] * t58 + t22[ip0] * t57;
    t63 = t21[ip0] * t56 + t22[ip0] * t55;
    t64 = t21[ip0] * t54 + t22[ip0] * t53;
    t65 = t21[ip0] * t52 + t22[ip0] * t51;
    t66 = t21[ip0] * t50 + t22[ip0] * t49;
    t67 = t21[ip0] * t48 + t22[ip0] * t47;
    t68 = t21[ip0] * t46 + t22[ip0] * t45;
    t69 = t21[ip0] * t43 + t22[ip0] * t42;
    t70 = t21[ip0] * t41 + t22[ip0] * t40;
    t71 = t21[ip0] * t38 + t22[ip0] * t37;
    t72 = t21[ip0] * t36 + t22[ip0] * t35;
    for (int32_t ip2_0 = 0; ip2_0 <= 1; ++ip2_0)
    {
      t73[2 * ip0 + ip2_0] = t21[ip2_0] * t72 + t22[ip2_0] * t71;
      t74[ip2_0] = -1.0 * t73[2 * ip0 + ip2_0];
      t75[2 * ip0 + ip2_0] = t21[ip2_0] * t70 + t22[ip2_0] * t69;
      t76[2 * ip0 + ip2_0] = t21[ip2_0] * t68 + t22[ip2_0] * t67;
    }
    for (int32_t ip1_0 = 0; ip1_0 <= 1; ++ip1_0)
    {
      t77[2 * ip0 + ip1_0] = t21[ip1_0] * t66 + t22[ip1_0] * t65;
      t78[2 * ip0 + ip1_0] = t21[ip1_0] * t64 + t22[ip1_0] * t63;
      t79[2 * ip0 + ip1_0] = t21[ip1_0] * t62 + t22[ip1_0] * t61;
      t80 = t23[ip0] * t23[ip1_0];
      for (int32_t ip2_1 = 0; ip2_1 <= 1; ++ip2_1)
      {
        t81 = t76[2 * ip0 + ip2_1] * t79[2 * ip0 + ip1_0] + -1.0 * t78[2 * ip0 + ip1_0] * t75[2 * ip0 + ip2_1];
        t82[4 * ip0 + 2 * ip1_0 + ip2_1] = t78[2 * ip0 + ip1_0] * t30[2 * ip1_0 + ip2_1];
        t83[4 * ip0 + 2 * ip1_0 + ip2_1] = t31[2 * ip1_0 + ip2_1] * t75[2 * ip0 + ip2_1] + -1.0 * t76[2 * ip0 + ip2_1] * t30[2 * ip1_0 + ip2_1];
        t84 = t32[2 * ip1_0 + ip2_1] * t81 + (t31[2 * ip1_0 + ip2_1] * t79[2 * ip0 + ip1_0] + -1.0 * t82[4 * ip0 + 2 * ip1_0 + ip2_1]) * t74[ip2_1] + t77[2 * ip0 + ip1_0] * t83[4 * ip0 + 2 * ip1_0 + ip2_1];
        t85[4 * ip0 + 2 * ip1_0 + ip2_1] = t80 * t23[ip2_1] * fabs(t84);
        t86[4 * ip0 + 2 * ip1_0 + ip2_1] = 1.0 / t84;
        t87[4 * ip0 + 2 * ip1_0 + ip2_1] = (t73[2 * ip0 + ip2_1] * t78[2 * ip0 + ip1_0] + -1.0 * t77[2 * ip0 + ip1_0] * t76[2 * ip0 + ip2_1]) * t86[4 * ip0 + 2 * ip1_0 + ip2_1];
        t88 = t87[4 * ip0 + 2 * ip1_0 + ip2_1] * t87[4 * ip0 + 2 * ip1_0 + ip2_1];
        t89[4 * ip0 + 2 * ip1_0 + ip2_1] = t81 * t86[4 * ip0 + 2 * ip1_0 + ip2_1];
        t90 = t89[4 * ip0 + 2 * ip1_0 + ip2_1] * t89[4 * ip0 + 2 * ip1_0 + ip2_1];
        t91 = 0.25 * t90;
        t92[4 * ip0 + 2 * ip1_0 + ip2_1] = (t77[2 * ip0 + ip1_0] * t75[2 * ip0 + ip2_1] + t79[2 * ip0 + ip1_0] * t74[ip2_1]) * t86[4 * ip0 + 2 * ip1_0 + ip2_1];
        t93 = t92[4 * ip0 + 2 * ip1_0 + ip2_1] * t92[4 * ip0 + 2 * ip1_0 + ip2_1];
        t94 = 0.25 * t93;
        t95[4 * ip0 + 2 * ip1_0 + ip2_1] = t87[4 * ip0 + 2 * ip1_0 + ip2_1] + t87[4 * ip0 + 2 * ip1_0 + ip2_1];
        t96[2 * ip1_0 + ip2_1] = t96[2 * ip1_0 + ip2_1] + t85[4 * ip0 + 2 * ip1_0 + ip2_1] * (t88 + t91 + t94 + t91 + t94 + 0.25 * t95[4 * ip0 + 2 * ip1_0 + ip2_1] * t95[4 * ip0 + 2 * ip1_0 + ip2_1]);
        t97 = t92[4 * ip0 + 2 * ip1_0 + ip2_1] * t87[4 * ip0 + 2 * ip1_0 + ip2_1];
        t98 = t87[4 * ip0 + 2 * ip1_0 + ip2_1] * t92[4 * ip0 + 2 * ip1_0 + ip2_1];
        t99 = 0.25 * t98;
        t100[2 * ip1_0 + ip2_1] = t100[2 * ip1_0 + ip2_1] + t85[4 * ip0 + 2 * ip1_0 + ip2_1] * (t97 + t99 + t99);
        t101 = t89[4 * ip0 + 2 * ip1_0 + ip2_1] * t87[4 * ip0 + 2 * ip1_0 + ip2_1];
        t102 = t87[4 * ip0 + 2 * ip1_0 + ip2_1] * t89[4 * ip0 + 2 * ip1_0 + ip2_1];
        t103 = 0.25 * t102;
        t104[2 * ip1_0 + ip2_1] = t104[2 * ip1_0 + ip2_1] + t85[4 * ip0 + 2 * ip1_0 + ip2_1] * (t101 + t103 + t103);
        t105 = 0.25 * t97;
        t106[2 * ip1_0 + ip2_1] = t106[2 * ip1_0 + ip2_1] + t85[4 * ip0 + 2 * ip1_0 + ip2_1] * (t98 + t105 + t105);
        t107[4 * ip0 + 2 * ip1_0 + ip2_1] = t92[4 * ip0 + 2 * ip1_0 + ip2_1] + t92[4 * ip0 + 2 * ip1_0 + ip2_1];
        t108 = 0.25 * t88;
        t109[2 * ip1_0 + ip2_1] = t109[2 * ip1_0 + ip2_1] + t85[4 * ip0 + 2 * ip1_0 + ip2_1] * (t93 + t91 + t91 + 0.25 * t107[4 * ip0 + 2 * ip1_0 + ip2_1] * t107[4 * ip0 + 2 * ip1_0 + ip2_1] + t108 + t108);
        t110 = t89[4 * ip0 + 2 * ip1_0 + ip2_1] * t92[4 * ip0 + 2 * ip1_0 + ip2_1];
        t111 = t92[4 * ip0 + 2 * ip1_0 + ip2_1] * t89[4 * ip0 + 2 * ip1_0 + ip2_1];
        t112 = 0.25 * t111;
        t113[2 * ip1_0 + ip2_1] = t113[2 * ip1_0 + ip2_1] + t85[4 * ip0 + 2 * ip1_0 + ip2_1] * (t110 + t112 + t112);
        t114 = 0.25 * t101;
        t115[2 * ip1_0 + ip2_1] = t115[2 * ip1_0 + ip2_1] + t85[4 * ip0 + 2 * ip1_0 + ip2_1] * (t102 + t114 + t114);
        t116 = 0.25 * t110;
        t117[2 * ip1_0 + ip2_1] = t117[2 * ip1_0 + ip2_1] + t85[4 * ip0 + 2 * ip1_0 + ip2_1] * (t111 + t116 + t116);
        t118[4 * ip0 + 2 * ip1_0 + ip2_1] = t89[4 * ip0 + 2 * ip1_0 + ip2_1] + t89[4 * ip0 + 2 * ip1_0 + ip2_1];
        t119[2 * ip1_0 + ip2_1] = t119[2 * ip1_0 + ip2_1] + t85[4 * ip0 + 2 * ip1_0 + ip2_1] * (t90 + 0.25 * t118[4 * ip0 + 2 * ip1_0 + ip2_1] * t118[4 * ip0 + 2 * ip1_0 + ip2_1] + t94 + t108 + t94 + t108);
      }
    }
  }
  for (int32_t ip2_2 = 0; ip2_2 <= 1; ++ip2_2)
    for (int32_t j2 = 0; j2 <= 1; ++j2)
      for (int32_t k2 = 0; k2 <= 1; ++k2)
        t120[4 * ip2_2 + 2 * j2 + k2] = t33[ip2_2 + 2 * j2] * t33[ip2_2 + 2 * k2];
  for (int32_t j1 = 0; j1 <= 1; ++j1)
    for (int32_t j2_0 = 0; j2_0 <= 1; ++j2_0)
    {
      for (int32_t k1 = 0; k1 <= 1; ++k1)
        for (int32_t k2_0 = 0; k2_0 <= 1; ++k2_0)
        {
          t140[8 * j1 + 4 * j2_0 + 2 * k1 + k2_0] = (double) (0.0);
          t139[8 * j1 + 4 * j2_0 + 2 * k1 + k2_0] = (double) (0.0);
          t138[8 * j1 + 4 * j2_0 + 2 * k1 + k2_0] = (double) (0.0);
          t137[8 * j1 + 4 * j2_0 + 2 * k1 + k2_0] = (double) (0.0);
          t136[8 * j1 + 4 * j2_0 + 2 * k1 + k2_0] = (double) (0.0);
          t135[8 * j1 + 4 * j2_0 + 2 * k1 + k2_0] = (double) (0.0);
          t134[8 * j1 + 4 * j2_0 + 2 * k1 + k2_0] = (double) (0.0);
          t133[8 * j1 + 4 * j2_0 + 2 * k1 + k2_0] = (double) (0.0);
          t132[8 * j1 + 4 * j2_0 + 2 * k1 + k2_0] = (double) (0.0);
        }
      for (int32_t k0 = 0; k0 <= 1; ++k0)
      {
        for (int32_t k2_1 = 0; k2_1 <= 1; ++k2_1)
        {
          t505[8 * j1 + 4 * j2_0 + 2 * k0 + k2_1] = (double) (0.0);
          t504[8 * j1 + 4 * j2_0 + 2 * k0 + k2_1] = (double) (0.0);
          t503[8 * j1 + 4 * j2_0 + 2 * k0 + k2_1] = (double) (0.0);
          t502[8 * j1 + 4 * j2_0 + 2 * k0 + k2_1] = (double) (0.0);
          t501[8 * j1 + 4 * j2_0 + 2 * k0 + k2_1] = (double) (0.0);
          t500[8 * j1 + 4 * j2_0 + 2 * k0 + k2_1] = (double) (0.0);
          t499[8 * j1 + 4 * j2_0 + 2 * k0 + k2_1] = (double) (0.0);
          t498[8 * j1 + 4 * j2_0 + 2 * k0 + k2_1] = (double) (0.0);
          t497[8 * j1 + 4 * j2_0 + 2 * k0 + k2_1] = (double) (0.0);
        }
        for (int32_t k1_0 = 0; k1_0 <= 1; ++k1_0)
        {
          t514[8 * j1 + 4 * j2_0 + 2 * k0 + k1_0] = (double) (0.0);
          t513[8 * j1 + 4 * j2_0 + 2 * k0 + k1_0] = (double) (0.0);
          t512[8 * j1 + 4 * j2_0 + 2 * k0 + k1_0] = (double) (0.0);
          t511[8 * j1 + 4 * j2_0 + 2 * k0 + k1_0] = (double) (0.0);
          t510[8 * j1 + 4 * j2_0 + 2 * k0 + k1_0] = (double) (0.0);
          t509[8 * j1 + 4 * j2_0 + 2 * k0 + k1_0] = (double) (0.0);
          t508[8 * j1 + 4 * j2_0 + 2 * k0 + k1_0] = (double) (0.0);
          t507[8 * j1 + 4 * j2_0 + 2 * k0 + k1_0] = (double) (0.0);
          t506[8 * j1 + 4 * j2_0 + 2 * k0 + k1_0] = (double) (0.0);
        }
      }
    }
  for (int32_t j0 = 0; j0 <= 1; ++j0)
  {
    for (int32_t j2_1 = 0; j2_1 <= 1; ++j2_1)
    {
      for (int32_t k1_1 = 0; k1_1 <= 1; ++k1_1)
        for (int32_t k2_2 = 0; k2_2 <= 1; ++k2_2)
        {
          t524[8 * j0 + 4 * j2_1 + 2 * k1_1 + k2_2] = (double) (0.0);
          t523[8 * j0 + 4 * j2_1 + 2 * k1_1 + k2_2] = (double) (0.0);
          t522[8 * j0 + 4 * j2_1 + 2 * k1_1 + k2_2] = (double) (0.0);
          t521[8 * j0 + 4 * j2_1 + 2 * k1_1 + k2_2] = (double) (0.0);
          t520[8 * j0 + 4 * j2_1 + 2 * k1_1 + k2_2] = (double) (0.0);
          t519[8 * j0 + 4 * j2_1 + 2 * k1_1 + k2_2] = (double) (0.0);
          t518[8 * j0 + 4 * j2_1 + 2 * k1_1 + k2_2] = (double) (0.0);
          t517[8 * j0 + 4 * j2_1 + 2 * k1_1 + k2_2] = (double) (0.0);
          t516[8 * j0 + 4 * j2_1 + 2 * k1_1 + k2_2] = (double) (0.0);
        }
      for (int32_t k0_0 = 0; k0_0 <= 1; ++k0_0)
      {
        for (int32_t k2_3 = 0; k2_3 <= 1; ++k2_3)
        {
          t533[8 * j0 + 4 * j2_1 + 2 * k0_0 + k2_3] = (double) (0.0);
          t532[8 * j0 + 4 * j2_1 + 2 * k0_0 + k2_3] = (double) (0.0);
          t531[8 * j0 + 4 * j2_1 + 2 * k0_0 + k2_3] = (double) (0.0);
          t530[8 * j0 + 4 * j2_1 + 2 * k0_0 + k2_3] = (double) (0.0);
          t529[8 * j0 + 4 * j2_1 + 2 * k0_0 + k2_3] = (double) (0.0);
          t528[8 * j0 + 4 * j2_1 + 2 * k0_0 + k2_3] = (double) (0.0);
          t527[8 * j0 + 4 * j2_1 + 2 * k0_0 + k2_3] = (double) (0.0);
          t526[8 * j0 + 4 * j2_1 + 2 * k0_0 + k2_3] = (double) (0.0);
          t525[8 * j0 + 4 * j2_1 + 2 * k0_0 + k2_3] = (double) (0.0);
        }
        for (int32_t k1_2 = 0; k1_2 <= 1; ++k1_2)
        {
          t542[8 * j0 + 4 * j2_1 + 2 * k0_0 + k1_2] = (double) (0.0);
          t541[8 * j0 + 4 * j2_1 + 2 * k0_0 + k1_2] = (double) (0.0);
          t540[8 * j0 + 4 * j2_1 + 2 * k0_0 + k1_2] = (double) (0.0);
          t539[8 * j0 + 4 * j2_1 + 2 * k0_0 + k1_2] = (double) (0.0);
          t538[8 * j0 + 4 * j2_1 + 2 * k0_0 + k1_2] = (double) (0.0);
          t537[8 * j0 + 4 * j2_1 + 2 * k0_0 + k1_2] = (double) (0.0);
          t536[8 * j0 + 4 * j2_1 + 2 * k0_0 + k1_2] = (double) (0.0);
          t535[8 * j0 + 4 * j2_1 + 2 * k0_0 + k1_2] = (double) (0.0);
          t534[8 * j0 + 4 * j2_1 + 2 * k0_0 + k1_2] = (double) (0.0);
        }
      }
    }
    for (int32_t j1_0 = 0; j1_0 <= 1; ++j1_0)
    {
      for (int32_t k1_3 = 0; k1_3 <= 1; ++k1_3)
        for (int32_t k2_4 = 0; k2_4 <= 1; ++k2_4)
        {
          t551[8 * j0 + 4 * j1_0 + 2 * k1_3 + k2_4] = (double) (0.0);
          t550[8 * j0 + 4 * j1_0 + 2 * k1_3 + k2_4] = (double) (0.0);
          t549[8 * j0 + 4 * j1_0 + 2 * k1_3 + k2_4] = (double) (0.0);
          t548[8 * j0 + 4 * j1_0 + 2 * k1_3 + k2_4] = (double) (0.0);
          t547[8 * j0 + 4 * j1_0 + 2 * k1_3 + k2_4] = (double) (0.0);
          t546[8 * j0 + 4 * j1_0 + 2 * k1_3 + k2_4] = (double) (0.0);
          t545[8 * j0 + 4 * j1_0 + 2 * k1_3 + k2_4] = (double) (0.0);
          t544[8 * j0 + 4 * j1_0 + 2 * k1_3 + k2_4] = (double) (0.0);
          t543[8 * j0 + 4 * j1_0 + 2 * k1_3 + k2_4] = (double) (0.0);
        }
      for (int32_t k0_1 = 0; k0_1 <= 1; ++k0_1)
      {
        for (int32_t k2_5 = 0; k2_5 <= 1; ++k2_5)
        {
          t560[8 * j0 + 4 * j1_0 + 2 * k0_1 + k2_5] = (double) (0.0);
          t559[8 * j0 + 4 * j1_0 + 2 * k0_1 + k2_5] = (double) (0.0);
          t558[8 * j0 + 4 * j1_0 + 2 * k0_1 + k2_5] = (double) (0.0);
          t557[8 * j0 + 4 * j1_0 + 2 * k0_1 + k2_5] = (double) (0.0);
          t556[8 * j0 + 4 * j1_0 + 2 * k0_1 + k2_5] = (double) (0.0);
          t555[8 * j0 + 4 * j1_0 + 2 * k0_1 + k2_5] = (double) (0.0);
          t554[8 * j0 + 4 * j1_0 + 2 * k0_1 + k2_5] = (double) (0.0);
          t553[8 * j0 + 4 * j1_0 + 2 * k0_1 + k2_5] = (double) (0.0);
          t552[8 * j0 + 4 * j1_0 + 2 * k0_1 + k2_5] = (double) (0.0);
        }
        for (int32_t k1_4 = 0; k1_4 <= 1; ++k1_4)
        {
          t569[8 * j0 + 4 * j1_0 + 2 * k0_1 + k1_4] = (double) (0.0);
          t568[8 * j0 + 4 * j1_0 + 2 * k0_1 + k1_4] = (double) (0.0);
          t567[8 * j0 + 4 * j1_0 + 2 * k0_1 + k1_4] = (double) (0.0);
          t566[8 * j0 + 4 * j1_0 + 2 * k0_1 + k1_4] = (double) (0.0);
          t565[8 * j0 + 4 * j1_0 + 2 * k0_1 + k1_4] = (double) (0.0);
          t564[8 * j0 + 4 * j1_0 + 2 * k0_1 + k1_4] = (double) (0.0);
          t563[8 * j0 + 4 * j1_0 + 2 * k0_1 + k1_4] = (double) (0.0);
          t562[8 * j0 + 4 * j1_0 + 2 * k0_1 + k1_4] = (double) (0.0);
          t561[8 * j0 + 4 * j1_0 + 2 * k0_1 + k1_4] = (double) (0.0);
        }
      }
    }
  }
  for (int32_t ip1_1 = 0; ip1_1 <= 1; ++ip1_1)
  {
    for (int32_t j2_2 = 0; j2_2 <= 1; ++j2_2)
      for (int32_t k2_6 = 0; k2_6 <= 1; ++k2_6)
      {
        t130[2 * j2_2 + k2_6] = (double) (0.0);
        t129[2 * j2_2 + k2_6] = (double) (0.0);
        t128[2 * j2_2 + k2_6] = (double) (0.0);
        t127[2 * j2_2 + k2_6] = (double) (0.0);
        t126[2 * j2_2 + k2_6] = (double) (0.0);
        t125[2 * j2_2 + k2_6] = (double) (0.0);
        t124[2 * j2_2 + k2_6] = (double) (0.0);
        t123[2 * j2_2 + k2_6] = (double) (0.0);
        t122[2 * j2_2 + k2_6] = (double) (0.0);
      }
    for (int32_t ip2_3 = 0; ip2_3 <= 1; ++ip2_3)
      for (int32_t j2_3 = 0; j2_3 <= 1; ++j2_3)
        for (int32_t k2_7 = 0; k2_7 <= 1; ++k2_7)
        {
          t122[2 * j2_3 + k2_7] = t122[2 * j2_3 + k2_7] + t96[2 * ip1_1 + ip2_3] * t120[4 * ip2_3 + 2 * j2_3 + k2_7];
          t123[2 * j2_3 + k2_7] = t123[2 * j2_3 + k2_7] + t100[2 * ip1_1 + ip2_3] * t120[4 * ip2_3 + 2 * j2_3 + k2_7];
          t124[2 * j2_3 + k2_7] = t124[2 * j2_3 + k2_7] + t104[2 * ip1_1 + ip2_3] * t120[4 * ip2_3 + 2 * j2_3 + k2_7];
          t125[2 * j2_3 + k2_7] = t125[2 * j2_3 + k2_7] + t106[2 * ip1_1 + ip2_3] * t120[4 * ip2_3 + 2 * j2_3 + k2_7];
          t126[2 * j2_3 + k2_7] = t126[2 * j2_3 + k2_7] + t109[2 * ip1_1 + ip2_3] * t120[4 * ip2_3 + 2 * j2_3 + k2_7];
          t127[2 * j2_3 + k2_7] = t127[2 * j2_3 + k2_7] + t113[2 * ip1_1 + ip2_3] * t120[4 * ip2_3 + 2 * j2_3 + k2_7];
          t128[2 * j2_3 + k2_7] = t128[2 * j2_3 + k2_7] + t115[2 * ip1_1 + ip2_3] * t120[4 * ip2_3 + 2 * j2_3 + k2_7];
          t129[2 * j2_3 + k2_7] = t129[2 * j2_3 + k2_7] + t117[2 * ip1_1 + ip2_3] * t120[4 * ip2_3 + 2 * j2_3 + k2_7];
          t130[2 * j2_3 + k2_7] = t130[2 * j2_3 + k2_7] + t119[2 * ip1_1 + ip2_3] * t120[4 * ip2_3 + 2 * j2_3 + k2_7];
        }
    for (int32_t j1_1 = 0; j1_1 <= 1; ++j1_1)
    {
      for (int32_t k1_5 = 0; k1_5 <= 1; ++k1_5)
        t131[4 * ip1_1 + 2 * j1_1 + k1_5] = t33[ip1_1 + 2 * j1_1] * t33[ip1_1 + 2 * k1_5];
      for (int32_t j2_4 = 0; j2_4 <= 1; ++j2_4)
        for (int32_t k1_6 = 0; k1_6 <= 1; ++k1_6)
          for (int32_t k2_8 = 0; k2_8 <= 1; ++k2_8)
          {
            t132[8 * j1_1 + 4 * j2_4 + 2 * k1_6 + k2_8] = t132[8 * j1_1 + 4 * j2_4 + 2 * k1_6 + k2_8] + t122[2 * j2_4 + k2_8] * t131[4 * ip1_1 + 2 * j1_1 + k1_6];
            t133[8 * j1_1 + 4 * j2_4 + 2 * k1_6 + k2_8] = t133[8 * j1_1 + 4 * j2_4 + 2 * k1_6 + k2_8] + t123[2 * j2_4 + k2_8] * t131[4 * ip1_1 + 2 * j1_1 + k1_6];
            t134[8 * j1_1 + 4 * j2_4 + 2 * k1_6 + k2_8] = t134[8 * j1_1 + 4 * j2_4 + 2 * k1_6 + k2_8] + t124[2 * j2_4 + k2_8] * t131[4 * ip1_1 + 2 * j1_1 + k1_6];
            t135[8 * j1_1 + 4 * j2_4 + 2 * k1_6 + k2_8] = t135[8 * j1_1 + 4 * j2_4 + 2 * k1_6 + k2_8] + t125[2 * j2_4 + k2_8] * t131[4 * ip1_1 + 2 * j1_1 + k1_6];
            t136[8 * j1_1 + 4 * j2_4 + 2 * k1_6 + k2_8] = t136[8 * j1_1 + 4 * j2_4 + 2 * k1_6 + k2_8] + t126[2 * j2_4 + k2_8] * t131[4 * ip1_1 + 2 * j1_1 + k1_6];
            t137[8 * j1_1 + 4 * j2_4 + 2 * k1_6 + k2_8] = t137[8 * j1_1 + 4 * j2_4 + 2 * k1_6 + k2_8] + t127[2 * j2_4 + k2_8] * t131[4 * ip1_1 + 2 * j1_1 + k1_6];
            t138[8 * j1_1 + 4 * j2_4 + 2 * k1_6 + k2_8] = t138[8 * j1_1 + 4 * j2_4 + 2 * k1_6 + k2_8] + t128[2 * j2_4 + k2_8] * t131[4 * ip1_1 + 2 * j1_1 + k1_6];
            t139[8 * j1_1 + 4 * j2_4 + 2 * k1_6 + k2_8] = t139[8 * j1_1 + 4 * j2_4 + 2 * k1_6 + k2_8] + t129[2 * j2_4 + k2_8] * t131[4 * ip1_1 + 2 * j1_1 + k1_6];
            t140[8 * j1_1 + 4 * j2_4 + 2 * k1_6 + k2_8] = t140[8 * j1_1 + 4 * j2_4 + 2 * k1_6 + k2_8] + t130[2 * j2_4 + k2_8] * t131[4 * ip1_1 + 2 * j1_1 + k1_6];
          }
    }
  }
  for (int32_t ip0_0 = 0; ip0_0 <= 1; ++ip0_0)
  {
    for (int32_t ip2_4 = 0; ip2_4 <= 1; ++ip2_4)
    {
      t175[ip2_4] = (double) (0.0);
      t173[ip2_4] = (double) (0.0);
      t171[ip2_4] = (double) (0.0);
      t169[ip2_4] = (double) (0.0);
      t165[ip2_4] = (double) (0.0);
      t162[ip2_4] = (double) (0.0);
      t160[ip2_4] = (double) (0.0);
      t156[ip2_4] = (double) (0.0);
      t152[ip2_4] = (double) (0.0);
    }
    for (int32_t ip1_2 = 0; ip1_2 <= 1; ++ip1_2)
    {
      t141 = -1.0 * t77[2 * ip0_0 + ip1_2];
      t142 = -1.0 * t79[2 * ip0_0 + ip1_2];
      for (int32_t ip2_5 = 0; ip2_5 <= 1; ++ip2_5)
      {
        t143[2 * ip1_2 + ip2_5] = (t77[2 * ip0_0 + ip1_2] * t31[2 * ip1_2 + ip2_5] + -1.0 * t32[2 * ip1_2 + ip2_5] * t78[2 * ip0_0 + ip1_2]) * t86[4 * ip0_0 + 2 * ip1_2 + ip2_5];
        t144 = t143[2 * ip1_2 + ip2_5] * t143[2 * ip1_2 + ip2_5];
        t145[2 * ip1_2 + ip2_5] = (t82[4 * ip0_0 + 2 * ip1_2 + ip2_5] + t31[2 * ip1_2 + ip2_5] * t142) * t86[4 * ip0_0 + 2 * ip1_2 + ip2_5];
        t146 = t145[2 * ip1_2 + ip2_5] * t145[2 * ip1_2 + ip2_5];
        t147 = 0.25 * t146;
        t148[2 * ip1_2 + ip2_5] = (t32[2 * ip1_2 + ip2_5] * t79[2 * ip0_0 + ip1_2] + t30[2 * ip1_2 + ip2_5] * t141) * t86[4 * ip0_0 + 2 * ip1_2 + ip2_5];
        t149 = t148[2 * ip1_2 + ip2_5] * t148[2 * ip1_2 + ip2_5];
        t150 = 0.25 * t149;
        t151[2 * ip1_2 + ip2_5] = t143[2 * ip1_2 + ip2_5] + t143[2 * ip1_2 + ip2_5];
        t152[ip2_5] = t152[ip2_5] + t85[4 * ip0_0 + 2 * ip1_2 + ip2_5] * (t144 + t147 + t150 + t147 + t150 + 0.25 * t151[2 * ip1_2 + ip2_5] * t151[2 * ip1_2 + ip2_5]);
        t153 = t148[2 * ip1_2 + ip2_5] * t143[2 * ip1_2 + ip2_5];
        t154 = t143[2 * ip1_2 + ip2_5] * t148[2 * ip1_2 + ip2_5];
        t155 = 0.25 * t154;
        t156[ip2_5] = t156[ip2_5] + t85[4 * ip0_0 + 2 * ip1_2 + ip2_5] * (t153 + t155 + t155);
        t157 = t145[2 * ip1_2 + ip2_5] * t143[2 * ip1_2 + ip2_5];
        t158 = t143[2 * ip1_2 + ip2_5] * t145[2 * ip1_2 + ip2_5];
        t159 = 0.25 * t158;
        t160[ip2_5] = t160[ip2_5] + t85[4 * ip0_0 + 2 * ip1_2 + ip2_5] * (t157 + t159 + t159);
        t161 = 0.25 * t153;
        t162[ip2_5] = t162[ip2_5] + t85[4 * ip0_0 + 2 * ip1_2 + ip2_5] * (t154 + t161 + t161);
        t163[2 * ip1_2 + ip2_5] = t148[2 * ip1_2 + ip2_5] + t148[2 * ip1_2 + ip2_5];
        t164 = 0.25 * t144;
        t165[ip2_5] = t165[ip2_5] + t85[4 * ip0_0 + 2 * ip1_2 + ip2_5] * (t149 + t147 + t147 + 0.25 * t163[2 * ip1_2 + ip2_5] * t163[2 * ip1_2 + ip2_5] + t164 + t164);
        t166 = t145[2 * ip1_2 + ip2_5] * t148[2 * ip1_2 + ip2_5];
        t167 = t148[2 * ip1_2 + ip2_5] * t145[2 * ip1_2 + ip2_5];
        t168 = 0.25 * t167;
        t169[ip2_5] = t169[ip2_5] + t85[4 * ip0_0 + 2 * ip1_2 + ip2_5] * (t166 + t168 + t168);
        t170 = 0.25 * t157;
        t171[ip2_5] = t171[ip2_5] + t85[4 * ip0_0 + 2 * ip1_2 + ip2_5] * (t158 + t170 + t170);
        t172 = 0.25 * t166;
        t173[ip2_5] = t173[ip2_5] + t85[4 * ip0_0 + 2 * ip1_2 + ip2_5] * (t167 + t172 + t172);
        t174[2 * ip1_2 + ip2_5] = t145[2 * ip1_2 + ip2_5] + t145[2 * ip1_2 + ip2_5];
        t175[ip2_5] = t175[ip2_5] + t85[4 * ip0_0 + 2 * ip1_2 + ip2_5] * (t146 + 0.25 * t174[2 * ip1_2 + ip2_5] * t174[2 * ip1_2 + ip2_5] + t150 + t164 + t150 + t164);
      }
    }
    for (int32_t j2_5 = 0; j2_5 <= 1; ++j2_5)
    {
      for (int32_t k2_9 = 0; k2_9 <= 1; ++k2_9)
      {
        t184[2 * j2_5 + k2_9] = (double) (0.0);
        t183[2 * j2_5 + k2_9] = (double) (0.0);
        t182[2 * j2_5 + k2_9] = (double) (0.0);
        t181[2 * j2_5 + k2_9] = (double) (0.0);
        t180[2 * j2_5 + k2_9] = (double) (0.0);
        t179[2 * j2_5 + k2_9] = (double) (0.0);
        t178[2 * j2_5 + k2_9] = (double) (0.0);
        t177[2 * j2_5 + k2_9] = (double) (0.0);
        t176[2 * j2_5 + k2_9] = (double) (0.0);
      }
      for (int32_t k1_7 = 0; k1_7 <= 1; ++k1_7)
      {
        for (int32_t k2_10 = 0; k2_10 <= 1; ++k2_10)
        {
          t442[4 * j2_5 + 2 * k1_7 + k2_10] = (double) (0.0);
          t441[4 * j2_5 + 2 * k1_7 + k2_10] = (double) (0.0);
          t440[4 * j2_5 + 2 * k1_7 + k2_10] = (double) (0.0);
          t439[4 * j2_5 + 2 * k1_7 + k2_10] = (double) (0.0);
          t438[4 * j2_5 + 2 * k1_7 + k2_10] = (double) (0.0);
          t437[4 * j2_5 + 2 * k1_7 + k2_10] = (double) (0.0);
          t436[4 * j2_5 + 2 * k1_7 + k2_10] = (double) (0.0);
          t435[4 * j2_5 + 2 * k1_7 + k2_10] = (double) (0.0);
          t434[4 * j2_5 + 2 * k1_7 + k2_10] = (double) (0.0);
        }
        t451[2 * j2_5 + k1_7] = (double) (0.0);
        t450[2 * j2_5 + k1_7] = (double) (0.0);
        t449[2 * j2_5 + k1_7] = (double) (0.0);
        t448[2 * j2_5 + k1_7] = (double) (0.0);
        t447[2 * j2_5 + k1_7] = (double) (0.0);
        t446[2 * j2_5 + k1_7] = (double) (0.0);
        t445[2 * j2_5 + k1_7] = (double) (0.0);
        t444[2 * j2_5 + k1_7] = (double) (0.0);
        t443[2 * j2_5 + k1_7] = (double) (0.0);
      }
    }
    for (int32_t j1_2 = 0; j1_2 <= 1; ++j1_2)
    {
      for (int32_t k2_11 = 0; k2_11 <= 1; ++k2_11)
      {
        t460[2 * j1_2 + k2_11] = (double) (0.0);
        t459[2 * j1_2 + k2_11] = (double) (0.0);
        t458[2 * j1_2 + k2_11] = (double) (0.0);
        t457[2 * j1_2 + k2_11] = (double) (0.0);
        t456[2 * j1_2 + k2_11] = (double) (0.0);
        t455[2 * j1_2 + k2_11] = (double) (0.0);
        t454[2 * j1_2 + k2_11] = (double) (0.0);
        t453[2 * j1_2 + k2_11] = (double) (0.0);
        t452[2 * j1_2 + k2_11] = (double) (0.0);
      }
      for (int32_t k1_8 = 0; k1_8 <= 1; ++k1_8)
      {
        for (int32_t k2_12 = 0; k2_12 <= 1; ++k2_12)
        {
          t469[4 * j1_2 + 2 * k1_8 + k2_12] = (double) (0.0);
          t468[4 * j1_2 + 2 * k1_8 + k2_12] = (double) (0.0);
          t467[4 * j1_2 + 2 * k1_8 + k2_12] = (double) (0.0);
          t466[4 * j1_2 + 2 * k1_8 + k2_12] = (double) (0.0);
          t465[4 * j1_2 + 2 * k1_8 + k2_12] = (double) (0.0);
          t464[4 * j1_2 + 2 * k1_8 + k2_12] = (double) (0.0);
          t463[4 * j1_2 + 2 * k1_8 + k2_12] = (double) (0.0);
          t462[4 * j1_2 + 2 * k1_8 + k2_12] = (double) (0.0);
          t461[4 * j1_2 + 2 * k1_8 + k2_12] = (double) (0.0);
        }
        t478[2 * j1_2 + k1_8] = (double) (0.0);
        t477[2 * j1_2 + k1_8] = (double) (0.0);
        t476[2 * j1_2 + k1_8] = (double) (0.0);
        t475[2 * j1_2 + k1_8] = (double) (0.0);
        t474[2 * j1_2 + k1_8] = (double) (0.0);
        t473[2 * j1_2 + k1_8] = (double) (0.0);
        t472[2 * j1_2 + k1_8] = (double) (0.0);
        t471[2 * j1_2 + k1_8] = (double) (0.0);
        t470[2 * j1_2 + k1_8] = (double) (0.0);
      }
      for (int32_t j2_6 = 0; j2_6 <= 1; ++j2_6)
      {
        for (int32_t k2_13 = 0; k2_13 <= 1; ++k2_13)
        {
          t487[4 * j1_2 + 2 * j2_6 + k2_13] = (double) (0.0);
          t486[4 * j1_2 + 2 * j2_6 + k2_13] = (double) (0.0);
          t485[4 * j1_2 + 2 * j2_6 + k2_13] = (double) (0.0);
          t484[4 * j1_2 + 2 * j2_6 + k2_13] = (double) (0.0);
          t483[4 * j1_2 + 2 * j2_6 + k2_13] = (double) (0.0);
          t482[4 * j1_2 + 2 * j2_6 + k2_13] = (double) (0.0);
          t481[4 * j1_2 + 2 * j2_6 + k2_13] = (double) (0.0);
          t480[4 * j1_2 + 2 * j2_6 + k2_13] = (double) (0.0);
          t479[4 * j1_2 + 2 * j2_6 + k2_13] = (double) (0.0);
        }
        for (int32_t k1_9 = 0; k1_9 <= 1; ++k1_9)
        {
          t496[4 * j1_2 + 2 * j2_6 + k1_9] = (double) (0.0);
          t495[4 * j1_2 + 2 * j2_6 + k1_9] = (double) (0.0);
          t494[4 * j1_2 + 2 * j2_6 + k1_9] = (double) (0.0);
          t493[4 * j1_2 + 2 * j2_6 + k1_9] = (double) (0.0);
          t492[4 * j1_2 + 2 * j2_6 + k1_9] = (double) (0.0);
          t491[4 * j1_2 + 2 * j2_6 + k1_9] = (double) (0.0);
          t490[4 * j1_2 + 2 * j2_6 + k1_9] = (double) (0.0);
          t489[4 * j1_2 + 2 * j2_6 + k1_9] = (double) (0.0);
          t488[4 * j1_2 + 2 * j2_6 + k1_9] = (double) (0.0);
        }
      }
    }
    for (int32_t ip2_6 = 0; ip2_6 <= 1; ++ip2_6)
      for (int32_t j2_7 = 0; j2_7 <= 1; ++j2_7)
        for (int32_t k2_14 = 0; k2_14 <= 1; ++k2_14)
        {
          t176[2 * j2_7 + k2_14] = t176[2 * j2_7 + k2_14] + t152[ip2_6] * t120[4 * ip2_6 + 2 * j2_7 + k2_14];
          t177[2 * j2_7 + k2_14] = t177[2 * j2_7 + k2_14] + t156[ip2_6] * t120[4 * ip2_6 + 2 * j2_7 + k2_14];
          t178[2 * j2_7 + k2_14] = t178[2 * j2_7 + k2_14] + t160[ip2_6] * t120[4 * ip2_6 + 2 * j2_7 + k2_14];
          t179[2 * j2_7 + k2_14] = t179[2 * j2_7 + k2_14] + t162[ip2_6] * t120[4 * ip2_6 + 2 * j2_7 + k2_14];
          t180[2 * j2_7 + k2_14] = t180[2 * j2_7 + k2_14] + t165[ip2_6] * t120[4 * ip2_6 + 2 * j2_7 + k2_14];
          t181[2 * j2_7 + k2_14] = t181[2 * j2_7 + k2_14] + t169[ip2_6] * t120[4 * ip2_6 + 2 * j2_7 + k2_14];
          t182[2 * j2_7 + k2_14] = t182[2 * j2_7 + k2_14] + t171[ip2_6] * t120[4 * ip2_6 + 2 * j2_7 + k2_14];
          t183[2 * j2_7 + k2_14] = t183[2 * j2_7 + k2_14] + t173[ip2_6] * t120[4 * ip2_6 + 2 * j2_7 + k2_14];
          t184[2 * j2_7 + k2_14] = t184[2 * j2_7 + k2_14] + t175[ip2_6] * t120[4 * ip2_6 + 2 * j2_7 + k2_14];
        }
    for (int32_t ip1_3 = 0; ip1_3 <= 1; ++ip1_3)
    {
      for (int32_t k2_15 = 0; k2_15 <= 1; ++k2_15)
      {
        t262[k2_15] = (double) (0.0);
        t261[k2_15] = (double) (0.0);
        t260[k2_15] = (double) (0.0);
        t259[k2_15] = (double) (0.0);
        t258[k2_15] = (double) (0.0);
        t257[k2_15] = (double) (0.0);
        t256[k2_15] = (double) (0.0);
        t255[k2_15] = (double) (0.0);
        t254[k2_15] = (double) (0.0);
        t253[k2_15] = (double) (0.0);
        t252[k2_15] = (double) (0.0);
        t251[k2_15] = (double) (0.0);
        t250[k2_15] = (double) (0.0);
        t249[k2_15] = (double) (0.0);
        t248[k2_15] = (double) (0.0);
        t247[k2_15] = (double) (0.0);
        t246[k2_15] = (double) (0.0);
        t245[k2_15] = (double) (0.0);
      }
      t289 = (double) (0.0);
      t288 = (double) (0.0);
      t286 = (double) (0.0);
      t284 = (double) (0.0);
      t280 = (double) (0.0);
      t278 = (double) (0.0);
      t276 = (double) (0.0);
      t272 = (double) (0.0);
      t268 = (double) (0.0);
      for (int32_t j2_8 = 0; j2_8 <= 1; ++j2_8)
      {
        for (int32_t k2_16 = 0; k2_16 <= 1; ++k2_16)
        {
          t415[2 * j2_8 + k2_16] = (double) (0.0);
          t414[2 * j2_8 + k2_16] = (double) (0.0);
          t413[2 * j2_8 + k2_16] = (double) (0.0);
          t412[2 * j2_8 + k2_16] = (double) (0.0);
          t411[2 * j2_8 + k2_16] = (double) (0.0);
          t410[2 * j2_8 + k2_16] = (double) (0.0);
          t409[2 * j2_8 + k2_16] = (double) (0.0);
          t408[2 * j2_8 + k2_16] = (double) (0.0);
          t407[2 * j2_8 + k2_16] = (double) (0.0);
          t406[2 * j2_8 + k2_16] = (double) (0.0);
          t405[2 * j2_8 + k2_16] = (double) (0.0);
          t404[2 * j2_8 + k2_16] = (double) (0.0);
          t403[2 * j2_8 + k2_16] = (double) (0.0);
          t402[2 * j2_8 + k2_16] = (double) (0.0);
          t401[2 * j2_8 + k2_16] = (double) (0.0);
          t400[2 * j2_8 + k2_16] = (double) (0.0);
          t399[2 * j2_8 + k2_16] = (double) (0.0);
          t398[2 * j2_8 + k2_16] = (double) (0.0);
        }
        t433[j2_8] = (double) (0.0);
        t432[j2_8] = (double) (0.0);
        t431[j2_8] = (double) (0.0);
        t430[j2_8] = (double) (0.0);
        t429[j2_8] = (double) (0.0);
        t428[j2_8] = (double) (0.0);
        t427[j2_8] = (double) (0.0);
        t426[j2_8] = (double) (0.0);
        t425[j2_8] = (double) (0.0);
        t424[j2_8] = (double) (0.0);
        t423[j2_8] = (double) (0.0);
        t422[j2_8] = (double) (0.0);
        t421[j2_8] = (double) (0.0);
        t420[j2_8] = (double) (0.0);
        t419[j2_8] = (double) (0.0);
        t418[j2_8] = (double) (0.0);
        t417[j2_8] = (double) (0.0);
        t416[j2_8] = (double) (0.0);
      }
      for (int32_t ip2_7 = 0; ip2_7 <= 1; ++ip2_7)
      {
        t185 = t83[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t86[4 * ip0_0 + 2 * ip1_3 + ip2_7];
        t186 = t89[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t185;
        t187 = t185 + t185;
        t188 = (t73[2 * ip0_0 + ip2_7] * t30[2 * ip1_3 + ip2_7] + -1.0 * t32[2 * ip1_3 + ip2_7] * t75[2 * ip0_0 + ip2_7]) * t86[4 * ip0_0 + 2 * ip1_3 + ip2_7];
        t189 = t92[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t188;
        t190 = 0.25 * t189;
        t191 = (t32[2 * ip1_3 + ip2_7] * t76[2 * ip0_0 + ip2_7] + -1.0 * t73[2 * ip0_0 + ip2_7] * t31[2 * ip1_3 + ip2_7]) * t86[4 * ip0_0 + 2 * ip1_3 + ip2_7];
        t192 = t87[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t191;
        t193 = 0.25 * t192;
        t194 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t186 + 0.25 * t118[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t187 + t190 + t193 + t190 + t193);
        t195 = t92[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t185;
        t196 = t89[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t188;
        t197 = 0.25 * t196;
        t198 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t195 + t197 + t197);
        t199 = t87[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t185;
        t200 = t89[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t191;
        t201 = 0.25 * t200;
        t202 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t199 + t201 + t201);
        t203 = 0.25 * t195;
        t204 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t196 + t203 + t203);
        t205 = 0.25 * t186;
        t206 = t188 + t188;
        t207 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t189 + t205 + t205 + 0.25 * t107[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t206 + t193 + t193);
        t208 = t87[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t188;
        t209 = t92[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t191;
        t210 = 0.25 * t209;
        t211 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t208 + t210 + t210);
        t212 = 0.25 * t199;
        t213 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t200 + t212 + t212);
        t214 = 0.25 * t208;
        t215 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t209 + t214 + t214);
        t216 = t191 + t191;
        t217 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t192 + t205 + t190 + t205 + t190 + 0.25 * t95[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t216);
        t218 = t145[2 * ip1_3 + ip2_7] * t185;
        t219 = t148[2 * ip1_3 + ip2_7] * t188;
        t220 = 0.25 * t219;
        t221 = t143[2 * ip1_3 + ip2_7] * t191;
        t222 = 0.25 * t221;
        t223 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t218 + 0.25 * t174[2 * ip1_3 + ip2_7] * t187 + t220 + t222 + t220 + t222);
        t224 = t148[2 * ip1_3 + ip2_7] * t185;
        t225 = t145[2 * ip1_3 + ip2_7] * t188;
        t226 = 0.25 * t225;
        t227 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t224 + t226 + t226);
        t228 = t143[2 * ip1_3 + ip2_7] * t185;
        t229 = t145[2 * ip1_3 + ip2_7] * t191;
        t230 = 0.25 * t229;
        t231 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t228 + t230 + t230);
        t232 = 0.25 * t224;
        t233 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t225 + t232 + t232);
        t234 = 0.25 * t218;
        t235 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t219 + t234 + t234 + 0.25 * t163[2 * ip1_3 + ip2_7] * t206 + t222 + t222);
        t236 = t143[2 * ip1_3 + ip2_7] * t188;
        t237 = t148[2 * ip1_3 + ip2_7] * t191;
        t238 = 0.25 * t237;
        t239 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t236 + t238 + t238);
        t240 = 0.25 * t228;
        t241 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t229 + t240 + t240);
        t242 = 0.25 * t236;
        t243 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t237 + t242 + t242);
        t244 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t221 + t234 + t220 + t234 + t220 + 0.25 * t151[2 * ip1_3 + ip2_7] * t216);
        for (int32_t k2_17 = 0; k2_17 <= 1; ++k2_17)
        {
          t245[k2_17] = t245[k2_17] + t33[ip2_7 + 2 * k2_17] * t244;
          t246[k2_17] = t246[k2_17] + t33[ip2_7 + 2 * k2_17] * t243;
          t247[k2_17] = t247[k2_17] + t33[ip2_7 + 2 * k2_17] * t241;
          t248[k2_17] = t248[k2_17] + t33[ip2_7 + 2 * k2_17] * t239;
          t249[k2_17] = t249[k2_17] + t33[ip2_7 + 2 * k2_17] * t235;
          t250[k2_17] = t250[k2_17] + t33[ip2_7 + 2 * k2_17] * t233;
          t251[k2_17] = t251[k2_17] + t33[ip2_7 + 2 * k2_17] * t231;
          t252[k2_17] = t252[k2_17] + t33[ip2_7 + 2 * k2_17] * t227;
          t253[k2_17] = t253[k2_17] + t33[ip2_7 + 2 * k2_17] * t223;
          t254[k2_17] = t254[k2_17] + t33[ip2_7 + 2 * k2_17] * t217;
          t255[k2_17] = t255[k2_17] + t33[ip2_7 + 2 * k2_17] * t215;
          t256[k2_17] = t256[k2_17] + t33[ip2_7 + 2 * k2_17] * t213;
          t257[k2_17] = t257[k2_17] + t33[ip2_7 + 2 * k2_17] * t211;
          t258[k2_17] = t258[k2_17] + t33[ip2_7 + 2 * k2_17] * t207;
          t259[k2_17] = t259[k2_17] + t33[ip2_7 + 2 * k2_17] * t204;
          t260[k2_17] = t260[k2_17] + t33[ip2_7 + 2 * k2_17] * t202;
          t261[k2_17] = t261[k2_17] + t33[ip2_7 + 2 * k2_17] * t198;
          t262[k2_17] = t262[k2_17] + t33[ip2_7 + 2 * k2_17] * t194;
        }
        t263 = t191 * t191;
        t264 = t185 * t185;
        t265 = 0.25 * t264;
        t266 = t188 * t188;
        t267 = 0.25 * t266;
        t268 = t268 + t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t263 + t265 + t267 + t265 + t267 + 0.25 * t216 * t216);
        t269 = t188 * t191;
        t270 = t191 * t188;
        t271 = 0.25 * t270;
        t272 = t272 + t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t269 + t271 + t271);
        t273 = t185 * t191;
        t274 = t191 * t185;
        t275 = 0.25 * t274;
        t276 = t276 + t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t273 + t275 + t275);
        t277 = 0.25 * t269;
        t278 = t278 + t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t270 + t277 + t277);
        t279 = 0.25 * t263;
        t280 = t280 + t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t266 + t265 + t265 + 0.25 * t206 * t206 + t279 + t279);
        t281 = t185 * t188;
        t282 = t188 * t185;
        t283 = 0.25 * t282;
        t284 = t284 + t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t281 + t283 + t283);
        t285 = 0.25 * t273;
        t286 = t286 + t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t274 + t285 + t285);
        t287 = 0.25 * t281;
        t288 = t288 + t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t282 + t287 + t287);
        t289 = t289 + t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t264 + 0.25 * t187 * t187 + t267 + t279 + t267 + t279);
        t290 = t185 * t89[4 * ip0_0 + 2 * ip1_3 + ip2_7];
        t291 = t188 * t92[4 * ip0_0 + 2 * ip1_3 + ip2_7];
        t292 = 0.25 * t291;
        t293 = t191 * t87[4 * ip0_0 + 2 * ip1_3 + ip2_7];
        t294 = 0.25 * t293;
        t295 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t290 + 0.25 * t187 * t118[4 * ip0_0 + 2 * ip1_3 + ip2_7] + t292 + t294 + t292 + t294);
        t296 = t188 * t89[4 * ip0_0 + 2 * ip1_3 + ip2_7];
        t297 = t185 * t92[4 * ip0_0 + 2 * ip1_3 + ip2_7];
        t298 = 0.25 * t297;
        t299 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t296 + t298 + t298);
        t300 = t191 * t89[4 * ip0_0 + 2 * ip1_3 + ip2_7];
        t301 = t185 * t87[4 * ip0_0 + 2 * ip1_3 + ip2_7];
        t302 = 0.25 * t301;
        t303 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t300 + t302 + t302);
        t304 = 0.25 * t296;
        t305 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t297 + t304 + t304);
        t306 = 0.25 * t290;
        t307 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t291 + t306 + t306 + 0.25 * t206 * t107[4 * ip0_0 + 2 * ip1_3 + ip2_7] + t294 + t294);
        t308 = t191 * t92[4 * ip0_0 + 2 * ip1_3 + ip2_7];
        t309 = t188 * t87[4 * ip0_0 + 2 * ip1_3 + ip2_7];
        t310 = 0.25 * t309;
        t311 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t308 + t310 + t310);
        t312 = 0.25 * t300;
        t313 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t301 + t312 + t312);
        t314 = 0.25 * t308;
        t315 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t309 + t314 + t314);
        t316 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t293 + t306 + t292 + t306 + t292 + 0.25 * t216 * t95[4 * ip0_0 + 2 * ip1_3 + ip2_7]);
        t317 = t185 * t145[2 * ip1_3 + ip2_7];
        t318 = t188 * t148[2 * ip1_3 + ip2_7];
        t319 = 0.25 * t318;
        t320 = t191 * t143[2 * ip1_3 + ip2_7];
        t321 = 0.25 * t320;
        t322 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t317 + 0.25 * t187 * t174[2 * ip1_3 + ip2_7] + t319 + t321 + t319 + t321);
        t323 = t188 * t145[2 * ip1_3 + ip2_7];
        t324 = t185 * t148[2 * ip1_3 + ip2_7];
        t325 = 0.25 * t324;
        t326 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t323 + t325 + t325);
        t327 = t191 * t145[2 * ip1_3 + ip2_7];
        t328 = t185 * t143[2 * ip1_3 + ip2_7];
        t329 = 0.25 * t328;
        t330 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t327 + t329 + t329);
        t331 = 0.25 * t323;
        t332 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t324 + t331 + t331);
        t333 = 0.25 * t317;
        t334 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t318 + t333 + t333 + 0.25 * t206 * t163[2 * ip1_3 + ip2_7] + t321 + t321);
        t335 = t191 * t148[2 * ip1_3 + ip2_7];
        t336 = t188 * t143[2 * ip1_3 + ip2_7];
        t337 = 0.25 * t336;
        t338 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t335 + t337 + t337);
        t339 = 0.25 * t327;
        t340 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t328 + t339 + t339);
        t341 = 0.25 * t335;
        t342 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t336 + t341 + t341);
        t343 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t320 + t333 + t319 + t333 + t319 + 0.25 * t216 * t151[2 * ip1_3 + ip2_7]);
        t344 = t145[2 * ip1_3 + ip2_7] * t89[4 * ip0_0 + 2 * ip1_3 + ip2_7];
        t345 = t148[2 * ip1_3 + ip2_7] * t92[4 * ip0_0 + 2 * ip1_3 + ip2_7];
        t346 = 0.25 * t345;
        t347 = t143[2 * ip1_3 + ip2_7] * t87[4 * ip0_0 + 2 * ip1_3 + ip2_7];
        t348 = 0.25 * t347;
        t349 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t344 + 0.25 * t174[2 * ip1_3 + ip2_7] * t118[4 * ip0_0 + 2 * ip1_3 + ip2_7] + t346 + t348 + t346 + t348);
        t350 = t148[2 * ip1_3 + ip2_7] * t89[4 * ip0_0 + 2 * ip1_3 + ip2_7];
        t351 = t145[2 * ip1_3 + ip2_7] * t92[4 * ip0_0 + 2 * ip1_3 + ip2_7];
        t352 = 0.25 * t351;
        t353 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t350 + t352 + t352);
        t354 = t143[2 * ip1_3 + ip2_7] * t89[4 * ip0_0 + 2 * ip1_3 + ip2_7];
        t355 = t145[2 * ip1_3 + ip2_7] * t87[4 * ip0_0 + 2 * ip1_3 + ip2_7];
        t356 = 0.25 * t355;
        t357 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t354 + t356 + t356);
        t358 = 0.25 * t350;
        t359 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t351 + t358 + t358);
        t360 = 0.25 * t344;
        t361 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t345 + t360 + t360 + 0.25 * t163[2 * ip1_3 + ip2_7] * t107[4 * ip0_0 + 2 * ip1_3 + ip2_7] + t348 + t348);
        t362 = t143[2 * ip1_3 + ip2_7] * t92[4 * ip0_0 + 2 * ip1_3 + ip2_7];
        t363 = t148[2 * ip1_3 + ip2_7] * t87[4 * ip0_0 + 2 * ip1_3 + ip2_7];
        t364 = 0.25 * t363;
        t365 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t362 + t364 + t364);
        t366 = 0.25 * t354;
        t367 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t355 + t366 + t366);
        t368 = 0.25 * t362;
        t369 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t363 + t368 + t368);
        t370 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t347 + t360 + t346 + t360 + t346 + 0.25 * t151[2 * ip1_3 + ip2_7] * t95[4 * ip0_0 + 2 * ip1_3 + ip2_7]);
        t371 = t89[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t145[2 * ip1_3 + ip2_7];
        t372 = t92[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t148[2 * ip1_3 + ip2_7];
        t373 = 0.25 * t372;
        t374 = t87[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t143[2 * ip1_3 + ip2_7];
        t375 = 0.25 * t374;
        t376 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t371 + 0.25 * t118[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t174[2 * ip1_3 + ip2_7] + t373 + t375 + t373 + t375);
        t377 = t92[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t145[2 * ip1_3 + ip2_7];
        t378 = t89[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t148[2 * ip1_3 + ip2_7];
        t379 = 0.25 * t378;
        t380 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t377 + t379 + t379);
        t381 = t87[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t145[2 * ip1_3 + ip2_7];
        t382 = t89[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t143[2 * ip1_3 + ip2_7];
        t383 = 0.25 * t382;
        t384 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t381 + t383 + t383);
        t385 = 0.25 * t377;
        t386 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t378 + t385 + t385);
        t387 = 0.25 * t371;
        t388 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t372 + t387 + t387 + 0.25 * t107[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t163[2 * ip1_3 + ip2_7] + t375 + t375);
        t389 = t87[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t148[2 * ip1_3 + ip2_7];
        t390 = t92[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t143[2 * ip1_3 + ip2_7];
        t391 = 0.25 * t390;
        t392 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t389 + t391 + t391);
        t393 = 0.25 * t381;
        t394 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t382 + t393 + t393);
        t395 = 0.25 * t389;
        t396 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t390 + t395 + t395);
        t397 = t85[4 * ip0_0 + 2 * ip1_3 + ip2_7] * (t374 + t387 + t373 + t387 + t373 + 0.25 * t95[4 * ip0_0 + 2 * ip1_3 + ip2_7] * t151[2 * ip1_3 + ip2_7]);
        for (int32_t j2_9 = 0; j2_9 <= 1; ++j2_9)
        {
          for (int32_t k2_18 = 0; k2_18 <= 1; ++k2_18)
          {
            t398[2 * j2_9 + k2_18] = t398[2 * j2_9 + k2_18] + t397 * t120[4 * ip2_7 + 2 * j2_9 + k2_18];
            t399[2 * j2_9 + k2_18] = t399[2 * j2_9 + k2_18] + t396 * t120[4 * ip2_7 + 2 * j2_9 + k2_18];
            t400[2 * j2_9 + k2_18] = t400[2 * j2_9 + k2_18] + t394 * t120[4 * ip2_7 + 2 * j2_9 + k2_18];
            t401[2 * j2_9 + k2_18] = t401[2 * j2_9 + k2_18] + t392 * t120[4 * ip2_7 + 2 * j2_9 + k2_18];
            t402[2 * j2_9 + k2_18] = t402[2 * j2_9 + k2_18] + t388 * t120[4 * ip2_7 + 2 * j2_9 + k2_18];
            t403[2 * j2_9 + k2_18] = t403[2 * j2_9 + k2_18] + t386 * t120[4 * ip2_7 + 2 * j2_9 + k2_18];
            t404[2 * j2_9 + k2_18] = t404[2 * j2_9 + k2_18] + t384 * t120[4 * ip2_7 + 2 * j2_9 + k2_18];
            t405[2 * j2_9 + k2_18] = t405[2 * j2_9 + k2_18] + t380 * t120[4 * ip2_7 + 2 * j2_9 + k2_18];
            t406[2 * j2_9 + k2_18] = t406[2 * j2_9 + k2_18] + t376 * t120[4 * ip2_7 + 2 * j2_9 + k2_18];
            t407[2 * j2_9 + k2_18] = t407[2 * j2_9 + k2_18] + t370 * t120[4 * ip2_7 + 2 * j2_9 + k2_18];
            t408[2 * j2_9 + k2_18] = t408[2 * j2_9 + k2_18] + t369 * t120[4 * ip2_7 + 2 * j2_9 + k2_18];
            t409[2 * j2_9 + k2_18] = t409[2 * j2_9 + k2_18] + t367 * t120[4 * ip2_7 + 2 * j2_9 + k2_18];
            t410[2 * j2_9 + k2_18] = t410[2 * j2_9 + k2_18] + t365 * t120[4 * ip2_7 + 2 * j2_9 + k2_18];
            t411[2 * j2_9 + k2_18] = t411[2 * j2_9 + k2_18] + t361 * t120[4 * ip2_7 + 2 * j2_9 + k2_18];
            t412[2 * j2_9 + k2_18] = t412[2 * j2_9 + k2_18] + t359 * t120[4 * ip2_7 + 2 * j2_9 + k2_18];
            t413[2 * j2_9 + k2_18] = t413[2 * j2_9 + k2_18] + t357 * t120[4 * ip2_7 + 2 * j2_9 + k2_18];
            t414[2 * j2_9 + k2_18] = t414[2 * j2_9 + k2_18] + t353 * t120[4 * ip2_7 + 2 * j2_9 + k2_18];
            t415[2 * j2_9 + k2_18] = t415[2 * j2_9 + k2_18] + t349 * t120[4 * ip2_7 + 2 * j2_9 + k2_18];
          }
          t416[j2_9] = t416[j2_9] + t33[ip2_7 + 2 * j2_9] * t343;
          t417[j2_9] = t417[j2_9] + t33[ip2_7 + 2 * j2_9] * t342;
          t418[j2_9] = t418[j2_9] + t33[ip2_7 + 2 * j2_9] * t340;
          t419[j2_9] = t419[j2_9] + t33[ip2_7 + 2 * j2_9] * t338;
          t420[j2_9] = t420[j2_9] + t33[ip2_7 + 2 * j2_9] * t334;
          t421[j2_9] = t421[j2_9] + t33[ip2_7 + 2 * j2_9] * t332;
          t422[j2_9] = t422[j2_9] + t33[ip2_7 + 2 * j2_9] * t330;
          t423[j2_9] = t423[j2_9] + t33[ip2_7 + 2 * j2_9] * t326;
          t424[j2_9] = t424[j2_9] + t33[ip2_7 + 2 * j2_9] * t322;
          t425[j2_9] = t425[j2_9] + t33[ip2_7 + 2 * j2_9] * t316;
          t426[j2_9] = t426[j2_9] + t33[ip2_7 + 2 * j2_9] * t315;
          t427[j2_9] = t427[j2_9] + t33[ip2_7 + 2 * j2_9] * t313;
          t428[j2_9] = t428[j2_9] + t33[ip2_7 + 2 * j2_9] * t311;
          t429[j2_9] = t429[j2_9] + t33[ip2_7 + 2 * j2_9] * t307;
          t430[j2_9] = t430[j2_9] + t33[ip2_7 + 2 * j2_9] * t305;
          t431[j2_9] = t431[j2_9] + t33[ip2_7 + 2 * j2_9] * t303;
          t432[j2_9] = t432[j2_9] + t33[ip2_7 + 2 * j2_9] * t299;
          t433[j2_9] = t433[j2_9] + t33[ip2_7 + 2 * j2_9] * t295;
        }
      }
      for (int32_t j2_10 = 0; j2_10 <= 1; ++j2_10)
        for (int32_t k1_10 = 0; k1_10 <= 1; ++k1_10)
        {
          for (int32_t k2_19 = 0; k2_19 <= 1; ++k2_19)
          {
            t434[4 * j2_10 + 2 * k1_10 + k2_19] = t434[4 * j2_10 + 2 * k1_10 + k2_19] + t33[ip1_3 + 2 * k1_10] * t398[2 * j2_10 + k2_19];
            t435[4 * j2_10 + 2 * k1_10 + k2_19] = t435[4 * j2_10 + 2 * k1_10 + k2_19] + t33[ip1_3 + 2 * k1_10] * t399[2 * j2_10 + k2_19];
            t436[4 * j2_10 + 2 * k1_10 + k2_19] = t436[4 * j2_10 + 2 * k1_10 + k2_19] + t33[ip1_3 + 2 * k1_10] * t400[2 * j2_10 + k2_19];
            t437[4 * j2_10 + 2 * k1_10 + k2_19] = t437[4 * j2_10 + 2 * k1_10 + k2_19] + t33[ip1_3 + 2 * k1_10] * t401[2 * j2_10 + k2_19];
            t438[4 * j2_10 + 2 * k1_10 + k2_19] = t438[4 * j2_10 + 2 * k1_10 + k2_19] + t33[ip1_3 + 2 * k1_10] * t402[2 * j2_10 + k2_19];
            t439[4 * j2_10 + 2 * k1_10 + k2_19] = t439[4 * j2_10 + 2 * k1_10 + k2_19] + t33[ip1_3 + 2 * k1_10] * t403[2 * j2_10 + k2_19];
            t440[4 * j2_10 + 2 * k1_10 + k2_19] = t440[4 * j2_10 + 2 * k1_10 + k2_19] + t33[ip1_3 + 2 * k1_10] * t404[2 * j2_10 + k2_19];
            t441[4 * j2_10 + 2 * k1_10 + k2_19] = t441[4 * j2_10 + 2 * k1_10 + k2_19] + t33[ip1_3 + 2 * k1_10] * t405[2 * j2_10 + k2_19];
            t442[4 * j2_10 + 2 * k1_10 + k2_19] = t442[4 * j2_10 + 2 * k1_10 + k2_19] + t33[ip1_3 + 2 * k1_10] * t406[2 * j2_10 + k2_19];
          }
          t443[2 * j2_10 + k1_10] = t443[2 * j2_10 + k1_10] + t33[ip1_3 + 2 * k1_10] * t416[j2_10];
          t444[2 * j2_10 + k1_10] = t444[2 * j2_10 + k1_10] + t33[ip1_3 + 2 * k1_10] * t417[j2_10];
          t445[2 * j2_10 + k1_10] = t445[2 * j2_10 + k1_10] + t33[ip1_3 + 2 * k1_10] * t418[j2_10];
          t446[2 * j2_10 + k1_10] = t446[2 * j2_10 + k1_10] + t33[ip1_3 + 2 * k1_10] * t419[j2_10];
          t447[2 * j2_10 + k1_10] = t447[2 * j2_10 + k1_10] + t33[ip1_3 + 2 * k1_10] * t420[j2_10];
          t448[2 * j2_10 + k1_10] = t448[2 * j2_10 + k1_10] + t33[ip1_3 + 2 * k1_10] * t421[j2_10];
          t449[2 * j2_10 + k1_10] = t449[2 * j2_10 + k1_10] + t33[ip1_3 + 2 * k1_10] * t422[j2_10];
          t450[2 * j2_10 + k1_10] = t450[2 * j2_10 + k1_10] + t33[ip1_3 + 2 * k1_10] * t423[j2_10];
          t451[2 * j2_10 + k1_10] = t451[2 * j2_10 + k1_10] + t33[ip1_3 + 2 * k1_10] * t424[j2_10];
        }
      for (int32_t j1_3 = 0; j1_3 <= 1; ++j1_3)
      {
        for (int32_t k2_20 = 0; k2_20 <= 1; ++k2_20)
        {
          t452[2 * j1_3 + k2_20] = t452[2 * j1_3 + k2_20] + t33[ip1_3 + 2 * j1_3] * t245[k2_20];
          t453[2 * j1_3 + k2_20] = t453[2 * j1_3 + k2_20] + t33[ip1_3 + 2 * j1_3] * t246[k2_20];
          t454[2 * j1_3 + k2_20] = t454[2 * j1_3 + k2_20] + t33[ip1_3 + 2 * j1_3] * t247[k2_20];
          t455[2 * j1_3 + k2_20] = t455[2 * j1_3 + k2_20] + t33[ip1_3 + 2 * j1_3] * t248[k2_20];
          t456[2 * j1_3 + k2_20] = t456[2 * j1_3 + k2_20] + t33[ip1_3 + 2 * j1_3] * t249[k2_20];
          t457[2 * j1_3 + k2_20] = t457[2 * j1_3 + k2_20] + t33[ip1_3 + 2 * j1_3] * t250[k2_20];
          t458[2 * j1_3 + k2_20] = t458[2 * j1_3 + k2_20] + t33[ip1_3 + 2 * j1_3] * t251[k2_20];
          t459[2 * j1_3 + k2_20] = t459[2 * j1_3 + k2_20] + t33[ip1_3 + 2 * j1_3] * t252[k2_20];
          t460[2 * j1_3 + k2_20] = t460[2 * j1_3 + k2_20] + t33[ip1_3 + 2 * j1_3] * t253[k2_20];
        }
        for (int32_t k1_11 = 0; k1_11 <= 1; ++k1_11)
        {
          for (int32_t k2_21 = 0; k2_21 <= 1; ++k2_21)
          {
            t461[4 * j1_3 + 2 * k1_11 + k2_21] = t461[4 * j1_3 + 2 * k1_11 + k2_21] + t254[k2_21] * t131[4 * ip1_3 + 2 * j1_3 + k1_11];
            t462[4 * j1_3 + 2 * k1_11 + k2_21] = t462[4 * j1_3 + 2 * k1_11 + k2_21] + t255[k2_21] * t131[4 * ip1_3 + 2 * j1_3 + k1_11];
            t463[4 * j1_3 + 2 * k1_11 + k2_21] = t463[4 * j1_3 + 2 * k1_11 + k2_21] + t256[k2_21] * t131[4 * ip1_3 + 2 * j1_3 + k1_11];
            t464[4 * j1_3 + 2 * k1_11 + k2_21] = t464[4 * j1_3 + 2 * k1_11 + k2_21] + t257[k2_21] * t131[4 * ip1_3 + 2 * j1_3 + k1_11];
            t465[4 * j1_3 + 2 * k1_11 + k2_21] = t465[4 * j1_3 + 2 * k1_11 + k2_21] + t258[k2_21] * t131[4 * ip1_3 + 2 * j1_3 + k1_11];
            t466[4 * j1_3 + 2 * k1_11 + k2_21] = t466[4 * j1_3 + 2 * k1_11 + k2_21] + t259[k2_21] * t131[4 * ip1_3 + 2 * j1_3 + k1_11];
            t467[4 * j1_3 + 2 * k1_11 + k2_21] = t467[4 * j1_3 + 2 * k1_11 + k2_21] + t260[k2_21] * t131[4 * ip1_3 + 2 * j1_3 + k1_11];
            t468[4 * j1_3 + 2 * k1_11 + k2_21] = t468[4 * j1_3 + 2 * k1_11 + k2_21] + t261[k2_21] * t131[4 * ip1_3 + 2 * j1_3 + k1_11];
            t469[4 * j1_3 + 2 * k1_11 + k2_21] = t469[4 * j1_3 + 2 * k1_11 + k2_21] + t262[k2_21] * t131[4 * ip1_3 + 2 * j1_3 + k1_11];
          }
          t470[2 * j1_3 + k1_11] = t470[2 * j1_3 + k1_11] + t268 * t131[4 * ip1_3 + 2 * j1_3 + k1_11];
          t471[2 * j1_3 + k1_11] = t471[2 * j1_3 + k1_11] + t272 * t131[4 * ip1_3 + 2 * j1_3 + k1_11];
          t472[2 * j1_3 + k1_11] = t472[2 * j1_3 + k1_11] + t276 * t131[4 * ip1_3 + 2 * j1_3 + k1_11];
          t473[2 * j1_3 + k1_11] = t473[2 * j1_3 + k1_11] + t278 * t131[4 * ip1_3 + 2 * j1_3 + k1_11];
          t474[2 * j1_3 + k1_11] = t474[2 * j1_3 + k1_11] + t280 * t131[4 * ip1_3 + 2 * j1_3 + k1_11];
          t475[2 * j1_3 + k1_11] = t475[2 * j1_3 + k1_11] + t284 * t131[4 * ip1_3 + 2 * j1_3 + k1_11];
          t476[2 * j1_3 + k1_11] = t476[2 * j1_3 + k1_11] + t286 * t131[4 * ip1_3 + 2 * j1_3 + k1_11];
          t477[2 * j1_3 + k1_11] = t477[2 * j1_3 + k1_11] + t288 * t131[4 * ip1_3 + 2 * j1_3 + k1_11];
          t478[2 * j1_3 + k1_11] = t478[2 * j1_3 + k1_11] + t289 * t131[4 * ip1_3 + 2 * j1_3 + k1_11];
        }
        for (int32_t j2_11 = 0; j2_11 <= 1; ++j2_11)
        {
          for (int32_t k2_22 = 0; k2_22 <= 1; ++k2_22)
          {
            t479[4 * j1_3 + 2 * j2_11 + k2_22] = t479[4 * j1_3 + 2 * j2_11 + k2_22] + t33[ip1_3 + 2 * j1_3] * t407[2 * j2_11 + k2_22];
            t480[4 * j1_3 + 2 * j2_11 + k2_22] = t480[4 * j1_3 + 2 * j2_11 + k2_22] + t33[ip1_3 + 2 * j1_3] * t408[2 * j2_11 + k2_22];
            t481[4 * j1_3 + 2 * j2_11 + k2_22] = t481[4 * j1_3 + 2 * j2_11 + k2_22] + t33[ip1_3 + 2 * j1_3] * t409[2 * j2_11 + k2_22];
            t482[4 * j1_3 + 2 * j2_11 + k2_22] = t482[4 * j1_3 + 2 * j2_11 + k2_22] + t33[ip1_3 + 2 * j1_3] * t410[2 * j2_11 + k2_22];
            t483[4 * j1_3 + 2 * j2_11 + k2_22] = t483[4 * j1_3 + 2 * j2_11 + k2_22] + t33[ip1_3 + 2 * j1_3] * t411[2 * j2_11 + k2_22];
            t484[4 * j1_3 + 2 * j2_11 + k2_22] = t484[4 * j1_3 + 2 * j2_11 + k2_22] + t33[ip1_3 + 2 * j1_3] * t412[2 * j2_11 + k2_22];
            t485[4 * j1_3 + 2 * j2_11 + k2_22] = t485[4 * j1_3 + 2 * j2_11 + k2_22] + t33[ip1_3 + 2 * j1_3] * t413[2 * j2_11 + k2_22];
            t486[4 * j1_3 + 2 * j2_11 + k2_22] = t486[4 * j1_3 + 2 * j2_11 + k2_22] + t33[ip1_3 + 2 * j1_3] * t414[2 * j2_11 + k2_22];
            t487[4 * j1_3 + 2 * j2_11 + k2_22] = t487[4 * j1_3 + 2 * j2_11 + k2_22] + t33[ip1_3 + 2 * j1_3] * t415[2 * j2_11 + k2_22];
          }
          for (int32_t k1_12 = 0; k1_12 <= 1; ++k1_12)
          {
            t488[4 * j1_3 + 2 * j2_11 + k1_12] = t488[4 * j1_3 + 2 * j2_11 + k1_12] + t425[j2_11] * t131[4 * ip1_3 + 2 * j1_3 + k1_12];
            t489[4 * j1_3 + 2 * j2_11 + k1_12] = t489[4 * j1_3 + 2 * j2_11 + k1_12] + t426[j2_11] * t131[4 * ip1_3 + 2 * j1_3 + k1_12];
            t490[4 * j1_3 + 2 * j2_11 + k1_12] = t490[4 * j1_3 + 2 * j2_11 + k1_12] + t427[j2_11] * t131[4 * ip1_3 + 2 * j1_3 + k1_12];
            t491[4 * j1_3 + 2 * j2_11 + k1_12] = t491[4 * j1_3 + 2 * j2_11 + k1_12] + t428[j2_11] * t131[4 * ip1_3 + 2 * j1_3 + k1_12];
            t492[4 * j1_3 + 2 * j2_11 + k1_12] = t492[4 * j1_3 + 2 * j2_11 + k1_12] + t429[j2_11] * t131[4 * ip1_3 + 2 * j1_3 + k1_12];
            t493[4 * j1_3 + 2 * j2_11 + k1_12] = t493[4 * j1_3 + 2 * j2_11 + k1_12] + t430[j2_11] * t131[4 * ip1_3 + 2 * j1_3 + k1_12];
            t494[4 * j1_3 + 2 * j2_11 + k1_12] = t494[4 * j1_3 + 2 * j2_11 + k1_12] + t431[j2_11] * t131[4 * ip1_3 + 2 * j1_3 + k1_12];
            t495[4 * j1_3 + 2 * j2_11 + k1_12] = t495[4 * j1_3 + 2 * j2_11 + k1_12] + t432[j2_11] * t131[4 * ip1_3 + 2 * j1_3 + k1_12];
            t496[4 * j1_3 + 2 * j2_11 + k1_12] = t496[4 * j1_3 + 2 * j2_11 + k1_12] + t433[j2_11] * t131[4 * ip1_3 + 2 * j1_3 + k1_12];
          }
        }
      }
    }
    for (int32_t j1_4 = 0; j1_4 <= 1; ++j1_4)
      for (int32_t j2_12 = 0; j2_12 <= 1; ++j2_12)
        for (int32_t k0_2 = 0; k0_2 <= 1; ++k0_2)
        {
          for (int32_t k2_23 = 0; k2_23 <= 1; ++k2_23)
          {
            t497[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k2_23] = t497[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k2_23] + t33[ip0_0 + 2 * k0_2] * t479[4 * j1_4 + 2 * j2_12 + k2_23];
            t498[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k2_23] = t498[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k2_23] + t33[ip0_0 + 2 * k0_2] * t480[4 * j1_4 + 2 * j2_12 + k2_23];
            t499[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k2_23] = t499[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k2_23] + t33[ip0_0 + 2 * k0_2] * t481[4 * j1_4 + 2 * j2_12 + k2_23];
            t500[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k2_23] = t500[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k2_23] + t33[ip0_0 + 2 * k0_2] * t482[4 * j1_4 + 2 * j2_12 + k2_23];
            t501[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k2_23] = t501[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k2_23] + t33[ip0_0 + 2 * k0_2] * t483[4 * j1_4 + 2 * j2_12 + k2_23];
            t502[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k2_23] = t502[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k2_23] + t33[ip0_0 + 2 * k0_2] * t484[4 * j1_4 + 2 * j2_12 + k2_23];
            t503[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k2_23] = t503[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k2_23] + t33[ip0_0 + 2 * k0_2] * t485[4 * j1_4 + 2 * j2_12 + k2_23];
            t504[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k2_23] = t504[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k2_23] + t33[ip0_0 + 2 * k0_2] * t486[4 * j1_4 + 2 * j2_12 + k2_23];
            t505[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k2_23] = t505[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k2_23] + t33[ip0_0 + 2 * k0_2] * t487[4 * j1_4 + 2 * j2_12 + k2_23];
          }
          for (int32_t k1_13 = 0; k1_13 <= 1; ++k1_13)
          {
            t506[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k1_13] = t506[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k1_13] + t33[ip0_0 + 2 * k0_2] * t488[4 * j1_4 + 2 * j2_12 + k1_13];
            t507[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k1_13] = t507[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k1_13] + t33[ip0_0 + 2 * k0_2] * t489[4 * j1_4 + 2 * j2_12 + k1_13];
            t508[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k1_13] = t508[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k1_13] + t33[ip0_0 + 2 * k0_2] * t490[4 * j1_4 + 2 * j2_12 + k1_13];
            t509[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k1_13] = t509[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k1_13] + t33[ip0_0 + 2 * k0_2] * t491[4 * j1_4 + 2 * j2_12 + k1_13];
            t510[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k1_13] = t510[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k1_13] + t33[ip0_0 + 2 * k0_2] * t492[4 * j1_4 + 2 * j2_12 + k1_13];
            t511[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k1_13] = t511[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k1_13] + t33[ip0_0 + 2 * k0_2] * t493[4 * j1_4 + 2 * j2_12 + k1_13];
            t512[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k1_13] = t512[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k1_13] + t33[ip0_0 + 2 * k0_2] * t494[4 * j1_4 + 2 * j2_12 + k1_13];
            t513[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k1_13] = t513[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k1_13] + t33[ip0_0 + 2 * k0_2] * t495[4 * j1_4 + 2 * j2_12 + k1_13];
            t514[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k1_13] = t514[8 * j1_4 + 4 * j2_12 + 2 * k0_2 + k1_13] + t33[ip0_0 + 2 * k0_2] * t496[4 * j1_4 + 2 * j2_12 + k1_13];
          }
        }
    for (int32_t j0_0 = 0; j0_0 <= 1; ++j0_0)
    {
      for (int32_t k0_3 = 0; k0_3 <= 1; ++k0_3)
        t515[k0_3] = t33[ip0_0 + 2 * j0_0] * t33[ip0_0 + 2 * k0_3];
      for (int32_t j2_13 = 0; j2_13 <= 1; ++j2_13)
      {
        for (int32_t k1_14 = 0; k1_14 <= 1; ++k1_14)
          for (int32_t k2_24 = 0; k2_24 <= 1; ++k2_24)
          {
            t516[8 * j0_0 + 4 * j2_13 + 2 * k1_14 + k2_24] = t516[8 * j0_0 + 4 * j2_13 + 2 * k1_14 + k2_24] + t33[ip0_0 + 2 * j0_0] * t434[4 * j2_13 + 2 * k1_14 + k2_24];
            t517[8 * j0_0 + 4 * j2_13 + 2 * k1_14 + k2_24] = t517[8 * j0_0 + 4 * j2_13 + 2 * k1_14 + k2_24] + t33[ip0_0 + 2 * j0_0] * t435[4 * j2_13 + 2 * k1_14 + k2_24];
            t518[8 * j0_0 + 4 * j2_13 + 2 * k1_14 + k2_24] = t518[8 * j0_0 + 4 * j2_13 + 2 * k1_14 + k2_24] + t33[ip0_0 + 2 * j0_0] * t436[4 * j2_13 + 2 * k1_14 + k2_24];
            t519[8 * j0_0 + 4 * j2_13 + 2 * k1_14 + k2_24] = t519[8 * j0_0 + 4 * j2_13 + 2 * k1_14 + k2_24] + t33[ip0_0 + 2 * j0_0] * t437[4 * j2_13 + 2 * k1_14 + k2_24];
            t520[8 * j0_0 + 4 * j2_13 + 2 * k1_14 + k2_24] = t520[8 * j0_0 + 4 * j2_13 + 2 * k1_14 + k2_24] + t33[ip0_0 + 2 * j0_0] * t438[4 * j2_13 + 2 * k1_14 + k2_24];
            t521[8 * j0_0 + 4 * j2_13 + 2 * k1_14 + k2_24] = t521[8 * j0_0 + 4 * j2_13 + 2 * k1_14 + k2_24] + t33[ip0_0 + 2 * j0_0] * t439[4 * j2_13 + 2 * k1_14 + k2_24];
            t522[8 * j0_0 + 4 * j2_13 + 2 * k1_14 + k2_24] = t522[8 * j0_0 + 4 * j2_13 + 2 * k1_14 + k2_24] + t33[ip0_0 + 2 * j0_0] * t440[4 * j2_13 + 2 * k1_14 + k2_24];
            t523[8 * j0_0 + 4 * j2_13 + 2 * k1_14 + k2_24] = t523[8 * j0_0 + 4 * j2_13 + 2 * k1_14 + k2_24] + t33[ip0_0 + 2 * j0_0] * t441[4 * j2_13 + 2 * k1_14 + k2_24];
            t524[8 * j0_0 + 4 * j2_13 + 2 * k1_14 + k2_24] = t524[8 * j0_0 + 4 * j2_13 + 2 * k1_14 + k2_24] + t33[ip0_0 + 2 * j0_0] * t442[4 * j2_13 + 2 * k1_14 + k2_24];
          }
        for (int32_t k0_4 = 0; k0_4 <= 1; ++k0_4)
        {
          for (int32_t k2_25 = 0; k2_25 <= 1; ++k2_25)
          {
            t525[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k2_25] = t525[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k2_25] + t176[2 * j2_13 + k2_25] * t515[k0_4];
            t526[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k2_25] = t526[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k2_25] + t177[2 * j2_13 + k2_25] * t515[k0_4];
            t527[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k2_25] = t527[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k2_25] + t178[2 * j2_13 + k2_25] * t515[k0_4];
            t528[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k2_25] = t528[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k2_25] + t179[2 * j2_13 + k2_25] * t515[k0_4];
            t529[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k2_25] = t529[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k2_25] + t180[2 * j2_13 + k2_25] * t515[k0_4];
            t530[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k2_25] = t530[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k2_25] + t181[2 * j2_13 + k2_25] * t515[k0_4];
            t531[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k2_25] = t531[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k2_25] + t182[2 * j2_13 + k2_25] * t515[k0_4];
            t532[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k2_25] = t532[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k2_25] + t183[2 * j2_13 + k2_25] * t515[k0_4];
            t533[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k2_25] = t533[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k2_25] + t184[2 * j2_13 + k2_25] * t515[k0_4];
          }
          for (int32_t k1_15 = 0; k1_15 <= 1; ++k1_15)
          {
            t534[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k1_15] = t534[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k1_15] + t443[2 * j2_13 + k1_15] * t515[k0_4];
            t535[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k1_15] = t535[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k1_15] + t444[2 * j2_13 + k1_15] * t515[k0_4];
            t536[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k1_15] = t536[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k1_15] + t445[2 * j2_13 + k1_15] * t515[k0_4];
            t537[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k1_15] = t537[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k1_15] + t446[2 * j2_13 + k1_15] * t515[k0_4];
            t538[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k1_15] = t538[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k1_15] + t447[2 * j2_13 + k1_15] * t515[k0_4];
            t539[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k1_15] = t539[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k1_15] + t448[2 * j2_13 + k1_15] * t515[k0_4];
            t540[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k1_15] = t540[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k1_15] + t449[2 * j2_13 + k1_15] * t515[k0_4];
            t541[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k1_15] = t541[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k1_15] + t450[2 * j2_13 + k1_15] * t515[k0_4];
            t542[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k1_15] = t542[8 * j0_0 + 4 * j2_13 + 2 * k0_4 + k1_15] + t451[2 * j2_13 + k1_15] * t515[k0_4];
          }
        }
      }
      for (int32_t j1_5 = 0; j1_5 <= 1; ++j1_5)
      {
        for (int32_t k1_16 = 0; k1_16 <= 1; ++k1_16)
          for (int32_t k2_26 = 0; k2_26 <= 1; ++k2_26)
          {
            t543[8 * j0_0 + 4 * j1_5 + 2 * k1_16 + k2_26] = t543[8 * j0_0 + 4 * j1_5 + 2 * k1_16 + k2_26] + t33[ip0_0 + 2 * j0_0] * t461[4 * j1_5 + 2 * k1_16 + k2_26];
            t544[8 * j0_0 + 4 * j1_5 + 2 * k1_16 + k2_26] = t544[8 * j0_0 + 4 * j1_5 + 2 * k1_16 + k2_26] + t33[ip0_0 + 2 * j0_0] * t462[4 * j1_5 + 2 * k1_16 + k2_26];
            t545[8 * j0_0 + 4 * j1_5 + 2 * k1_16 + k2_26] = t545[8 * j0_0 + 4 * j1_5 + 2 * k1_16 + k2_26] + t33[ip0_0 + 2 * j0_0] * t463[4 * j1_5 + 2 * k1_16 + k2_26];
            t546[8 * j0_0 + 4 * j1_5 + 2 * k1_16 + k2_26] = t546[8 * j0_0 + 4 * j1_5 + 2 * k1_16 + k2_26] + t33[ip0_0 + 2 * j0_0] * t464[4 * j1_5 + 2 * k1_16 + k2_26];
            t547[8 * j0_0 + 4 * j1_5 + 2 * k1_16 + k2_26] = t547[8 * j0_0 + 4 * j1_5 + 2 * k1_16 + k2_26] + t33[ip0_0 + 2 * j0_0] * t465[4 * j1_5 + 2 * k1_16 + k2_26];
            t548[8 * j0_0 + 4 * j1_5 + 2 * k1_16 + k2_26] = t548[8 * j0_0 + 4 * j1_5 + 2 * k1_16 + k2_26] + t33[ip0_0 + 2 * j0_0] * t466[4 * j1_5 + 2 * k1_16 + k2_26];
            t549[8 * j0_0 + 4 * j1_5 + 2 * k1_16 + k2_26] = t549[8 * j0_0 + 4 * j1_5 + 2 * k1_16 + k2_26] + t33[ip0_0 + 2 * j0_0] * t467[4 * j1_5 + 2 * k1_16 + k2_26];
            t550[8 * j0_0 + 4 * j1_5 + 2 * k1_16 + k2_26] = t550[8 * j0_0 + 4 * j1_5 + 2 * k1_16 + k2_26] + t33[ip0_0 + 2 * j0_0] * t468[4 * j1_5 + 2 * k1_16 + k2_26];
            t551[8 * j0_0 + 4 * j1_5 + 2 * k1_16 + k2_26] = t551[8 * j0_0 + 4 * j1_5 + 2 * k1_16 + k2_26] + t33[ip0_0 + 2 * j0_0] * t469[4 * j1_5 + 2 * k1_16 + k2_26];
          }
        for (int32_t k0_5 = 0; k0_5 <= 1; ++k0_5)
        {
          for (int32_t k2_27 = 0; k2_27 <= 1; ++k2_27)
          {
            t552[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k2_27] = t552[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k2_27] + t452[2 * j1_5 + k2_27] * t515[k0_5];
            t553[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k2_27] = t553[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k2_27] + t453[2 * j1_5 + k2_27] * t515[k0_5];
            t554[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k2_27] = t554[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k2_27] + t454[2 * j1_5 + k2_27] * t515[k0_5];
            t555[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k2_27] = t555[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k2_27] + t455[2 * j1_5 + k2_27] * t515[k0_5];
            t556[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k2_27] = t556[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k2_27] + t456[2 * j1_5 + k2_27] * t515[k0_5];
            t557[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k2_27] = t557[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k2_27] + t457[2 * j1_5 + k2_27] * t515[k0_5];
            t558[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k2_27] = t558[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k2_27] + t458[2 * j1_5 + k2_27] * t515[k0_5];
            t559[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k2_27] = t559[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k2_27] + t459[2 * j1_5 + k2_27] * t515[k0_5];
            t560[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k2_27] = t560[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k2_27] + t460[2 * j1_5 + k2_27] * t515[k0_5];
          }
          for (int32_t k1_17 = 0; k1_17 <= 1; ++k1_17)
          {
            t561[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k1_17] = t561[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k1_17] + t470[2 * j1_5 + k1_17] * t515[k0_5];
            t562[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k1_17] = t562[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k1_17] + t471[2 * j1_5 + k1_17] * t515[k0_5];
            t563[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k1_17] = t563[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k1_17] + t472[2 * j1_5 + k1_17] * t515[k0_5];
            t564[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k1_17] = t564[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k1_17] + t473[2 * j1_5 + k1_17] * t515[k0_5];
            t565[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k1_17] = t565[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k1_17] + t474[2 * j1_5 + k1_17] * t515[k0_5];
            t566[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k1_17] = t566[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k1_17] + t475[2 * j1_5 + k1_17] * t515[k0_5];
            t567[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k1_17] = t567[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k1_17] + t476[2 * j1_5 + k1_17] * t515[k0_5];
            t568[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k1_17] = t568[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k1_17] + t477[2 * j1_5 + k1_17] * t515[k0_5];
            t569[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k1_17] = t569[8 * j0_0 + 4 * j1_5 + 2 * k0_5 + k1_17] + t478[2 * j1_5 + k1_17] * t515[k0_5];
          }
        }
      }
    }
  }
  for (int32_t j1_6 = 0; j1_6 <= 1; ++j1_6)
    for (int32_t j2_14 = 0; j2_14 <= 1; ++j2_14)
      for (int32_t k0_6 = 0; k0_6 <= 1; ++k0_6)
        for (int32_t k1_18 = 0; k1_18 <= 1; ++k1_18)
          for (int32_t k2_28 = 0; k2_28 <= 1; ++k2_28)
          {
            t570[16 * j1_6 + 8 * j2_14 + 4 * k0_6 + 2 * k1_18 + k2_28] = t121[k0_6] * t132[8 * j1_6 + 4 * j2_14 + 2 * k1_18 + k2_28] + t121[k1_18] * t497[8 * j1_6 + 4 * j2_14 + 2 * k0_6 + k2_28] + t121[k2_28] * t506[8 * j1_6 + 4 * j2_14 + 2 * k0_6 + k1_18];
            t571[16 * j1_6 + 8 * j2_14 + 4 * k0_6 + 2 * k1_18 + k2_28] = t121[k0_6] * t133[8 * j1_6 + 4 * j2_14 + 2 * k1_18 + k2_28] + t121[k1_18] * t498[8 * j1_6 + 4 * j2_14 + 2 * k0_6 + k2_28] + t121[k2_28] * t507[8 * j1_6 + 4 * j2_14 + 2 * k0_6 + k1_18];
            t572[16 * j1_6 + 8 * j2_14 + 4 * k0_6 + 2 * k1_18 + k2_28] = t121[k0_6] * t134[8 * j1_6 + 4 * j2_14 + 2 * k1_18 + k2_28] + t121[k1_18] * t499[8 * j1_6 + 4 * j2_14 + 2 * k0_6 + k2_28] + t121[k2_28] * t508[8 * j1_6 + 4 * j2_14 + 2 * k0_6 + k1_18];
            t573[16 * j1_6 + 8 * j2_14 + 4 * k0_6 + 2 * k1_18 + k2_28] = t121[k0_6] * t135[8 * j1_6 + 4 * j2_14 + 2 * k1_18 + k2_28] + t121[k1_18] * t500[8 * j1_6 + 4 * j2_14 + 2 * k0_6 + k2_28] + t121[k2_28] * t509[8 * j1_6 + 4 * j2_14 + 2 * k0_6 + k1_18];
            t574[16 * j1_6 + 8 * j2_14 + 4 * k0_6 + 2 * k1_18 + k2_28] = t121[k0_6] * t136[8 * j1_6 + 4 * j2_14 + 2 * k1_18 + k2_28] + t121[k1_18] * t501[8 * j1_6 + 4 * j2_14 + 2 * k0_6 + k2_28] + t121[k2_28] * t510[8 * j1_6 + 4 * j2_14 + 2 * k0_6 + k1_18];
            t575[16 * j1_6 + 8 * j2_14 + 4 * k0_6 + 2 * k1_18 + k2_28] = t121[k0_6] * t137[8 * j1_6 + 4 * j2_14 + 2 * k1_18 + k2_28] + t121[k1_18] * t502[8 * j1_6 + 4 * j2_14 + 2 * k0_6 + k2_28] + t121[k2_28] * t511[8 * j1_6 + 4 * j2_14 + 2 * k0_6 + k1_18];
            t576[16 * j1_6 + 8 * j2_14 + 4 * k0_6 + 2 * k1_18 + k2_28] = t121[k0_6] * t138[8 * j1_6 + 4 * j2_14 + 2 * k1_18 + k2_28] + t121[k1_18] * t503[8 * j1_6 + 4 * j2_14 + 2 * k0_6 + k2_28] + t121[k2_28] * t512[8 * j1_6 + 4 * j2_14 + 2 * k0_6 + k1_18];
            t577[16 * j1_6 + 8 * j2_14 + 4 * k0_6 + 2 * k1_18 + k2_28] = t121[k0_6] * t139[8 * j1_6 + 4 * j2_14 + 2 * k1_18 + k2_28] + t121[k1_18] * t504[8 * j1_6 + 4 * j2_14 + 2 * k0_6 + k2_28] + t121[k2_28] * t513[8 * j1_6 + 4 * j2_14 + 2 * k0_6 + k1_18];
            t578[16 * j1_6 + 8 * j2_14 + 4 * k0_6 + 2 * k1_18 + k2_28] = t121[k0_6] * t140[8 * j1_6 + 4 * j2_14 + 2 * k1_18 + k2_28] + t121[k1_18] * t505[8 * j1_6 + 4 * j2_14 + 2 * k0_6 + k2_28] + t121[k2_28] * t514[8 * j1_6 + 4 * j2_14 + 2 * k0_6 + k1_18];
          }
  for (int32_t j0_1 = 0; j0_1 <= 1; ++j0_1)
  {
    for (int32_t j2_15 = 0; j2_15 <= 1; ++j2_15)
      for (int32_t k0_7 = 0; k0_7 <= 1; ++k0_7)
        for (int32_t k1_19 = 0; k1_19 <= 1; ++k1_19)
          for (int32_t k2_29 = 0; k2_29 <= 1; ++k2_29)
          {
            t579[8 * j2_15 + 4 * k0_7 + 2 * k1_19 + k2_29] = t121[k0_7] * t516[8 * j0_1 + 4 * j2_15 + 2 * k1_19 + k2_29] + t121[k1_19] * t525[8 * j0_1 + 4 * j2_15 + 2 * k0_7 + k2_29] + t121[k2_29] * t534[8 * j0_1 + 4 * j2_15 + 2 * k0_7 + k1_19];
            t580[8 * j2_15 + 4 * k0_7 + 2 * k1_19 + k2_29] = t121[k0_7] * t517[8 * j0_1 + 4 * j2_15 + 2 * k1_19 + k2_29] + t121[k1_19] * t526[8 * j0_1 + 4 * j2_15 + 2 * k0_7 + k2_29] + t121[k2_29] * t535[8 * j0_1 + 4 * j2_15 + 2 * k0_7 + k1_19];
            t581[8 * j2_15 + 4 * k0_7 + 2 * k1_19 + k2_29] = t121[k0_7] * t518[8 * j0_1 + 4 * j2_15 + 2 * k1_19 + k2_29] + t121[k1_19] * t527[8 * j0_1 + 4 * j2_15 + 2 * k0_7 + k2_29] + t121[k2_29] * t536[8 * j0_1 + 4 * j2_15 + 2 * k0_7 + k1_19];
            t582[8 * j2_15 + 4 * k0_7 + 2 * k1_19 + k2_29] = t121[k0_7] * t519[8 * j0_1 + 4 * j2_15 + 2 * k1_19 + k2_29] + t121[k1_19] * t528[8 * j0_1 + 4 * j2_15 + 2 * k0_7 + k2_29] + t121[k2_29] * t537[8 * j0_1 + 4 * j2_15 + 2 * k0_7 + k1_19];
            t583[8 * j2_15 + 4 * k0_7 + 2 * k1_19 + k2_29] = t121[k0_7] * t520[8 * j0_1 + 4 * j2_15 + 2 * k1_19 + k2_29] + t121[k1_19] * t529[8 * j0_1 + 4 * j2_15 + 2 * k0_7 + k2_29] + t121[k2_29] * t538[8 * j0_1 + 4 * j2_15 + 2 * k0_7 + k1_19];
            t584[8 * j2_15 + 4 * k0_7 + 2 * k1_19 + k2_29] = t121[k0_7] * t521[8 * j0_1 + 4 * j2_15 + 2 * k1_19 + k2_29] + t121[k1_19] * t530[8 * j0_1 + 4 * j2_15 + 2 * k0_7 + k2_29] + t121[k2_29] * t539[8 * j0_1 + 4 * j2_15 + 2 * k0_7 + k1_19];
            t585[8 * j2_15 + 4 * k0_7 + 2 * k1_19 + k2_29] = t121[k0_7] * t522[8 * j0_1 + 4 * j2_15 + 2 * k1_19 + k2_29] + t121[k1_19] * t531[8 * j0_1 + 4 * j2_15 + 2 * k0_7 + k2_29] + t121[k2_29] * t540[8 * j0_1 + 4 * j2_15 + 2 * k0_7 + k1_19];
            t586[8 * j2_15 + 4 * k0_7 + 2 * k1_19 + k2_29] = t121[k0_7] * t523[8 * j0_1 + 4 * j2_15 + 2 * k1_19 + k2_29] + t121[k1_19] * t532[8 * j0_1 + 4 * j2_15 + 2 * k0_7 + k2_29] + t121[k2_29] * t541[8 * j0_1 + 4 * j2_15 + 2 * k0_7 + k1_19];
            t587[8 * j2_15 + 4 * k0_7 + 2 * k1_19 + k2_29] = t121[k0_7] * t524[8 * j0_1 + 4 * j2_15 + 2 * k1_19 + k2_29] + t121[k1_19] * t533[8 * j0_1 + 4 * j2_15 + 2 * k0_7 + k2_29] + t121[k2_29] * t542[8 * j0_1 + 4 * j2_15 + 2 * k0_7 + k1_19];
          }
    for (int32_t j1_7 = 0; j1_7 <= 1; ++j1_7)
    {
      for (int32_t k0_8 = 0; k0_8 <= 1; ++k0_8)
        for (int32_t k1_20 = 0; k1_20 <= 1; ++k1_20)
          for (int32_t k2_30 = 0; k2_30 <= 1; ++k2_30)
          {
            t588[4 * k0_8 + 2 * k1_20 + k2_30] = t121[k0_8] * t543[8 * j0_1 + 4 * j1_7 + 2 * k1_20 + k2_30] + t121[k1_20] * t552[8 * j0_1 + 4 * j1_7 + 2 * k0_8 + k2_30] + t121[k2_30] * t561[8 * j0_1 + 4 * j1_7 + 2 * k0_8 + k1_20];
            t589[4 * k0_8 + 2 * k1_20 + k2_30] = t121[k0_8] * t544[8 * j0_1 + 4 * j1_7 + 2 * k1_20 + k2_30] + t121[k1_20] * t553[8 * j0_1 + 4 * j1_7 + 2 * k0_8 + k2_30] + t121[k2_30] * t562[8 * j0_1 + 4 * j1_7 + 2 * k0_8 + k1_20];
            t590[4 * k0_8 + 2 * k1_20 + k2_30] = t121[k0_8] * t545[8 * j0_1 + 4 * j1_7 + 2 * k1_20 + k2_30] + t121[k1_20] * t554[8 * j0_1 + 4 * j1_7 + 2 * k0_8 + k2_30] + t121[k2_30] * t563[8 * j0_1 + 4 * j1_7 + 2 * k0_8 + k1_20];
            t591[4 * k0_8 + 2 * k1_20 + k2_30] = t121[k0_8] * t546[8 * j0_1 + 4 * j1_7 + 2 * k1_20 + k2_30] + t121[k1_20] * t555[8 * j0_1 + 4 * j1_7 + 2 * k0_8 + k2_30] + t121[k2_30] * t564[8 * j0_1 + 4 * j1_7 + 2 * k0_8 + k1_20];
            t592[4 * k0_8 + 2 * k1_20 + k2_30] = t121[k0_8] * t547[8 * j0_1 + 4 * j1_7 + 2 * k1_20 + k2_30] + t121[k1_20] * t556[8 * j0_1 + 4 * j1_7 + 2 * k0_8 + k2_30] + t121[k2_30] * t565[8 * j0_1 + 4 * j1_7 + 2 * k0_8 + k1_20];
            t593[4 * k0_8 + 2 * k1_20 + k2_30] = t121[k0_8] * t548[8 * j0_1 + 4 * j1_7 + 2 * k1_20 + k2_30] + t121[k1_20] * t557[8 * j0_1 + 4 * j1_7 + 2 * k0_8 + k2_30] + t121[k2_30] * t566[8 * j0_1 + 4 * j1_7 + 2 * k0_8 + k1_20];
            t594[4 * k0_8 + 2 * k1_20 + k2_30] = t121[k0_8] * t549[8 * j0_1 + 4 * j1_7 + 2 * k1_20 + k2_30] + t121[k1_20] * t558[8 * j0_1 + 4 * j1_7 + 2 * k0_8 + k2_30] + t121[k2_30] * t567[8 * j0_1 + 4 * j1_7 + 2 * k0_8 + k1_20];
            t595[4 * k0_8 + 2 * k1_20 + k2_30] = t121[k0_8] * t550[8 * j0_1 + 4 * j1_7 + 2 * k1_20 + k2_30] + t121[k1_20] * t559[8 * j0_1 + 4 * j1_7 + 2 * k0_8 + k2_30] + t121[k2_30] * t568[8 * j0_1 + 4 * j1_7 + 2 * k0_8 + k1_20];
            t596[4 * k0_8 + 2 * k1_20 + k2_30] = t121[k0_8] * t551[8 * j0_1 + 4 * j1_7 + 2 * k1_20 + k2_30] + t121[k1_20] * t560[8 * j0_1 + 4 * j1_7 + 2 * k0_8 + k2_30] + t121[k2_30] * t569[8 * j0_1 + 4 * j1_7 + 2 * k0_8 + k1_20];
          }
      for (int32_t j2_16 = 0; j2_16 <= 1; ++j2_16)
        for (int32_t k0_9 = 0; k0_9 <= 1; ++k0_9)
          for (int32_t k1_21 = 0; k1_21 <= 1; ++k1_21)
            for (int32_t k2_31 = 0; k2_31 <= 1; ++k2_31)
            {
              A[288 * j0_1 + 144 * j1_7 + 72 * j2_16 + 12 * k0_9 + 6 * k1_21 + 3 * k2_31] = A[288 * j0_1 + 144 * j1_7 + 72 * j2_16 + 12 * k0_9 + 6 * k1_21 + 3 * k2_31] + t578[16 * j1_7 + 8 * j2_16 + 4 * k0_9 + 2 * k1_21 + k2_31] * t121[j0_1] + t587[8 * j2_16 + 4 * k0_9 + 2 * k1_21 + k2_31] * t121[j1_7] + t596[4 * k0_9 + 2 * k1_21 + k2_31] * t121[j2_16];
              A[1 + 288 * j0_1 + 144 * j1_7 + 72 * j2_16 + 12 * k0_9 + 6 * k1_21 + 3 * k2_31] = A[1 + 288 * j0_1 + 144 * j1_7 + 72 * j2_16 + 12 * k0_9 + 6 * k1_21 + 3 * k2_31] + t577[16 * j1_7 + 8 * j2_16 + 4 * k0_9 + 2 * k1_21 + k2_31] * t121[j0_1] + t586[8 * j2_16 + 4 * k0_9 + 2 * k1_21 + k2_31] * t121[j1_7] + t595[4 * k0_9 + 2 * k1_21 + k2_31] * t121[j2_16];
              A[2 + 288 * j0_1 + 144 * j1_7 + 72 * j2_16 + 12 * k0_9 + 6 * k1_21 + 3 * k2_31] = A[2 + 288 * j0_1 + 144 * j1_7 + 72 * j2_16 + 12 * k0_9 + 6 * k1_21 + 3 * k2_31] + t576[16 * j1_7 + 8 * j2_16 + 4 * k0_9 + 2 * k1_21 + k2_31] * t121[j0_1] + t585[8 * j2_16 + 4 * k0_9 + 2 * k1_21 + k2_31] * t121[j1_7] + t594[4 * k0_9 + 2 * k1_21 + k2_31] * t121[j2_16];
              A[24 + 288 * j0_1 + 144 * j1_7 + 72 * j2_16 + 12 * k0_9 + 6 * k1_21 + 3 * k2_31] = A[24 + 288 * j0_1 + 144 * j1_7 + 72 * j2_16 + 12 * k0_9 + 6 * k1_21 + 3 * k2_31] + t575[16 * j1_7 + 8 * j2_16 + 4 * k0_9 + 2 * k1_21 + k2_31] * t121[j0_1] + t584[8 * j2_16 + 4 * k0_9 + 2 * k1_21 + k2_31] * t121[j1_7] + t593[4 * k0_9 + 2 * k1_21 + k2_31] * t121[j2_16];
              A[25 + 288 * j0_1 + 144 * j1_7 + 72 * j2_16 + 12 * k0_9 + 6 * k1_21 + 3 * k2_31] = A[25 + 288 * j0_1 + 144 * j1_7 + 72 * j2_16 + 12 * k0_9 + 6 * k1_21 + 3 * k2_31] + t574[16 * j1_7 + 8 * j2_16 + 4 * k0_9 + 2 * k1_21 + k2_31] * t121[j0_1] + t583[8 * j2_16 + 4 * k0_9 + 2 * k1_21 + k2_31] * t121[j1_7] + t592[4 * k0_9 + 2 * k1_21 + k2_31] * t121[j2_16];
              A[26 + 288 * j0_1 + 144 * j1_7 + 72 * j2_16 + 12 * k0_9 + 6 * k1_21 + 3 * k2_31] = A[26 + 288 * j0_1 + 144 * j1_7 + 72 * j2_16 + 12 * k0_9 + 6 * k1_21 + 3 * k2_31] + t573[16 * j1_7 + 8 * j2_16 + 4 * k0_9 + 2 * k1_21 + k2_31] * t121[j0_1] + t582[8 * j2_16 + 4 * k0_9 + 2 * k1_21 + k2_31] * t121[j1_7] + t591[4 * k0_9 + 2 * k1_21 + k2_31] * t121[j2_16];
              A[48 + 288 * j0_1 + 144 * j1_7 + 72 * j2_16 + 12 * k0_9 + 6 * k1_21 + 3 * k2_31] = A[48 + 288 * j0_1 + 144 * j1_7 + 72 * j2_16 + 12 * k0_9 + 6 * k1_21 + 3 * k2_31] + t572[16 * j1_7 + 8 * j2_16 + 4 * k0_9 + 2 * k1_21 + k2_31] * t121[j0_1] + t581[8 * j2_16 + 4 * k0_9 + 2 * k1_21 + k2_31] * t121[j1_7] + t590[4 * k0_9 + 2 * k1_21 + k2_31] * t121[j2_16];
              A[49 + 288 * j0_1 + 144 * j1_7 + 72 * j2_16 + 12 * k0_9 + 6 * k1_21 + 3 * k2_31] = A[49 + 288 * j0_1 + 144 * j1_7 + 72 * j2_16 + 12 * k0_9 + 6 * k1_21 + 3 * k2_31] + t571[16 * j1_7 + 8 * j2_16 + 4 * k0_9 + 2 * k1_21 + k2_31] * t121[j0_1] + t580[8 * j2_16 + 4 * k0_9 + 2 * k1_21 + k2_31] * t121[j1_7] + t589[4 * k0_9 + 2 * k1_21 + k2_31] * t121[j2_16];
              A[50 + 288 * j0_1 + 144 * j1_7 + 72 * j2_16 + 12 * k0_9 + 6 * k1_21 + 3 * k2_31] = A[50 + 288 * j0_1 + 144 * j1_7 + 72 * j2_16 + 12 * k0_9 + 6 * k1_21 + 3 * k2_31] + t570[16 * j1_7 + 8 * j2_16 + 4 * k0_9 + 2 * k1_21 + k2_31] * t121[j0_1] + t579[8 * j2_16 + 4 * k0_9 + 2 * k1_21 + k2_31] * t121[j1_7] + t588[4 * k0_9 + 2 * k1_21 + k2_31] * t121[j2_16];
            }
    }
  }

}