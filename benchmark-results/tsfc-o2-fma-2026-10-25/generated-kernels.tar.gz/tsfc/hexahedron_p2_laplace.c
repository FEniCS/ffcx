#include <stdint.h>
#include <stdbool.h>
#include <math.h>

void k_cell_integral(double *__restrict__ A, double const *__restrict__ coords_0)
{
  double t0;
  double t1;
  double t10;
  double t100;
  double t101;
  double t102;
  double t103;
  double t104;
  double t105;
  double t106;
  double t107;
  double t108;
  double t109;
  double t11;
  double t110;
  double t111;
  double t112;
  double t113[3 * 3];
  double t114[3 * 3];
  double t115[3 * 3];
  double t116[3 * 3];
  double t117[3 * 3];
  double t118[3 * 3];
  double t119[3 * 3];
  double t12;
  double t120[3 * 3];
  double t121[3 * 3];
  double t122[3 * 3 * 3];
  double t123[3 * 3 * 3];
  double t124[3 * 3 * 3];
  double t125[3];
  double t126[3 * 3 * 3 * 3];
  double t127[3 * 3 * 3 * 3];
  double t128[3 * 3 * 3 * 3];
  double t129[3 * 3 * 3 * 3];
  double t13;
  double t130[3 * 3 * 3 * 3 * 3];
  double t131[3 * 3 * 3 * 3 * 3];
  double t14;
  double t15;
  double t16;
  double t17;
  double t18;
  double t19;
  double t2;
  double t20;
  double t21;
  double t22;
  double t23;
  double t24;
  double t25;
  double t26;
  double t27;
  double t28;
  double t29;
  double t3;
  double t30;
  double t31;
  double t32;
  double t33;
  double t34;
  double t35;
  double t36;
  double t37;
  double t38;
  double t39;
  double t4;
  double t40;
  double t41;
  double t42;
  double t43;
  double t44;
  double t45;
  double t46;
  double t47;
  double t48[3] = { 0.8872983346207416, 0.5, 0.1127016653792583 };
  double t49[3] = { 0.1127016653792583, 0.5, 0.8872983346207416 };
  double t5;
  double t50[3] = { 0.2777777777777779, 0.4444444444444444, 0.2777777777777779 };
  double t51[3 * 3] = { -2.549193338482967, -1.0, 0.5491933384829668, 3.0983866769659336, 0.0, -3.0983866769659336, -0.5491933384829669, 1.0, 2.549193338482967 };
  double t52[3 * 3] = { 0.6872983346207417, 0.0, -0.0872983346207417, 0.4, 1.0, 0.4, -0.0872983346207417, 0.0, 0.6872983346207417 };
  double t53[3 * 3 * 3];
  double t54[3 * 3 * 3];
  double t55[3 * 3 * 3];
  double t56[3 * 3 * 3];
  double t57;
  double t58;
  double t59;
  double t6;
  double t60;
  double t61;
  double t62;
  double t63[3 * 3];
  double t64[3 * 3];
  double t65[3 * 3];
  double t66[3 * 3 * 3];
  double t67;
  double t68;
  double t69;
  double t7;
  double t70;
  double t71;
  double t72;
  double t73;
  double t74;
  double t75;
  double t76;
  double t77;
  double t78;
  double t79[3];
  double t8;
  double t80[3];
  double t81[3];
  double t82[3];
  double t83;
  double t84;
  double t85;
  double t86;
  double t87;
  double t88;
  double t89;
  double t9;
  double t90;
  double t91;
  double t92;
  double t93;
  double t94;
  double t95;
  double t96;
  double t97;
  double t98;
  double t99;

  t0 = -1.0 * coords_0[12];
  t1 = t0 + coords_0[18];
  t2 = -1.0 * coords_0[0];
  t3 = t2 + coords_0[6];
  t4 = -1.0 * coords_0[15] + coords_0[21];
  t5 = -1.0 * coords_0[3];
  t6 = t5 + coords_0[9];
  t7 = -1.0 * coords_0[14];
  t8 = t7 + coords_0[20];
  t9 = -1.0 * coords_0[2];
  t10 = t9 + coords_0[8];
  t11 = -1.0 * coords_0[17] + coords_0[23];
  t12 = -1.0 * coords_0[5];
  t13 = t12 + coords_0[11];
  t14 = -1.0 * coords_0[13];
  t15 = t14 + coords_0[19];
  t16 = -1.0 * coords_0[1];
  t17 = t16 + coords_0[7];
  t18 = -1.0 * coords_0[16] + coords_0[22];
  t19 = -1.0 * coords_0[4];
  t20 = t19 + coords_0[10];
  t21 = t0 + coords_0[15];
  t22 = t2 + coords_0[3];
  t23 = -1.0 * coords_0[18] + coords_0[21];
  t24 = -1.0 * coords_0[6];
  t25 = t24 + coords_0[9];
  t26 = t7 + coords_0[17];
  t27 = t9 + coords_0[5];
  t28 = -1.0 * coords_0[20] + coords_0[23];
  t29 = -1.0 * coords_0[8];
  t30 = t29 + coords_0[11];
  t31 = t14 + coords_0[16];
  t32 = t16 + coords_0[4];
  t33 = -1.0 * coords_0[19] + coords_0[22];
  t34 = -1.0 * coords_0[7];
  t35 = t34 + coords_0[10];
  t36 = t29 + coords_0[20];
  t37 = t9 + coords_0[14];
  t38 = -1.0 * coords_0[11] + coords_0[23];
  t39 = t12 + coords_0[17];
  t40 = t34 + coords_0[19];
  t41 = t16 + coords_0[13];
  t42 = -1.0 * coords_0[10] + coords_0[22];
  t43 = t19 + coords_0[16];
  t44 = t24 + coords_0[18];
  t45 = t2 + coords_0[12];
  t46 = -1.0 * coords_0[9] + coords_0[21];
  t47 = t5 + coords_0[15];
  for (int32_t ip2 = 0; ip2 <= 2; ++ip2)
    for (int32_t j2 = 0; j2 <= 2; ++j2)
      for (int32_t k2 = 0; k2 <= 2; ++k2)
      {
        t53[9 * ip2 + 3 * j2 + k2] = t51[ip2 + 3 * j2] * t51[ip2 + 3 * k2];
        t54[9 * ip2 + 3 * j2 + k2] = t51[ip2 + 3 * j2] * t52[ip2 + 3 * k2];
        t55[9 * ip2 + 3 * j2 + k2] = t52[ip2 + 3 * j2] * t51[ip2 + 3 * k2];
        t56[9 * ip2 + 3 * j2 + k2] = t52[ip2 + 3 * j2] * t52[ip2 + 3 * k2];
      }
  for (int32_t ip1 = 0; ip1 <= 2; ++ip1)
  {
    t57 = t48[ip1] * t47 + t49[ip1] * t46;
    t58 = t48[ip1] * t45 + t49[ip1] * t44;
    t59 = t48[ip1] * t43 + t49[ip1] * t42;
    t60 = t48[ip1] * t41 + t49[ip1] * t40;
    t61 = t48[ip1] * t39 + t49[ip1] * t38;
    t62 = t48[ip1] * t37 + t49[ip1] * t36;
    for (int32_t ip2_0 = 0; ip2_0 <= 2; ++ip2_0)
    {
      t63[3 * ip1 + ip2_0] = t48[ip2_0] * t62 + t49[ip2_0] * t61;
      t64[3 * ip1 + ip2_0] = t48[ip2_0] * t60 + t49[ip2_0] * t59;
      t65[3 * ip1 + ip2_0] = t48[ip2_0] * t58 + t49[ip2_0] * t57;
    }
    for (int32_t j1 = 0; j1 <= 2; ++j1)
      for (int32_t k1 = 0; k1 <= 2; ++k1)
        t66[9 * ip1 + 3 * j1 + k1] = t52[ip1 + 3 * j1] * t52[ip1 + 3 * k1];
  }
  for (int32_t ip0 = 0; ip0 <= 2; ++ip0)
  {
    t67 = t48[ip0] * t35 + t49[ip0] * t33;
    t68 = t48[ip0] * t32 + t49[ip0] * t31;
    t69 = t48[ip0] * t30 + t49[ip0] * t28;
    t70 = t48[ip0] * t27 + t49[ip0] * t26;
    t71 = t48[ip0] * t25 + t49[ip0] * t23;
    t72 = t48[ip0] * t22 + t49[ip0] * t21;
    t73 = t48[ip0] * t20 + t49[ip0] * t18;
    t74 = t48[ip0] * t17 + t49[ip0] * t15;
    t75 = t48[ip0] * t13 + t49[ip0] * t11;
    t76 = t48[ip0] * t10 + t49[ip0] * t8;
    t77 = t48[ip0] * t6 + t49[ip0] * t4;
    t78 = t48[ip0] * t3 + t49[ip0] * t1;
    for (int32_t ip2_1 = 0; ip2_1 <= 2; ++ip2_1)
    {
      t79[ip2_1] = t48[ip2_1] * t78 + t49[ip2_1] * t77;
      t80[ip2_1] = -1.0 * t79[ip2_1];
      t81[ip2_1] = t48[ip2_1] * t76 + t49[ip2_1] * t75;
      t82[ip2_1] = t48[ip2_1] * t74 + t49[ip2_1] * t73;
    }
    for (int32_t j1_0 = 0; j1_0 <= 2; ++j1_0)
      for (int32_t j2_0 = 0; j2_0 <= 2; ++j2_0)
        for (int32_t k1_0 = 0; k1_0 <= 2; ++k1_0)
          for (int32_t k2_0 = 0; k2_0 <= 2; ++k2_0)
          {
            t129[27 * j1_0 + 9 * j2_0 + 3 * k1_0 + k2_0] = (double) (0.0);
            t128[27 * j1_0 + 9 * j2_0 + 3 * k1_0 + k2_0] = (double) (0.0);
            t127[27 * j1_0 + 9 * j2_0 + 3 * k1_0 + k2_0] = (double) (0.0);
            t126[27 * j1_0 + 9 * j2_0 + 3 * k1_0 + k2_0] = (double) (0.0);
          }
    for (int32_t ip1_0 = 0; ip1_0 <= 2; ++ip1_0)
    {
      t83 = t48[ip1_0] * t72 + t49[ip1_0] * t71;
      t84 = -1.0 * t83;
      t85 = t48[ip1_0] * t70 + t49[ip1_0] * t69;
      t86 = -1.0 * t85;
      t87 = t48[ip1_0] * t68 + t49[ip1_0] * t67;
      t88 = t50[ip0] * t50[ip1_0];
      for (int32_t j2_1 = 0; j2_1 <= 2; ++j2_1)
        for (int32_t k2_1 = 0; k2_1 <= 2; ++k2_1)
        {
          t121[3 * j2_1 + k2_1] = (double) (0.0);
          t120[3 * j2_1 + k2_1] = (double) (0.0);
          t119[3 * j2_1 + k2_1] = (double) (0.0);
          t118[3 * j2_1 + k2_1] = (double) (0.0);
          t117[3 * j2_1 + k2_1] = (double) (0.0);
          t116[3 * j2_1 + k2_1] = (double) (0.0);
          t115[3 * j2_1 + k2_1] = (double) (0.0);
          t114[3 * j2_1 + k2_1] = (double) (0.0);
          t113[3 * j2_1 + k2_1] = (double) (0.0);
        }
      for (int32_t ip2_2 = 0; ip2_2 <= 2; ++ip2_2)
      {
        t89 = t82[ip2_2] * t85 + -1.0 * t87 * t81[ip2_2];
        t90 = t87 * t63[3 * ip1_0 + ip2_2];
        t91 = t64[3 * ip1_0 + ip2_2] * t81[ip2_2] + -1.0 * t82[ip2_2] * t63[3 * ip1_0 + ip2_2];
        t92 = t65[3 * ip1_0 + ip2_2] * t89 + (t64[3 * ip1_0 + ip2_2] * t85 + -1.0 * t90) * t80[ip2_2] + t83 * t91;
        t93 = t88 * t50[ip2_2] * fabs(t92);
        t94 = 1.0 / t92;
        t95 = t89 * t94;
        t96 = (t83 * t81[ip2_2] + t85 * t80[ip2_2]) * t94;
        t97 = (t79[ip2_2] * t87 + -1.0 * t83 * t82[ip2_2]) * t94;
        t98 = t93 * (t95 * t95 + t96 * t96 + t97 * t97);
        t99 = t91 * t94;
        t100 = (t79[ip2_2] * t63[3 * ip1_0 + ip2_2] + -1.0 * t65[3 * ip1_0 + ip2_2] * t81[ip2_2]) * t94;
        t101 = (t65[3 * ip1_0 + ip2_2] * t82[ip2_2] + -1.0 * t79[ip2_2] * t64[3 * ip1_0 + ip2_2]) * t94;
        t102 = t93 * (t95 * t99 + t96 * t100 + t97 * t101);
        t103 = (t90 + t64[3 * ip1_0 + ip2_2] * t86) * t94;
        t104 = (t65[3 * ip1_0 + ip2_2] * t85 + t63[3 * ip1_0 + ip2_2] * t84) * t94;
        t105 = (t83 * t64[3 * ip1_0 + ip2_2] + -1.0 * t65[3 * ip1_0 + ip2_2] * t87) * t94;
        t106 = t93 * (t95 * t103 + t96 * t104 + t97 * t105);
        t107 = t93 * (t99 * t103 + t100 * t104 + t101 * t105);
        t108 = t93 * (t103 * t103 + t104 * t104 + t105 * t105);
        t109 = t93 * (t99 * t99 + t100 * t100 + t101 * t101);
        t110 = t93 * (t103 * t99 + t104 * t100 + t105 * t101);
        t111 = t93 * (t99 * t95 + t100 * t96 + t101 * t97);
        t112 = t93 * (t103 * t95 + t104 * t96 + t105 * t97);
        for (int32_t j2_2 = 0; j2_2 <= 2; ++j2_2)
          for (int32_t k2_2 = 0; k2_2 <= 2; ++k2_2)
          {
            t113[3 * j2_2 + k2_2] = t113[3 * j2_2 + k2_2] + t112 * t56[9 * ip2_2 + 3 * j2_2 + k2_2];
            t114[3 * j2_2 + k2_2] = t114[3 * j2_2 + k2_2] + t111 * t55[9 * ip2_2 + 3 * j2_2 + k2_2];
            t115[3 * j2_2 + k2_2] = t115[3 * j2_2 + k2_2] + t110 * t54[9 * ip2_2 + 3 * j2_2 + k2_2];
            t116[3 * j2_2 + k2_2] = t116[3 * j2_2 + k2_2] + t109 * t53[9 * ip2_2 + 3 * j2_2 + k2_2];
            t117[3 * j2_2 + k2_2] = t117[3 * j2_2 + k2_2] + t108 * t56[9 * ip2_2 + 3 * j2_2 + k2_2];
            t118[3 * j2_2 + k2_2] = t118[3 * j2_2 + k2_2] + t107 * t55[9 * ip2_2 + 3 * j2_2 + k2_2];
            t119[3 * j2_2 + k2_2] = t119[3 * j2_2 + k2_2] + t106 * t56[9 * ip2_2 + 3 * j2_2 + k2_2];
            t120[3 * j2_2 + k2_2] = t120[3 * j2_2 + k2_2] + t102 * t54[9 * ip2_2 + 3 * j2_2 + k2_2];
            t121[3 * j2_2 + k2_2] = t121[3 * j2_2 + k2_2] + t98 * t56[9 * ip2_2 + 3 * j2_2 + k2_2];
          }
      }
      for (int32_t j2_3 = 0; j2_3 <= 2; ++j2_3)
        for (int32_t k1_1 = 0; k1_1 <= 2; ++k1_1)
          for (int32_t k2_3 = 0; k2_3 <= 2; ++k2_3)
          {
            t122[9 * j2_3 + 3 * k1_1 + k2_3] = t51[ip1_0 + 3 * k1_1] * t113[3 * j2_3 + k2_3] + t52[ip1_0 + 3 * k1_1] * t114[3 * j2_3 + k2_3];
            t123[9 * j2_3 + 3 * k1_1 + k2_3] = t51[ip1_0 + 3 * k1_1] * t115[3 * j2_3 + k2_3] + t52[ip1_0 + 3 * k1_1] * t116[3 * j2_3 + k2_3];
            t124[9 * j2_3 + 3 * k1_1 + k2_3] = t51[ip1_0 + 3 * k1_1] * t117[3 * j2_3 + k2_3] + t52[ip1_0 + 3 * k1_1] * t118[3 * j2_3 + k2_3];
          }
      for (int32_t j1_1 = 0; j1_1 <= 2; ++j1_1)
        for (int32_t j2_4 = 0; j2_4 <= 2; ++j2_4)
        {
          for (int32_t k2_4 = 0; k2_4 <= 2; ++k2_4)
            t125[k2_4] = t51[ip1_0 + 3 * j1_1] * t119[3 * j2_4 + k2_4] + t52[ip1_0 + 3 * j1_1] * t120[3 * j2_4 + k2_4];
          for (int32_t k1_2 = 0; k1_2 <= 2; ++k1_2)
            for (int32_t k2_5 = 0; k2_5 <= 2; ++k2_5)
            {
              t126[27 * j1_1 + 9 * j2_4 + 3 * k1_2 + k2_5] = t126[27 * j1_1 + 9 * j2_4 + 3 * k1_2 + k2_5] + t125[k2_5] * t52[ip1_0 + 3 * k1_2];
              t127[27 * j1_1 + 9 * j2_4 + 3 * k1_2 + k2_5] = t127[27 * j1_1 + 9 * j2_4 + 3 * k1_2 + k2_5] + t124[9 * j2_4 + 3 * k1_2 + k2_5] * t51[ip1_0 + 3 * j1_1] + t123[9 * j2_4 + 3 * k1_2 + k2_5] * t52[ip1_0 + 3 * j1_1];
              t128[27 * j1_1 + 9 * j2_4 + 3 * k1_2 + k2_5] = t128[27 * j1_1 + 9 * j2_4 + 3 * k1_2 + k2_5] + t121[3 * j2_4 + k2_5] * t66[9 * ip1_0 + 3 * j1_1 + k1_2];
              t129[27 * j1_1 + 9 * j2_4 + 3 * k1_2 + k2_5] = t129[27 * j1_1 + 9 * j2_4 + 3 * k1_2 + k2_5] + t122[9 * j2_4 + 3 * k1_2 + k2_5] * t52[ip1_0 + 3 * j1_1];
            }
        }
    }
    for (int32_t j1_2 = 0; j1_2 <= 2; ++j1_2)
      for (int32_t j2_5 = 0; j2_5 <= 2; ++j2_5)
        for (int32_t k0 = 0; k0 <= 2; ++k0)
          for (int32_t k1_3 = 0; k1_3 <= 2; ++k1_3)
            for (int32_t k2_6 = 0; k2_6 <= 2; ++k2_6)
            {
              t130[81 * j1_2 + 27 * j2_5 + 9 * k0 + 3 * k1_3 + k2_6] = t51[ip0 + 3 * k0] * t126[27 * j1_2 + 9 * j2_5 + 3 * k1_3 + k2_6] + t52[ip0 + 3 * k0] * t127[27 * j1_2 + 9 * j2_5 + 3 * k1_3 + k2_6];
              t131[81 * j1_2 + 27 * j2_5 + 9 * k0 + 3 * k1_3 + k2_6] = t51[ip0 + 3 * k0] * t128[27 * j1_2 + 9 * j2_5 + 3 * k1_3 + k2_6] + t52[ip0 + 3 * k0] * t129[27 * j1_2 + 9 * j2_5 + 3 * k1_3 + k2_6];
            }
    for (int32_t j0 = 0; j0 <= 2; ++j0)
      for (int32_t j1_3 = 0; j1_3 <= 2; ++j1_3)
        for (int32_t j2_6 = 0; j2_6 <= 2; ++j2_6)
          for (int32_t k0_0 = 0; k0_0 <= 2; ++k0_0)
            for (int32_t k1_4 = 0; k1_4 <= 2; ++k1_4)
              for (int32_t k2_7 = 0; k2_7 <= 2; ++k2_7)
                A[243 * j0 + 81 * j1_3 + 27 * j2_6 + 9 * k0_0 + 3 * k1_4 + k2_7] = A[243 * j0 + 81 * j1_3 + 27 * j2_6 + 9 * k0_0 + 3 * k1_4 + k2_7] + t131[81 * j1_3 + 27 * j2_6 + 9 * k0_0 + 3 * k1_4 + k2_7] * t51[ip0 + 3 * j0] + t130[81 * j1_3 + 27 * j2_6 + 9 * k0_0 + 3 * k1_4 + k2_7] * t52[ip0 + 3 * j0];
  }

}