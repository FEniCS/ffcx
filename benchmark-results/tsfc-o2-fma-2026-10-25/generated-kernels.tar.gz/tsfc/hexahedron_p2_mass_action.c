#include <stdint.h>
#include <stdbool.h>
#include <math.h>

void k_cell_integral(double *__restrict__ A, double const *__restrict__ coords_0, double const *__restrict__ w_0)
{
  double t0;
  double t1;
  double t10;
  double t11;
  double t12;
  double t13;
  double t14;
  double t15;
  double t16;
  double t17;
  double t18;
  double t19;
  double t2;
  double t20;
  double t21;
  double t22;
  double t23;
  double t24;
  double t25;
  double t26;
  double t27;
  double t28;
  double t29;
  double t3;
  double t30;
  double t31;
  double t32;
  double t33;
  double t34;
  double t35;
  double t36;
  double t37;
  double t38;
  double t39;
  double t4;
  double t40;
  double t41;
  double t42;
  double t43;
  double t44;
  double t45;
  double t46;
  double t47;
  double t48[3 * 3] = { 0.6872983346207417, 0.0, -0.0872983346207417, 0.4, 1.0, 0.4, -0.0872983346207417, 0.0, 0.6872983346207417 };
  double t49[3] = { 0.8872983346207416, 0.5, 0.1127016653792583 };
  double t5;
  double t50[3] = { 0.1127016653792583, 0.5, 0.8872983346207416 };
  double t51[3] = { 0.2777777777777779, 0.4444444444444444, 0.2777777777777779 };
  double t52[3] = { 0.6872983346207417, 0.0, -0.0872983346207417 };
  double t53[3] = { 0.4, 1.0, 0.4 };
  double t54[3] = { -0.0872983346207417, 0.0, 0.6872983346207417 };
  double t55;
  double t56;
  double t57;
  double t58;
  double t59;
  double t6;
  double t60;
  double t61[3 * 3];
  double t62[3 * 3];
  double t63[3 * 3];
  double t64;
  double t65;
  double t66;
  double t67;
  double t68;
  double t69;
  double t7;
  double t70;
  double t71;
  double t72;
  double t73;
  double t74;
  double t75;
  double t76;
  double t77;
  double t78;
  double t79;
  double t8;
  double t80;
  double t81;
  double t82;
  double t83;
  double t84;
  double t85[3];
  double t86[3];
  double t87[3];
  double t88;
  double t89;
  double t9;
  double t90;
  double t91;
  double t92;
  double t93;
  double t94;
  double t95;
  double t96[3];
  double t97[3 * 3];

  t0 = -1.0 * coords_0[12];
  t1 = t0 + coords_0[18];
  t2 = -1.0 * coords_0[0];
  t3 = t2 + coords_0[6];
  t4 = -1.0 * coords_0[15] + coords_0[21];
  t5 = -1.0 * coords_0[3];
  t6 = t5 + coords_0[9];
  t7 = -1.0 * coords_0[14];
  t8 = t7 + coords_0[20];
  t9 = -1.0 * coords_0[2];
  t10 = t9 + coords_0[8];
  t11 = -1.0 * coords_0[17] + coords_0[23];
  t12 = -1.0 * coords_0[5];
  t13 = t12 + coords_0[11];
  t14 = -1.0 * coords_0[13];
  t15 = t14 + coords_0[19];
  t16 = -1.0 * coords_0[1];
  t17 = t16 + coords_0[7];
  t18 = -1.0 * coords_0[16] + coords_0[22];
  t19 = -1.0 * coords_0[4];
  t20 = t19 + coords_0[10];
  t21 = t0 + coords_0[15];
  t22 = t2 + coords_0[3];
  t23 = -1.0 * coords_0[18] + coords_0[21];
  t24 = -1.0 * coords_0[6];
  t25 = t24 + coords_0[9];
  t26 = t14 + coords_0[16];
  t27 = t16 + coords_0[4];
  t28 = -1.0 * coords_0[19] + coords_0[22];
  t29 = -1.0 * coords_0[7];
  t30 = t29 + coords_0[10];
  t31 = t7 + coords_0[17];
  t32 = t9 + coords_0[5];
  t33 = -1.0 * coords_0[20] + coords_0[23];
  t34 = -1.0 * coords_0[8];
  t35 = t34 + coords_0[11];
  t36 = t34 + coords_0[20];
  t37 = t9 + coords_0[14];
  t38 = -1.0 * coords_0[11] + coords_0[23];
  t39 = t12 + coords_0[17];
  t40 = t29 + coords_0[19];
  t41 = t16 + coords_0[13];
  t42 = -1.0 * coords_0[10] + coords_0[22];
  t43 = t19 + coords_0[16];
  t44 = t24 + coords_0[18];
  t45 = t2 + coords_0[12];
  t46 = -1.0 * coords_0[9] + coords_0[21];
  t47 = t5 + coords_0[15];
  for (int32_t ip1 = 0; ip1 <= 2; ++ip1)
  {
    t55 = t49[ip1] * t47 + t50[ip1] * t46;
    t56 = t49[ip1] * t45 + t50[ip1] * t44;
    t57 = t49[ip1] * t43 + t50[ip1] * t42;
    t58 = t49[ip1] * t41 + t50[ip1] * t40;
    t59 = t49[ip1] * t39 + t50[ip1] * t38;
    t60 = t49[ip1] * t37 + t50[ip1] * t36;
    for (int32_t ip2 = 0; ip2 <= 2; ++ip2)
    {
      t61[3 * ip1 + ip2] = t49[ip2] * t60 + t50[ip2] * t59;
      t62[3 * ip1 + ip2] = t49[ip2] * t58 + t50[ip2] * t57;
      t63[3 * ip1 + ip2] = t49[ip2] * t56 + t50[ip2] * t55;
    }
  }
  for (int32_t ip0 = 0; ip0 <= 2; ++ip0)
  {
    t64 = t49[ip0] * t35 + t50[ip0] * t33;
    t65 = t49[ip0] * t32 + t50[ip0] * t31;
    t66 = t49[ip0] * t30 + t50[ip0] * t28;
    t67 = t49[ip0] * t27 + t50[ip0] * t26;
    t68 = t49[ip0] * t25 + t50[ip0] * t23;
    t69 = t49[ip0] * t22 + t50[ip0] * t21;
    t70 = t52[ip0] * w_0[6] + t53[ip0] * w_0[15] + t54[ip0] * w_0[24];
    t71 = t52[ip0] * w_0[3] + t53[ip0] * w_0[12] + t54[ip0] * w_0[21];
    t72 = t52[ip0] * w_0[0] + t53[ip0] * w_0[9] + t54[ip0] * w_0[18];
    t73 = t52[ip0] * w_0[7] + t53[ip0] * w_0[16] + t54[ip0] * w_0[25];
    t74 = t52[ip0] * w_0[4] + t53[ip0] * w_0[13] + t54[ip0] * w_0[22];
    t75 = t52[ip0] * w_0[1] + t53[ip0] * w_0[10] + t54[ip0] * w_0[19];
    t76 = t52[ip0] * w_0[8] + t53[ip0] * w_0[17] + t54[ip0] * w_0[26];
    t77 = t52[ip0] * w_0[5] + t53[ip0] * w_0[14] + t54[ip0] * w_0[23];
    t78 = t52[ip0] * w_0[2] + t53[ip0] * w_0[11] + t54[ip0] * w_0[20];
    t79 = t49[ip0] * t20 + t50[ip0] * t18;
    t80 = t49[ip0] * t17 + t50[ip0] * t15;
    t81 = t49[ip0] * t13 + t50[ip0] * t11;
    t82 = t49[ip0] * t10 + t50[ip0] * t8;
    t83 = t49[ip0] * t6 + t50[ip0] * t4;
    t84 = t49[ip0] * t3 + t50[ip0] * t1;
    for (int32_t ip2_0 = 0; ip2_0 <= 2; ++ip2_0)
    {
      t85[ip2_0] = -1.0 * (t49[ip2_0] * t84 + t50[ip2_0] * t83);
      t86[ip2_0] = t49[ip2_0] * t82 + t50[ip2_0] * t81;
      t87[ip2_0] = t49[ip2_0] * t80 + t50[ip2_0] * t79;
    }
    for (int32_t j1 = 0; j1 <= 2; ++j1)
      for (int32_t j2 = 0; j2 <= 2; ++j2)
        t97[3 * j1 + j2] = (double) (0.0);
    for (int32_t ip1_0 = 0; ip1_0 <= 2; ++ip1_0)
    {
      t88 = t52[ip1_0] * t78 + t53[ip1_0] * t77 + t54[ip1_0] * t76;
      t89 = t52[ip1_0] * t75 + t53[ip1_0] * t74 + t54[ip1_0] * t73;
      t90 = t52[ip1_0] * t72 + t53[ip1_0] * t71 + t54[ip1_0] * t70;
      t91 = t49[ip1_0] * t69 + t50[ip1_0] * t68;
      t92 = t49[ip1_0] * t67 + t50[ip1_0] * t66;
      t93 = t49[ip1_0] * t65 + t50[ip1_0] * t64;
      t94 = t51[ip0] * t51[ip1_0];
      for (int32_t j2_0 = 0; j2_0 <= 2; ++j2_0)
        t96[j2_0] = (double) (0.0);
      for (int32_t ip2_1 = 0; ip2_1 <= 2; ++ip2_1)
      {
        t95 = t94 * t51[ip2_1] * fabs(t63[3 * ip1_0 + ip2_1] * (t87[ip2_1] * t93 + -1.0 * t92 * t86[ip2_1]) + (t62[3 * ip1_0 + ip2_1] * t93 + -1.0 * t92 * t61[3 * ip1_0 + ip2_1]) * t85[ip2_1] + t91 * (t62[3 * ip1_0 + ip2_1] * t86[ip2_1] + -1.0 * t87[ip2_1] * t61[3 * ip1_0 + ip2_1])) * (t52[ip2_1] * t90 + t53[ip2_1] * t89 + t54[ip2_1] * t88);
        for (int32_t j2_1 = 0; j2_1 <= 2; ++j2_1)
          t96[j2_1] = t96[j2_1] + t48[ip2_1 + 3 * j2_1] * t95;
      }
      for (int32_t j1_0 = 0; j1_0 <= 2; ++j1_0)
        for (int32_t j2_2 = 0; j2_2 <= 2; ++j2_2)
          t97[3 * j1_0 + j2_2] = t97[3 * j1_0 + j2_2] + t48[ip1_0 + 3 * j1_0] * t96[j2_2];
    }
    for (int32_t j0 = 0; j0 <= 2; ++j0)
      for (int32_t j1_1 = 0; j1_1 <= 2; ++j1_1)
        for (int32_t j2_3 = 0; j2_3 <= 2; ++j2_3)
          A[9 * j0 + 3 * j1_1 + j2_3] = A[9 * j0 + 3 * j1_1 + j2_3] + t48[ip0 + 3 * j0] * t97[3 * j1_1 + j2_3];
  }

}