#include <stdint.h>
#include <stdbool.h>
#include <math.h>

void k_cell_integral(double *__restrict__ A, double const *__restrict__ coords_0)
{
  double t0;
  double t1;
  double t10;
  double t11;
  double t12;
  double t13;
  double t14;
  double t15;
  double t16;
  double t17;
  double t18;
  double t19;
  double t2;
  double t20;
  double t21;
  double t22;
  double t23;
  double t24;
  double t25;
  double t26;
  double t27;
  double t28;
  double t29;
  double t3;
  double t30;
  double t31;
  double t32;
  double t33;
  double t34;
  double t35;
  double t36;
  double t37;
  double t38;
  double t39;
  double t4;
  double t40;
  double t41;
  double t42;
  double t43;
  double t44;
  double t45;
  double t46;
  double t47;
  double t48[5] = { 0.953089922969332, 0.7692346550528416, 0.5, 0.23076534494715836, 0.046910077030668074 };
  double t49[5] = { 0.046910077030668074, 0.23076534494715836, 0.5, 0.7692346550528416, 0.953089922969332 };
  double t5;
  double t50[5] = { 0.11846344252809438, 0.23931433524968326, 0.28444444444444456, 0.23931433524968326, 0.11846344252809438 };
  double t51[5 * 5] = { 0.593370696019946, -0.10048256880508269, 0.0, 0.03014411077187963, -0.029205077492916134, 0.5164351986496183, 0.9313661019373952, 0.0, -0.09069490469997664, 0.08322282221996015, -0.16382363939660827, 0.22966726079578437, 1.0, 0.22966726079578428, -0.16382363939660838, 0.08322282221996005, -0.09069490469997667, 0.0, 0.9313661019373954, 0.5164351986496182, -0.029205077492916103, 0.03014411077187963, 0.0, -0.10048256880508262, 0.5933706960199461 };
  double t52[5 * 5 * 5];
  double t53;
  double t54;
  double t55;
  double t56;
  double t57;
  double t58;
  double t59[5 * 5];
  double t6;
  double t60[5 * 5];
  double t61[5 * 5];
  double t62[5 * 5 * 5];
  double t63;
  double t64;
  double t65;
  double t66;
  double t67;
  double t68;
  double t69;
  double t7;
  double t70;
  double t71;
  double t72;
  double t73;
  double t74;
  double t75[5];
  double t76[5];
  double t77[5];
  double t78;
  double t79;
  double t8;
  double t80;
  double t81;
  double t82;
  double t83[5 * 5];
  double t84[5 * 5 * 5 * 5];
  double t85[5];
  double t9;

  t0 = -1.0 * coords_0[12];
  t1 = t0 + coords_0[18];
  t2 = -1.0 * coords_0[0];
  t3 = t2 + coords_0[6];
  t4 = -1.0 * coords_0[15] + coords_0[21];
  t5 = -1.0 * coords_0[3];
  t6 = t5 + coords_0[9];
  t7 = -1.0 * coords_0[14];
  t8 = t7 + coords_0[20];
  t9 = -1.0 * coords_0[2];
  t10 = t9 + coords_0[8];
  t11 = -1.0 * coords_0[17] + coords_0[23];
  t12 = -1.0 * coords_0[5];
  t13 = t12 + coords_0[11];
  t14 = -1.0 * coords_0[13];
  t15 = t14 + coords_0[19];
  t16 = -1.0 * coords_0[1];
  t17 = t16 + coords_0[7];
  t18 = -1.0 * coords_0[16] + coords_0[22];
  t19 = -1.0 * coords_0[4];
  t20 = t19 + coords_0[10];
  t21 = t0 + coords_0[15];
  t22 = t2 + coords_0[3];
  t23 = -1.0 * coords_0[18] + coords_0[21];
  t24 = -1.0 * coords_0[6];
  t25 = t24 + coords_0[9];
  t26 = t14 + coords_0[16];
  t27 = t16 + coords_0[4];
  t28 = -1.0 * coords_0[19] + coords_0[22];
  t29 = -1.0 * coords_0[7];
  t30 = t29 + coords_0[10];
  t31 = t7 + coords_0[17];
  t32 = t9 + coords_0[5];
  t33 = -1.0 * coords_0[20] + coords_0[23];
  t34 = -1.0 * coords_0[8];
  t35 = t34 + coords_0[11];
  t36 = t34 + coords_0[20];
  t37 = t9 + coords_0[14];
  t38 = -1.0 * coords_0[11] + coords_0[23];
  t39 = t12 + coords_0[17];
  t40 = t29 + coords_0[19];
  t41 = t16 + coords_0[13];
  t42 = -1.0 * coords_0[10] + coords_0[22];
  t43 = t19 + coords_0[16];
  t44 = t24 + coords_0[18];
  t45 = t2 + coords_0[12];
  t46 = -1.0 * coords_0[9] + coords_0[21];
  t47 = t5 + coords_0[15];
  for (int32_t ip2 = 0; ip2 <= 4; ++ip2)
    for (int32_t j2 = 0; j2 <= 4; ++j2)
      for (int32_t k2 = 0; k2 <= 4; ++k2)
        t52[25 * ip2 + 5 * j2 + k2] = t51[ip2 + 5 * j2] * t51[ip2 + 5 * k2];
  for (int32_t ip1 = 0; ip1 <= 4; ++ip1)
  {
    t53 = t48[ip1] * t47 + t49[ip1] * t46;
    t54 = t48[ip1] * t45 + t49[ip1] * t44;
    t55 = t48[ip1] * t43 + t49[ip1] * t42;
    t56 = t48[ip1] * t41 + t49[ip1] * t40;
    t57 = t48[ip1] * t39 + t49[ip1] * t38;
    t58 = t48[ip1] * t37 + t49[ip1] * t36;
    for (int32_t ip2_0 = 0; ip2_0 <= 4; ++ip2_0)
    {
      t59[5 * ip1 + ip2_0] = t48[ip2_0] * t58 + t49[ip2_0] * t57;
      t60[5 * ip1 + ip2_0] = t48[ip2_0] * t56 + t49[ip2_0] * t55;
      t61[5 * ip1 + ip2_0] = t48[ip2_0] * t54 + t49[ip2_0] * t53;
    }
    for (int32_t j1 = 0; j1 <= 4; ++j1)
      for (int32_t k1 = 0; k1 <= 4; ++k1)
        t62[25 * ip1 + 5 * j1 + k1] = t51[ip1 + 5 * j1] * t51[ip1 + 5 * k1];
  }
  for (int32_t ip0 = 0; ip0 <= 4; ++ip0)
  {
    t63 = t48[ip0] * t35 + t49[ip0] * t33;
    t64 = t48[ip0] * t32 + t49[ip0] * t31;
    t65 = t48[ip0] * t30 + t49[ip0] * t28;
    t66 = t48[ip0] * t27 + t49[ip0] * t26;
    t67 = t48[ip0] * t25 + t49[ip0] * t23;
    t68 = t48[ip0] * t22 + t49[ip0] * t21;
    t69 = t48[ip0] * t20 + t49[ip0] * t18;
    t70 = t48[ip0] * t17 + t49[ip0] * t15;
    t71 = t48[ip0] * t13 + t49[ip0] * t11;
    t72 = t48[ip0] * t10 + t49[ip0] * t8;
    t73 = t48[ip0] * t6 + t49[ip0] * t4;
    t74 = t48[ip0] * t3 + t49[ip0] * t1;
    for (int32_t ip2_1 = 0; ip2_1 <= 4; ++ip2_1)
    {
      t75[ip2_1] = -1.0 * (t48[ip2_1] * t74 + t49[ip2_1] * t73);
      t76[ip2_1] = t48[ip2_1] * t72 + t49[ip2_1] * t71;
      t77[ip2_1] = t48[ip2_1] * t70 + t49[ip2_1] * t69;
    }
    for (int32_t j1_0 = 0; j1_0 <= 4; ++j1_0)
      for (int32_t j2_0 = 0; j2_0 <= 4; ++j2_0)
        for (int32_t k1_0 = 0; k1_0 <= 4; ++k1_0)
          for (int32_t k2_0 = 0; k2_0 <= 4; ++k2_0)
            t84[125 * j1_0 + 25 * j2_0 + 5 * k1_0 + k2_0] = (double) (0.0);
    for (int32_t ip1_0 = 0; ip1_0 <= 4; ++ip1_0)
    {
      t78 = t48[ip1_0] * t68 + t49[ip1_0] * t67;
      t79 = t48[ip1_0] * t66 + t49[ip1_0] * t65;
      t80 = t48[ip1_0] * t64 + t49[ip1_0] * t63;
      t81 = t50[ip0] * t50[ip1_0];
      for (int32_t j2_1 = 0; j2_1 <= 4; ++j2_1)
        for (int32_t k2_1 = 0; k2_1 <= 4; ++k2_1)
          t83[5 * j2_1 + k2_1] = (double) (0.0);
      for (int32_t ip2_2 = 0; ip2_2 <= 4; ++ip2_2)
      {
        t82 = t81 * t50[ip2_2] * fabs(t61[5 * ip1_0 + ip2_2] * (t77[ip2_2] * t80 + -1.0 * t79 * t76[ip2_2]) + (t60[5 * ip1_0 + ip2_2] * t80 + -1.0 * t79 * t59[5 * ip1_0 + ip2_2]) * t75[ip2_2] + t78 * (t60[5 * ip1_0 + ip2_2] * t76[ip2_2] + -1.0 * t77[ip2_2] * t59[5 * ip1_0 + ip2_2]));
        for (int32_t j2_2 = 0; j2_2 <= 4; ++j2_2)
          for (int32_t k2_2 = 0; k2_2 <= 4; ++k2_2)
            t83[5 * j2_2 + k2_2] = t83[5 * j2_2 + k2_2] + t82 * t52[25 * ip2_2 + 5 * j2_2 + k2_2];
      }
      for (int32_t j1_1 = 0; j1_1 <= 4; ++j1_1)
        for (int32_t j2_3 = 0; j2_3 <= 4; ++j2_3)
          for (int32_t k1_1 = 0; k1_1 <= 4; ++k1_1)
            for (int32_t k2_3 = 0; k2_3 <= 4; ++k2_3)
              t84[125 * j1_1 + 25 * j2_3 + 5 * k1_1 + k2_3] = t84[125 * j1_1 + 25 * j2_3 + 5 * k1_1 + k2_3] + t83[5 * j2_3 + k2_3] * t62[25 * ip1_0 + 5 * j1_1 + k1_1];
    }
    for (int32_t j0 = 0; j0 <= 4; ++j0)
    {
      for (int32_t k0 = 0; k0 <= 4; ++k0)
        t85[k0] = t51[ip0 + 5 * j0] * t51[ip0 + 5 * k0];
      for (int32_t j1_2 = 0; j1_2 <= 4; ++j1_2)
        for (int32_t j2_4 = 0; j2_4 <= 4; ++j2_4)
          for (int32_t k0_0 = 0; k0_0 <= 4; ++k0_0)
            for (int32_t k1_2 = 0; k1_2 <= 4; ++k1_2)
              for (int32_t k2_4 = 0; k2_4 <= 4; ++k2_4)
                A[3125 * j0 + 625 * j1_2 + 125 * j2_4 + 25 * k0_0 + 5 * k1_2 + k2_4] = A[3125 * j0 + 625 * j1_2 + 125 * j2_4 + 25 * k0_0 + 5 * k1_2 + k2_4] + t84[125 * j1_2 + 25 * j2_4 + 5 * k1_2 + k2_4] * t85[k0_0];
    }
  }

}