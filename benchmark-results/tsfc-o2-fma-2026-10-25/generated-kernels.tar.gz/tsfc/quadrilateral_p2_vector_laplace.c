#include <stdint.h>
#include <stdbool.h>
#include <math.h>

void k_cell_integral(double *__restrict__ A, double const *__restrict__ coords_0)
{
  double t0;
  double t1;
  double t10[3] = { 0.1127016653792583, 0.5, 0.8872983346207416 };
  double t11;
  double t12[3] = { 0.8872983346207416, 0.5, 0.1127016653792583 };
  double t13[3 * 3] = { -2.549193338482967, -1.0, 0.5491933384829668, 3.0983866769659336, 0.0, -3.0983866769659336, -0.5491933384829669, 1.0, 2.549193338482967 };
  double t14[3 * 3] = { 0.6872983346207417, 0.0, -0.0872983346207417, 0.4, 1.0, 0.4, -0.0872983346207417, 0.0, 0.6872983346207417 };
  double t15[3];
  double t16[3];
  double t17[3];
  double t18[3 * 3 * 3];
  double t19[3 * 3 * 3];
  double t2;
  double t20[3 * 3 * 3];
  double t21[3 * 3 * 3];
  double t22;
  double t23;
  double t24;
  double t25;
  double t26;
  double t27;
  double t28;
  double t29;
  double t3;
  double t30;
  double t31;
  double t32;
  double t33;
  double t34;
  double t35;
  double t36[3 * 3];
  double t37[3 * 3];
  double t38[3 * 3];
  double t39[3 * 3];
  double t4;
  double t40[3 * 3 * 3];
  double t41[3 * 3 * 3];
  double t42[3 * 3 * 3 * 3];
  double t5;
  double t6[3] = { 0.2777777777777779, 0.4444444444444444, 0.2777777777777779 };
  double t7;
  double t8;
  double t9;

  t0 = -1.0 * coords_0[5] + coords_0[7];
  t1 = -1.0 * coords_0[1];
  t2 = t1 + coords_0[3];
  t3 = -1.0 * coords_0[4] + coords_0[6];
  t4 = -1.0 * coords_0[0];
  t5 = t4 + coords_0[2];
  t7 = -1.0 * coords_0[2] + coords_0[6];
  t8 = t4 + coords_0[4];
  t9 = -1.0 * coords_0[3] + coords_0[7];
  t11 = t1 + coords_0[5];
  for (int32_t ip1 = 0; ip1 <= 2; ++ip1)
  {
    t15[ip1] = t12[ip1] * t11 + t10[ip1] * t9;
    t16[ip1] = -1.0 * t15[ip1];
    t17[ip1] = t12[ip1] * t8 + t10[ip1] * t7;
    for (int32_t j1 = 0; j1 <= 2; ++j1)
      for (int32_t k1 = 0; k1 <= 2; ++k1)
      {
        t18[9 * ip1 + 3 * j1 + k1] = t14[ip1 + 3 * j1] * t13[ip1 + 3 * k1];
        t19[9 * ip1 + 3 * j1 + k1] = t14[ip1 + 3 * j1] * t14[ip1 + 3 * k1];
        t20[9 * ip1 + 3 * j1 + k1] = t13[ip1 + 3 * j1] * t13[ip1 + 3 * k1];
        t21[9 * ip1 + 3 * j1 + k1] = t13[ip1 + 3 * j1] * t14[ip1 + 3 * k1];
      }
  }
  for (int32_t j0 = 0; j0 <= 2; ++j0)
    for (int32_t j1_0 = 0; j1_0 <= 2; ++j1_0)
      for (int32_t k0 = 0; k0 <= 2; ++k0)
        for (int32_t k1_0 = 0; k1_0 <= 2; ++k1_0)
          t42[27 * j0 + 9 * j1_0 + 3 * k0 + k1_0] = (double) (0.0);
  for (int32_t ip0 = 0; ip0 <= 2; ++ip0)
  {
    t22 = t12[ip0] * t5 + t10[ip0] * t3;
    t23 = -1.0 * t22;
    t24 = t12[ip0] * t2 + t10[ip0] * t0;
    for (int32_t j1_1 = 0; j1_1 <= 2; ++j1_1)
      for (int32_t k1_1 = 0; k1_1 <= 2; ++k1_1)
      {
        t39[3 * j1_1 + k1_1] = (double) (0.0);
        t38[3 * j1_1 + k1_1] = (double) (0.0);
        t37[3 * j1_1 + k1_1] = (double) (0.0);
        t36[3 * j1_1 + k1_1] = (double) (0.0);
      }
    for (int32_t ip1_0 = 0; ip1_0 <= 2; ++ip1_0)
    {
      t25 = t17[ip1_0] * t24 + -1.0 * t22 * t15[ip1_0];
      t26 = t6[ip0] * t6[ip1_0] * fabs(t25);
      t27 = 1.0 / t25;
      t28 = t16[ip1_0] * t27;
      t29 = t24 * t27;
      t30 = t17[ip1_0] * t27;
      t31 = t23 * t27;
      t32 = t26 * (t28 * t29 + t30 * t31);
      t33 = t26 * (t29 * t29 + t31 * t31);
      t34 = t26 * (t28 * t28 + t30 * t30);
      t35 = t26 * (t29 * t28 + t31 * t30);
      for (int32_t j1_2 = 0; j1_2 <= 2; ++j1_2)
        for (int32_t k1_2 = 0; k1_2 <= 2; ++k1_2)
        {
          t36[3 * j1_2 + k1_2] = t36[3 * j1_2 + k1_2] + t35 * t21[9 * ip1_0 + 3 * j1_2 + k1_2];
          t37[3 * j1_2 + k1_2] = t37[3 * j1_2 + k1_2] + t34 * t20[9 * ip1_0 + 3 * j1_2 + k1_2];
          t38[3 * j1_2 + k1_2] = t38[3 * j1_2 + k1_2] + t33 * t19[9 * ip1_0 + 3 * j1_2 + k1_2];
          t39[3 * j1_2 + k1_2] = t39[3 * j1_2 + k1_2] + t32 * t18[9 * ip1_0 + 3 * j1_2 + k1_2];
        }
    }
    for (int32_t j1_3 = 0; j1_3 <= 2; ++j1_3)
      for (int32_t k0_0 = 0; k0_0 <= 2; ++k0_0)
        for (int32_t k1_3 = 0; k1_3 <= 2; ++k1_3)
        {
          t40[9 * j1_3 + 3 * k0_0 + k1_3] = t13[ip0 + 3 * k0_0] * t36[3 * j1_3 + k1_3] + t14[ip0 + 3 * k0_0] * t37[3 * j1_3 + k1_3];
          t41[9 * j1_3 + 3 * k0_0 + k1_3] = t13[ip0 + 3 * k0_0] * t38[3 * j1_3 + k1_3] + t14[ip0 + 3 * k0_0] * t39[3 * j1_3 + k1_3];
        }
    for (int32_t j0_0 = 0; j0_0 <= 2; ++j0_0)
      for (int32_t j1_4 = 0; j1_4 <= 2; ++j1_4)
        for (int32_t k0_1 = 0; k0_1 <= 2; ++k0_1)
          for (int32_t k1_4 = 0; k1_4 <= 2; ++k1_4)
            t42[27 * j0_0 + 9 * j1_4 + 3 * k0_1 + k1_4] = t42[27 * j0_0 + 9 * j1_4 + 3 * k0_1 + k1_4] + t41[9 * j1_4 + 3 * k0_1 + k1_4] * t13[ip0 + 3 * j0_0] + t40[9 * j1_4 + 3 * k0_1 + k1_4] * t14[ip0 + 3 * j0_0];
  }
  for (int32_t j0_1 = 0; j0_1 <= 2; ++j0_1)
    for (int32_t j1_5 = 0; j1_5 <= 2; ++j1_5)
      for (int32_t k0_2 = 0; k0_2 <= 2; ++k0_2)
        for (int32_t k1_5 = 0; k1_5 <= 2; ++k1_5)
        {
          A[108 * j0_1 + 36 * j1_5 + 6 * k0_2 + 2 * k1_5] = A[108 * j0_1 + 36 * j1_5 + 6 * k0_2 + 2 * k1_5] + t42[27 * j0_1 + 9 * j1_5 + 3 * k0_2 + k1_5];
          A[19 + 108 * j0_1 + 36 * j1_5 + 6 * k0_2 + 2 * k1_5] = A[19 + 108 * j0_1 + 36 * j1_5 + 6 * k0_2 + 2 * k1_5] + t42[27 * j0_1 + 9 * j1_5 + 3 * k0_2 + k1_5];
        }

}