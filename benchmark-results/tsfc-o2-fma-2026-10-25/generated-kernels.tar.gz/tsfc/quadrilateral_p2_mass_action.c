#include <stdint.h>
#include <stdbool.h>
#include <math.h>

void k_cell_integral(double *__restrict__ A, double const *__restrict__ coords_0, double const *__restrict__ w_0)
{
  double t0;
  double t1;
  double t10;
  double t11[3] = { 0.1127016653792583, 0.5, 0.8872983346207416 };
  double t12;
  double t13[3] = { 0.8872983346207416, 0.5, 0.1127016653792583 };
  double t14[3] = { 0.6872983346207417, 0.0, -0.0872983346207417 };
  double t15[3] = { 0.4, 1.0, 0.4 };
  double t16[3] = { -0.0872983346207417, 0.0, 0.6872983346207417 };
  double t17[3];
  double t18[3];
  double t19;
  double t2;
  double t20;
  double t21;
  double t22;
  double t23;
  double t24;
  double t25[3];
  double t3;
  double t4;
  double t5;
  double t6[3 * 3] = { 0.6872983346207417, 0.0, -0.0872983346207417, 0.4, 1.0, 0.4, -0.0872983346207417, 0.0, 0.6872983346207417 };
  double t7[3] = { 0.2777777777777779, 0.4444444444444444, 0.2777777777777779 };
  double t8;
  double t9;

  t0 = -1.0 * coords_0[5] + coords_0[7];
  t1 = -1.0 * coords_0[1];
  t2 = t1 + coords_0[3];
  t3 = -1.0 * coords_0[4] + coords_0[6];
  t4 = -1.0 * coords_0[0];
  t5 = t4 + coords_0[2];
  t8 = -1.0 * coords_0[2] + coords_0[6];
  t9 = t4 + coords_0[4];
  t10 = -1.0 * coords_0[3] + coords_0[7];
  t12 = t1 + coords_0[5];
  for (int32_t ip1 = 0; ip1 <= 2; ++ip1)
  {
    t17[ip1] = t13[ip1] * t12 + t11[ip1] * t10;
    t18[ip1] = t13[ip1] * t9 + t11[ip1] * t8;
  }
  for (int32_t ip0 = 0; ip0 <= 2; ++ip0)
  {
    t19 = t14[ip0] * w_0[2] + t15[ip0] * w_0[5] + t16[ip0] * w_0[8];
    t20 = t14[ip0] * w_0[1] + t15[ip0] * w_0[4] + t16[ip0] * w_0[7];
    t21 = t14[ip0] * w_0[0] + t15[ip0] * w_0[3] + t16[ip0] * w_0[6];
    t22 = t13[ip0] * t5 + t11[ip0] * t3;
    t23 = t13[ip0] * t2 + t11[ip0] * t0;
    for (int32_t j1 = 0; j1 <= 2; ++j1)
      t25[j1] = (double) (0.0);
    for (int32_t ip1_0 = 0; ip1_0 <= 2; ++ip1_0)
    {
      t24 = t7[ip0] * t7[ip1_0] * fabs(t18[ip1_0] * t23 + -1.0 * t22 * t17[ip1_0]) * (t14[ip1_0] * t21 + t15[ip1_0] * t20 + t16[ip1_0] * t19);
      for (int32_t j1_0 = 0; j1_0 <= 2; ++j1_0)
        t25[j1_0] = t25[j1_0] + t6[ip1_0 + 3 * j1_0] * t24;
    }
    for (int32_t j0 = 0; j0 <= 2; ++j0)
      for (int32_t j1_1 = 0; j1_1 <= 2; ++j1_1)
        A[3 * j0 + j1_1] = A[3 * j0 + j1_1] + t6[ip0 + 3 * j0] * t25[j1_1];
  }

}