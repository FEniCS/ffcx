#include <stdint.h>
#include <stdbool.h>
#include <math.h>

void k_cell_integral(double *__restrict__ A, double const *__restrict__ coords_0)
{
  double t0;
  double t1;
  double t10[3] = { 0.1127016653792583, 0.5, 0.8872983346207416 };
  double t100[3 * 3 * 3];
  double t101[3 * 3 * 3];
  double t102[3 * 3 * 3];
  double t103[3 * 3 * 3];
  double t104[3 * 3 * 3];
  double t105[3 * 3 * 3];
  double t106[3 * 3 * 3];
  double t107[3 * 3 * 3];
  double t11;
  double t12[3] = { 0.8872983346207416, 0.5, 0.1127016653792583 };
  double t13[3 * 3] = { -2.549193338482967, -1.0, 0.5491933384829668, 3.0983866769659336, 0.0, -3.0983866769659336, -0.5491933384829669, 1.0, 2.549193338482967 };
  double t14[3 * 3] = { 0.6872983346207417, 0.0, -0.0872983346207417, 0.4, 1.0, 0.4, -0.0872983346207417, 0.0, 0.6872983346207417 };
  double t15[3];
  double t16[3];
  double t17[3];
  double t18[3 * 3 * 3];
  double t19[3 * 3 * 3];
  double t2;
  double t20[3 * 3 * 3];
  double t21[3 * 3 * 3];
  double t22;
  double t23;
  double t24;
  double t25;
  double t26;
  double t27;
  double t28;
  double t29;
  double t3;
  double t30;
  double t31;
  double t32;
  double t33;
  double t34;
  double t35;
  double t36;
  double t37;
  double t38;
  double t39;
  double t4;
  double t40;
  double t41;
  double t42;
  double t43;
  double t44;
  double t45;
  double t46;
  double t47;
  double t48;
  double t49;
  double t5;
  double t50;
  double t51;
  double t52;
  double t53;
  double t54;
  double t55;
  double t56;
  double t57;
  double t58;
  double t59;
  double t6[3] = { 0.2777777777777779, 0.4444444444444444, 0.2777777777777779 };
  double t60;
  double t61;
  double t62;
  double t63;
  double t64;
  double t65;
  double t66;
  double t67;
  double t68;
  double t69;
  double t7;
  double t70;
  double t71;
  double t72;
  double t73;
  double t74;
  double t75;
  double t76;
  double t77;
  double t78;
  double t79;
  double t8;
  double t80;
  double t81;
  double t82;
  double t83;
  double t84[3 * 3];
  double t85[3 * 3];
  double t86[3 * 3];
  double t87[3 * 3];
  double t88[3 * 3];
  double t89[3 * 3];
  double t9;
  double t90[3 * 3];
  double t91[3 * 3];
  double t92[3 * 3];
  double t93[3 * 3];
  double t94[3 * 3];
  double t95[3 * 3];
  double t96[3 * 3];
  double t97[3 * 3];
  double t98[3 * 3];
  double t99[3 * 3];

  t0 = -1.0 * coords_0[5] + coords_0[7];
  t1 = -1.0 * coords_0[1];
  t2 = t1 + coords_0[3];
  t3 = -1.0 * coords_0[4] + coords_0[6];
  t4 = -1.0 * coords_0[0];
  t5 = t4 + coords_0[2];
  t7 = -1.0 * coords_0[2] + coords_0[6];
  t8 = t4 + coords_0[4];
  t9 = -1.0 * coords_0[3] + coords_0[7];
  t11 = t1 + coords_0[5];
  for (int32_t ip1 = 0; ip1 <= 2; ++ip1)
  {
    t15[ip1] = t12[ip1] * t11 + t10[ip1] * t9;
    t16[ip1] = -1.0 * t15[ip1];
    t17[ip1] = t12[ip1] * t8 + t10[ip1] * t7;
    for (int32_t j1 = 0; j1 <= 2; ++j1)
      for (int32_t k1 = 0; k1 <= 2; ++k1)
      {
        t18[9 * ip1 + 3 * j1 + k1] = t14[ip1 + 3 * j1] * t13[ip1 + 3 * k1];
        t19[9 * ip1 + 3 * j1 + k1] = t14[ip1 + 3 * j1] * t14[ip1 + 3 * k1];
        t20[9 * ip1 + 3 * j1 + k1] = t13[ip1 + 3 * j1] * t13[ip1 + 3 * k1];
        t21[9 * ip1 + 3 * j1 + k1] = t13[ip1 + 3 * j1] * t14[ip1 + 3 * k1];
      }
  }
  for (int32_t ip0 = 0; ip0 <= 2; ++ip0)
  {
    t22 = t12[ip0] * t5 + t10[ip0] * t3;
    t23 = -1.0 * t22;
    t24 = t12[ip0] * t2 + t10[ip0] * t0;
    for (int32_t j1_0 = 0; j1_0 <= 2; ++j1_0)
      for (int32_t k1_0 = 0; k1_0 <= 2; ++k1_0)
      {
        t99[3 * j1_0 + k1_0] = (double) (0.0);
        t98[3 * j1_0 + k1_0] = (double) (0.0);
        t97[3 * j1_0 + k1_0] = (double) (0.0);
        t96[3 * j1_0 + k1_0] = (double) (0.0);
        t95[3 * j1_0 + k1_0] = (double) (0.0);
        t94[3 * j1_0 + k1_0] = (double) (0.0);
        t93[3 * j1_0 + k1_0] = (double) (0.0);
        t92[3 * j1_0 + k1_0] = (double) (0.0);
        t91[3 * j1_0 + k1_0] = (double) (0.0);
        t90[3 * j1_0 + k1_0] = (double) (0.0);
        t89[3 * j1_0 + k1_0] = (double) (0.0);
        t88[3 * j1_0 + k1_0] = (double) (0.0);
        t87[3 * j1_0 + k1_0] = (double) (0.0);
        t86[3 * j1_0 + k1_0] = (double) (0.0);
        t85[3 * j1_0 + k1_0] = (double) (0.0);
        t84[3 * j1_0 + k1_0] = (double) (0.0);
      }
    for (int32_t ip1_0 = 0; ip1_0 <= 2; ++ip1_0)
    {
      t25 = t17[ip1_0] * t24 + -1.0 * t22 * t15[ip1_0];
      t26 = t6[ip0] * t6[ip1_0] * fabs(t25);
      t27 = 1.0 / t25;
      t28 = t16[ip1_0] * t27;
      t29 = t24 * t27;
      t30 = t28 * t29;
      t31 = t28 + t28;
      t32 = t29 + t29;
      t33 = t17[ip1_0] * t27;
      t34 = t23 * t27;
      t35 = t33 * t34;
      t36 = 0.25 * t35;
      t37 = t26 * (t30 + 0.25 * t31 * t32 + t36 + t36);
      t38 = t29 * t29;
      t39 = t34 * t34;
      t40 = 0.25 * t39;
      t41 = t26 * (t38 + 0.25 * t32 * t32 + t40 + t40);
      t42 = t28 * t28;
      t43 = t33 * t33;
      t44 = 0.25 * t43;
      t45 = t26 * (t42 + 0.25 * t31 * t31 + t44 + t44);
      t46 = t29 * t28;
      t47 = t34 * t33;
      t48 = 0.25 * t47;
      t49 = t26 * (t46 + 0.25 * t32 * t31 + t48 + t48);
      t50 = t33 * t29;
      t51 = t28 * t34;
      t52 = 0.25 * t51;
      t53 = t26 * (t50 + t52 + t52);
      t54 = t34 * t29;
      t55 = t29 * t34;
      t56 = 0.25 * t55;
      t57 = t26 * (t54 + t56 + t56);
      t58 = t33 * t28;
      t59 = t28 * t33;
      t60 = 0.25 * t59;
      t61 = t26 * (t58 + t60 + t60);
      t62 = t34 * t28;
      t63 = t29 * t33;
      t64 = 0.25 * t63;
      t65 = t26 * (t62 + t64 + t64);
      t66 = 0.25 * t50;
      t67 = t26 * (t51 + t66 + t66);
      t68 = 0.25 * t54;
      t69 = t26 * (t55 + t68 + t68);
      t70 = 0.25 * t58;
      t71 = t26 * (t59 + t70 + t70);
      t72 = 0.25 * t62;
      t73 = t26 * (t63 + t72 + t72);
      t74 = 0.25 * t30;
      t75 = t33 + t33;
      t76 = t34 + t34;
      t77 = t26 * (t35 + t74 + t74 + 0.25 * t75 * t76);
      t78 = 0.25 * t38;
      t79 = t26 * (t39 + t78 + t78 + 0.25 * t76 * t76);
      t80 = 0.25 * t42;
      t81 = t26 * (t43 + t80 + t80 + 0.25 * t75 * t75);
      t82 = 0.25 * t46;
      t83 = t26 * (t47 + t82 + t82 + 0.25 * t76 * t75);
      for (int32_t j1_1 = 0; j1_1 <= 2; ++j1_1)
        for (int32_t k1_1 = 0; k1_1 <= 2; ++k1_1)
        {
          t84[3 * j1_1 + k1_1] = t84[3 * j1_1 + k1_1] + t83 * t21[9 * ip1_0 + 3 * j1_1 + k1_1];
          t85[3 * j1_1 + k1_1] = t85[3 * j1_1 + k1_1] + t81 * t20[9 * ip1_0 + 3 * j1_1 + k1_1];
          t86[3 * j1_1 + k1_1] = t86[3 * j1_1 + k1_1] + t79 * t19[9 * ip1_0 + 3 * j1_1 + k1_1];
          t87[3 * j1_1 + k1_1] = t87[3 * j1_1 + k1_1] + t77 * t18[9 * ip1_0 + 3 * j1_1 + k1_1];
          t88[3 * j1_1 + k1_1] = t88[3 * j1_1 + k1_1] + t73 * t21[9 * ip1_0 + 3 * j1_1 + k1_1];
          t89[3 * j1_1 + k1_1] = t89[3 * j1_1 + k1_1] + t71 * t20[9 * ip1_0 + 3 * j1_1 + k1_1];
          t90[3 * j1_1 + k1_1] = t90[3 * j1_1 + k1_1] + t69 * t19[9 * ip1_0 + 3 * j1_1 + k1_1];
          t91[3 * j1_1 + k1_1] = t91[3 * j1_1 + k1_1] + t67 * t18[9 * ip1_0 + 3 * j1_1 + k1_1];
          t92[3 * j1_1 + k1_1] = t92[3 * j1_1 + k1_1] + t65 * t21[9 * ip1_0 + 3 * j1_1 + k1_1];
          t93[3 * j1_1 + k1_1] = t93[3 * j1_1 + k1_1] + t61 * t20[9 * ip1_0 + 3 * j1_1 + k1_1];
          t94[3 * j1_1 + k1_1] = t94[3 * j1_1 + k1_1] + t57 * t19[9 * ip1_0 + 3 * j1_1 + k1_1];
          t95[3 * j1_1 + k1_1] = t95[3 * j1_1 + k1_1] + t53 * t18[9 * ip1_0 + 3 * j1_1 + k1_1];
          t96[3 * j1_1 + k1_1] = t96[3 * j1_1 + k1_1] + t49 * t21[9 * ip1_0 + 3 * j1_1 + k1_1];
          t97[3 * j1_1 + k1_1] = t97[3 * j1_1 + k1_1] + t45 * t20[9 * ip1_0 + 3 * j1_1 + k1_1];
          t98[3 * j1_1 + k1_1] = t98[3 * j1_1 + k1_1] + t41 * t19[9 * ip1_0 + 3 * j1_1 + k1_1];
          t99[3 * j1_1 + k1_1] = t99[3 * j1_1 + k1_1] + t37 * t18[9 * ip1_0 + 3 * j1_1 + k1_1];
        }
    }
    for (int32_t j1_2 = 0; j1_2 <= 2; ++j1_2)
      for (int32_t k0 = 0; k0 <= 2; ++k0)
        for (int32_t k1_2 = 0; k1_2 <= 2; ++k1_2)
        {
          t100[9 * j1_2 + 3 * k0 + k1_2] = t13[ip0 + 3 * k0] * t84[3 * j1_2 + k1_2] + t14[ip0 + 3 * k0] * t85[3 * j1_2 + k1_2];
          t101[9 * j1_2 + 3 * k0 + k1_2] = t13[ip0 + 3 * k0] * t86[3 * j1_2 + k1_2] + t14[ip0 + 3 * k0] * t87[3 * j1_2 + k1_2];
          t102[9 * j1_2 + 3 * k0 + k1_2] = t13[ip0 + 3 * k0] * t88[3 * j1_2 + k1_2] + t14[ip0 + 3 * k0] * t89[3 * j1_2 + k1_2];
          t103[9 * j1_2 + 3 * k0 + k1_2] = t13[ip0 + 3 * k0] * t90[3 * j1_2 + k1_2] + t14[ip0 + 3 * k0] * t91[3 * j1_2 + k1_2];
          t104[9 * j1_2 + 3 * k0 + k1_2] = t13[ip0 + 3 * k0] * t92[3 * j1_2 + k1_2] + t14[ip0 + 3 * k0] * t93[3 * j1_2 + k1_2];
          t105[9 * j1_2 + 3 * k0 + k1_2] = t13[ip0 + 3 * k0] * t94[3 * j1_2 + k1_2] + t14[ip0 + 3 * k0] * t95[3 * j1_2 + k1_2];
          t106[9 * j1_2 + 3 * k0 + k1_2] = t13[ip0 + 3 * k0] * t96[3 * j1_2 + k1_2] + t14[ip0 + 3 * k0] * t97[3 * j1_2 + k1_2];
          t107[9 * j1_2 + 3 * k0 + k1_2] = t13[ip0 + 3 * k0] * t98[3 * j1_2 + k1_2] + t14[ip0 + 3 * k0] * t99[3 * j1_2 + k1_2];
        }
    for (int32_t j0 = 0; j0 <= 2; ++j0)
      for (int32_t j1_3 = 0; j1_3 <= 2; ++j1_3)
        for (int32_t k0_0 = 0; k0_0 <= 2; ++k0_0)
          for (int32_t k1_3 = 0; k1_3 <= 2; ++k1_3)
          {
            A[108 * j0 + 36 * j1_3 + 6 * k0_0 + 2 * k1_3] = A[108 * j0 + 36 * j1_3 + 6 * k0_0 + 2 * k1_3] + t107[9 * j1_3 + 3 * k0_0 + k1_3] * t13[ip0 + 3 * j0] + t106[9 * j1_3 + 3 * k0_0 + k1_3] * t14[ip0 + 3 * j0];
            A[1 + 108 * j0 + 36 * j1_3 + 6 * k0_0 + 2 * k1_3] = A[1 + 108 * j0 + 36 * j1_3 + 6 * k0_0 + 2 * k1_3] + t105[9 * j1_3 + 3 * k0_0 + k1_3] * t13[ip0 + 3 * j0] + t104[9 * j1_3 + 3 * k0_0 + k1_3] * t14[ip0 + 3 * j0];
            A[18 + 108 * j0 + 36 * j1_3 + 6 * k0_0 + 2 * k1_3] = A[18 + 108 * j0 + 36 * j1_3 + 6 * k0_0 + 2 * k1_3] + t103[9 * j1_3 + 3 * k0_0 + k1_3] * t13[ip0 + 3 * j0] + t102[9 * j1_3 + 3 * k0_0 + k1_3] * t14[ip0 + 3 * j0];
            A[19 + 108 * j0 + 36 * j1_3 + 6 * k0_0 + 2 * k1_3] = A[19 + 108 * j0 + 36 * j1_3 + 6 * k0_0 + 2 * k1_3] + t101[9 * j1_3 + 3 * k0_0 + k1_3] * t13[ip0 + 3 * j0] + t100[9 * j1_3 + 3 * k0_0 + k1_3] * t14[ip0 + 3 * j0];
          }
  }

}