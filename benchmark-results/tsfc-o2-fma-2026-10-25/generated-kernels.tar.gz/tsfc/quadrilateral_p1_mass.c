#include <stdint.h>
#include <stdbool.h>
#include <math.h>

void k_cell_integral(double *__restrict__ A, double const *__restrict__ coords_0)
{
  double t0;
  double t1;
  double t10[2] = { 0.21132486540518713, 0.7886751345948128 };
  double t11;
  double t12[2] = { 0.7886751345948128, 0.21132486540518713 };
  double t13[2 * 2] = { 0.7886751345948128, 0.21132486540518713, 0.21132486540518713, 0.7886751345948128 };
  double t14[2];
  double t15[2];
  double t16[2 * 2 * 2];
  double t17;
  double t18;
  double t19;
  double t2;
  double t20[2 * 2];
  double t21[2];
  double t3;
  double t4;
  double t5;
  double t6[2] = { 0.4999999999999999, 0.4999999999999999 };
  double t7;
  double t8;
  double t9;

  t0 = -1.0 * coords_0[5] + coords_0[7];
  t1 = -1.0 * coords_0[1];
  t2 = t1 + coords_0[3];
  t3 = -1.0 * coords_0[4] + coords_0[6];
  t4 = -1.0 * coords_0[0];
  t5 = t4 + coords_0[2];
  t7 = -1.0 * coords_0[2] + coords_0[6];
  t8 = t4 + coords_0[4];
  t9 = -1.0 * coords_0[3] + coords_0[7];
  t11 = t1 + coords_0[5];
  for (int32_t ip1 = 0; ip1 <= 1; ++ip1)
  {
    t14[ip1] = t12[ip1] * t11 + t10[ip1] * t9;
    t15[ip1] = t12[ip1] * t8 + t10[ip1] * t7;
    for (int32_t j1 = 0; j1 <= 1; ++j1)
      for (int32_t k1 = 0; k1 <= 1; ++k1)
        t16[4 * ip1 + 2 * j1 + k1] = t13[ip1 + 2 * j1] * t13[ip1 + 2 * k1];
  }
  for (int32_t ip0 = 0; ip0 <= 1; ++ip0)
  {
    t17 = t12[ip0] * t5 + t10[ip0] * t3;
    t18 = t12[ip0] * t2 + t10[ip0] * t0;
    for (int32_t j1_0 = 0; j1_0 <= 1; ++j1_0)
      for (int32_t k1_0 = 0; k1_0 <= 1; ++k1_0)
        t20[2 * j1_0 + k1_0] = (double) (0.0);
    for (int32_t ip1_0 = 0; ip1_0 <= 1; ++ip1_0)
    {
      t19 = t6[ip0] * t6[ip1_0] * fabs(t15[ip1_0] * t18 + -1.0 * t17 * t14[ip1_0]);
      for (int32_t j1_1 = 0; j1_1 <= 1; ++j1_1)
        for (int32_t k1_1 = 0; k1_1 <= 1; ++k1_1)
          t20[2 * j1_1 + k1_1] = t20[2 * j1_1 + k1_1] + t19 * t16[4 * ip1_0 + 2 * j1_1 + k1_1];
    }
    for (int32_t j0 = 0; j0 <= 1; ++j0)
    {
      for (int32_t k0 = 0; k0 <= 1; ++k0)
        t21[k0] = t13[ip0 + 2 * j0] * t13[ip0 + 2 * k0];
      for (int32_t j1_2 = 0; j1_2 <= 1; ++j1_2)
        for (int32_t k0_0 = 0; k0_0 <= 1; ++k0_0)
          for (int32_t k1_2 = 0; k1_2 <= 1; ++k1_2)
            A[8 * j0 + 4 * j1_2 + 2 * k0_0 + k1_2] = A[8 * j0 + 4 * j1_2 + 2 * k0_0 + k1_2] + t20[2 * j1_2 + k1_2] * t21[k0_0];
    }
  }

}