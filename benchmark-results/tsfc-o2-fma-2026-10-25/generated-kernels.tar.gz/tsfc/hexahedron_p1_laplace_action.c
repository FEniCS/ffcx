#include <stdint.h>
#include <stdbool.h>
#include <math.h>

void k_cell_integral(double *__restrict__ A, double const *__restrict__ coords_0, double const *__restrict__ w_0)
{
  double t0;
  double t1;
  double t10;
  double t100[2];
  double t101;
  double t102;
  double t103;
  double t104;
  double t105;
  double t106;
  double t107;
  double t108;
  double t109;
  double t11;
  double t110;
  double t111;
  double t112[2 * 2 * 2];
  double t113;
  double t114;
  double t115[2 * 2 * 2];
  double t116[2 * 2 * 2];
  double t117[2 * 2 * 2];
  double t118;
  double t119[2 * 2 * 2];
  double t12;
  double t120[2 * 2 * 2];
  double t121[2 * 2 * 2];
  double t122;
  double t123[2 * 2 * 2];
  double t124[2 * 2 * 2];
  double t125[2 * 2 * 2];
  double t126[2 * 2];
  double t127[2];
  double t128[2 * 2];
  double t129[2] = { -1.0, 1.0 };
  double t13;
  double t130[2];
  double t131[2];
  double t132;
  double t133[2];
  double t134[2 * 2];
  double t135[2 * 2];
  double t14;
  double t15;
  double t16;
  double t17;
  double t18;
  double t19;
  double t2;
  double t20;
  double t21;
  double t22;
  double t23;
  double t24;
  double t25;
  double t26;
  double t27;
  double t28[2] = { 0.7886751345948128, 0.21132486540518713 };
  double t29[2] = { 0.21132486540518713, 0.7886751345948128 };
  double t3;
  double t30[2] = { 0.4999999999999999, 0.4999999999999999 };
  double t31;
  double t32;
  double t33;
  double t34;
  double t35;
  double t36;
  double t37;
  double t38;
  double t39[2 * 2];
  double t4;
  double t40[2 * 2];
  double t41[2 * 2];
  double t42[2 * 2];
  double t43[2 * 2] = { 0.7886751345948128, 0.21132486540518713, 0.21132486540518713, 0.7886751345948128 };
  double t44;
  double t45;
  double t46;
  double t47;
  double t48;
  double t49;
  double t5;
  double t50;
  double t51;
  double t52;
  double t53;
  double t54;
  double t55;
  double t56;
  double t57;
  double t58;
  double t59;
  double t6;
  double t60;
  double t61;
  double t62;
  double t63;
  double t64;
  double t65;
  double t66;
  double t67;
  double t68;
  double t69;
  double t7;
  double t70;
  double t71;
  double t72;
  double t73;
  double t74;
  double t75;
  double t76;
  double t77;
  double t78;
  double t79;
  double t8;
  double t80;
  double t81;
  double t82;
  double t83;
  double t84;
  double t85;
  double t86;
  double t87;
  double t88;
  double t89;
  double t9;
  double t90;
  double t91;
  double t92;
  double t93;
  double t94;
  double t95;
  double t96[2];
  double t97[2];
  double t98[2];
  double t99[2];

  t0 = -1.0 * w_0[2];
  t1 = t0 + w_0[6];
  t2 = -1.0 * w_0[0];
  t3 = t2 + w_0[4];
  t4 = -1.0 * w_0[3] + w_0[7];
  t5 = -1.0 * w_0[1];
  t6 = t5 + w_0[5];
  t7 = -1.0 * coords_0[8];
  t8 = t7 + coords_0[20];
  t9 = -1.0 * coords_0[2];
  t10 = t9 + coords_0[14];
  t11 = -1.0 * coords_0[11] + coords_0[23];
  t12 = -1.0 * coords_0[5];
  t13 = t12 + coords_0[17];
  t14 = -1.0 * coords_0[7];
  t15 = t14 + coords_0[19];
  t16 = -1.0 * coords_0[1];
  t17 = t16 + coords_0[13];
  t18 = -1.0 * coords_0[10] + coords_0[22];
  t19 = -1.0 * coords_0[4];
  t20 = t19 + coords_0[16];
  t21 = -1.0 * coords_0[6];
  t22 = t21 + coords_0[18];
  t23 = -1.0 * coords_0[0];
  t24 = t23 + coords_0[12];
  t25 = -1.0 * coords_0[9] + coords_0[21];
  t26 = -1.0 * coords_0[3];
  t27 = t26 + coords_0[15];
  for (int32_t ip1 = 0; ip1 <= 1; ++ip1)
  {
    t31 = t28[ip1] * t27 + t29[ip1] * t25;
    t32 = t28[ip1] * t24 + t29[ip1] * t22;
    t33 = t28[ip1] * t20 + t29[ip1] * t18;
    t34 = t28[ip1] * t17 + t29[ip1] * t15;
    t35 = t28[ip1] * t13 + t29[ip1] * t11;
    t36 = t28[ip1] * t10 + t29[ip1] * t8;
    t37 = t28[ip1] * t6 + t29[ip1] * t4;
    t38 = t28[ip1] * t3 + t29[ip1] * t1;
    for (int32_t ip2 = 0; ip2 <= 1; ++ip2)
    {
      t126[2 * ip1 + ip2] = (double) (0.0);
      t39[2 * ip1 + ip2] = t28[ip2] * t38 + t29[ip2] * t37;
      t40[2 * ip1 + ip2] = t28[ip2] * t36 + t29[ip2] * t35;
      t41[2 * ip1 + ip2] = t28[ip2] * t34 + t29[ip2] * t33;
      t42[2 * ip1 + ip2] = t28[ip2] * t32 + t29[ip2] * t31;
    }
  }
  t44 = -1.0 * w_0[4];
  t45 = t44 + w_0[6];
  t46 = t2 + w_0[2];
  t47 = -1.0 * w_0[5] + w_0[7];
  t48 = t5 + w_0[3];
  t49 = -1.0 * coords_0[12];
  t50 = t49 + coords_0[18];
  t51 = t23 + coords_0[6];
  t52 = -1.0 * coords_0[15] + coords_0[21];
  t53 = t26 + coords_0[9];
  t54 = -1.0 * coords_0[14];
  t55 = t54 + coords_0[20];
  t56 = t9 + coords_0[8];
  t57 = -1.0 * coords_0[17] + coords_0[23];
  t58 = t12 + coords_0[11];
  t59 = -1.0 * coords_0[13];
  t60 = t59 + coords_0[19];
  t61 = t16 + coords_0[7];
  t62 = -1.0 * coords_0[16] + coords_0[22];
  t63 = t19 + coords_0[10];
  t64 = t49 + coords_0[15];
  t65 = t23 + coords_0[3];
  t66 = -1.0 * coords_0[18] + coords_0[21];
  t67 = t21 + coords_0[9];
  t68 = t44 + w_0[5];
  t69 = t2 + w_0[1];
  t70 = -1.0 * w_0[6] + w_0[7];
  t71 = t0 + w_0[3];
  t72 = t54 + coords_0[17];
  t73 = t9 + coords_0[5];
  t74 = -1.0 * coords_0[20] + coords_0[23];
  t75 = t7 + coords_0[11];
  t76 = t59 + coords_0[16];
  t77 = t16 + coords_0[4];
  t78 = -1.0 * coords_0[19] + coords_0[22];
  t79 = t14 + coords_0[10];
  for (int32_t ip0 = 0; ip0 <= 1; ++ip0)
  {
    t80 = t28[ip0] * t79 + t29[ip0] * t78;
    t81 = t28[ip0] * t77 + t29[ip0] * t76;
    t82 = t28[ip0] * t75 + t29[ip0] * t74;
    t83 = t28[ip0] * t73 + t29[ip0] * t72;
    t84 = t28[ip0] * t71 + t29[ip0] * t70;
    t85 = t28[ip0] * t69 + t29[ip0] * t68;
    t86 = t28[ip0] * t67 + t29[ip0] * t66;
    t87 = t28[ip0] * t65 + t29[ip0] * t64;
    t88 = t28[ip0] * t63 + t29[ip0] * t62;
    t89 = t28[ip0] * t61 + t29[ip0] * t60;
    t90 = t28[ip0] * t58 + t29[ip0] * t57;
    t91 = t28[ip0] * t56 + t29[ip0] * t55;
    t92 = t28[ip0] * t53 + t29[ip0] * t52;
    t93 = t28[ip0] * t51 + t29[ip0] * t50;
    t94 = t28[ip0] * t48 + t29[ip0] * t47;
    t95 = t28[ip0] * t46 + t29[ip0] * t45;
    for (int32_t ip2_0 = 0; ip2_0 <= 1; ++ip2_0)
    {
      t96[ip2_0] = t28[ip2_0] * t95 + t29[ip2_0] * t94;
      t97[ip2_0] = t28[ip2_0] * t93 + t29[ip2_0] * t92;
      t98[ip2_0] = -1.0 * t97[ip2_0];
      t99[ip2_0] = t28[ip2_0] * t91 + t29[ip2_0] * t90;
      t100[ip2_0] = t28[ip2_0] * t89 + t29[ip2_0] * t88;
    }
    for (int32_t ip1_0 = 0; ip1_0 <= 1; ++ip1_0)
    {
      t101 = t28[ip1_0] * t87 + t29[ip1_0] * t86;
      t102 = -1.0 * t101;
      t103 = t28[ip1_0] * t85 + t29[ip1_0] * t84;
      t104 = t28[ip1_0] * t83 + t29[ip1_0] * t82;
      t105 = -1.0 * t104;
      t106 = t28[ip1_0] * t81 + t29[ip1_0] * t80;
      t107 = t30[ip0] * t30[ip1_0];
      for (int32_t ip2_1 = 0; ip2_1 <= 1; ++ip2_1)
      {
        t108 = t100[ip2_1] * t104 + -1.0 * t106 * t99[ip2_1];
        t109 = t106 * t40[2 * ip1_0 + ip2_1];
        t110 = t41[2 * ip1_0 + ip2_1] * t99[ip2_1] + -1.0 * t100[ip2_1] * t40[2 * ip1_0 + ip2_1];
        t111 = t42[2 * ip1_0 + ip2_1] * t108 + (t41[2 * ip1_0 + ip2_1] * t104 + -1.0 * t109) * t98[ip2_1] + t101 * t110;
        t112[4 * ip0 + 2 * ip1_0 + ip2_1] = t107 * t30[ip2_1] * fabs(t111);
        t113 = 1.0 / t111;
        t114 = t108 * t113;
        t115[4 * ip0 + 2 * ip1_0 + ip2_1] = (t109 + t41[2 * ip1_0 + ip2_1] * t105) * t113;
        t116[4 * ip0 + 2 * ip1_0 + ip2_1] = t110 * t113;
        t117[4 * ip0 + 2 * ip1_0 + ip2_1] = t114 * t39[2 * ip1_0 + ip2_1] + t115[4 * ip0 + 2 * ip1_0 + ip2_1] * t96[ip2_1] + t116[4 * ip0 + 2 * ip1_0 + ip2_1] * t103;
        t118 = (t101 * t99[ip2_1] + t104 * t98[ip2_1]) * t113;
        t119[4 * ip0 + 2 * ip1_0 + ip2_1] = (t42[2 * ip1_0 + ip2_1] * t104 + t40[2 * ip1_0 + ip2_1] * t102) * t113;
        t120[4 * ip0 + 2 * ip1_0 + ip2_1] = (t97[ip2_1] * t40[2 * ip1_0 + ip2_1] + -1.0 * t42[2 * ip1_0 + ip2_1] * t99[ip2_1]) * t113;
        t121[4 * ip0 + 2 * ip1_0 + ip2_1] = t118 * t39[2 * ip1_0 + ip2_1] + t119[4 * ip0 + 2 * ip1_0 + ip2_1] * t96[ip2_1] + t120[4 * ip0 + 2 * ip1_0 + ip2_1] * t103;
        t122 = (t97[ip2_1] * t106 + -1.0 * t101 * t100[ip2_1]) * t113;
        t123[4 * ip0 + 2 * ip1_0 + ip2_1] = (t101 * t41[2 * ip1_0 + ip2_1] + -1.0 * t42[2 * ip1_0 + ip2_1] * t106) * t113;
        t124[4 * ip0 + 2 * ip1_0 + ip2_1] = (t42[2 * ip1_0 + ip2_1] * t100[ip2_1] + -1.0 * t97[ip2_1] * t41[2 * ip1_0 + ip2_1]) * t113;
        t125[4 * ip0 + 2 * ip1_0 + ip2_1] = t122 * t39[2 * ip1_0 + ip2_1] + t123[4 * ip0 + 2 * ip1_0 + ip2_1] * t96[ip2_1] + t124[4 * ip0 + 2 * ip1_0 + ip2_1] * t103;
        t126[2 * ip1_0 + ip2_1] = t126[2 * ip1_0 + ip2_1] + t112[4 * ip0 + 2 * ip1_0 + ip2_1] * (t117[4 * ip0 + 2 * ip1_0 + ip2_1] * t114 + t121[4 * ip0 + 2 * ip1_0 + ip2_1] * t118 + t125[4 * ip0 + 2 * ip1_0 + ip2_1] * t122);
      }
    }
  }
  for (int32_t j1 = 0; j1 <= 1; ++j1)
    for (int32_t j2 = 0; j2 <= 1; ++j2)
      t128[2 * j1 + j2] = (double) (0.0);
  for (int32_t j0 = 0; j0 <= 1; ++j0)
  {
    for (int32_t j2_0 = 0; j2_0 <= 1; ++j2_0)
      t134[2 * j0 + j2_0] = (double) (0.0);
    for (int32_t j1_0 = 0; j1_0 <= 1; ++j1_0)
      t135[2 * j0 + j1_0] = (double) (0.0);
  }
  for (int32_t ip1_1 = 0; ip1_1 <= 1; ++ip1_1)
  {
    for (int32_t j2_1 = 0; j2_1 <= 1; ++j2_1)
      t127[j2_1] = (double) (0.0);
    for (int32_t ip2_2 = 0; ip2_2 <= 1; ++ip2_2)
      for (int32_t j2_2 = 0; j2_2 <= 1; ++j2_2)
        t127[j2_2] = t127[j2_2] + t43[ip2_2 + 2 * j2_2] * t126[2 * ip1_1 + ip2_2];
    for (int32_t j1_1 = 0; j1_1 <= 1; ++j1_1)
      for (int32_t j2_3 = 0; j2_3 <= 1; ++j2_3)
        t128[2 * j1_1 + j2_3] = t128[2 * j1_1 + j2_3] + t43[ip1_1 + 2 * j1_1] * t127[j2_3];
  }
  for (int32_t ip0_0 = 0; ip0_0 <= 1; ++ip0_0)
  {
    for (int32_t ip2_3 = 0; ip2_3 <= 1; ++ip2_3)
      t130[ip2_3] = (double) (0.0);
    for (int32_t ip1_2 = 0; ip1_2 <= 1; ++ip1_2)
      for (int32_t ip2_4 = 0; ip2_4 <= 1; ++ip2_4)
        t130[ip2_4] = t130[ip2_4] + t112[4 * ip0_0 + 2 * ip1_2 + ip2_4] * (t117[4 * ip0_0 + 2 * ip1_2 + ip2_4] * t115[4 * ip0_0 + 2 * ip1_2 + ip2_4] + t121[4 * ip0_0 + 2 * ip1_2 + ip2_4] * t119[4 * ip0_0 + 2 * ip1_2 + ip2_4] + t125[4 * ip0_0 + 2 * ip1_2 + ip2_4] * t123[4 * ip0_0 + 2 * ip1_2 + ip2_4]);
    for (int32_t j2_4 = 0; j2_4 <= 1; ++j2_4)
      t131[j2_4] = (double) (0.0);
    for (int32_t j1_2 = 0; j1_2 <= 1; ++j1_2)
      t133[j1_2] = (double) (0.0);
    for (int32_t ip2_5 = 0; ip2_5 <= 1; ++ip2_5)
      for (int32_t j2_5 = 0; j2_5 <= 1; ++j2_5)
        t131[j2_5] = t131[j2_5] + t43[ip2_5 + 2 * j2_5] * t130[ip2_5];
    for (int32_t ip1_3 = 0; ip1_3 <= 1; ++ip1_3)
    {
      t132 = (double) (0.0);
      for (int32_t ip2_6 = 0; ip2_6 <= 1; ++ip2_6)
        t132 = t132 + t112[4 * ip0_0 + 2 * ip1_3 + ip2_6] * (t117[4 * ip0_0 + 2 * ip1_3 + ip2_6] * t116[4 * ip0_0 + 2 * ip1_3 + ip2_6] + t121[4 * ip0_0 + 2 * ip1_3 + ip2_6] * t120[4 * ip0_0 + 2 * ip1_3 + ip2_6] + t125[4 * ip0_0 + 2 * ip1_3 + ip2_6] * t124[4 * ip0_0 + 2 * ip1_3 + ip2_6]);
      for (int32_t j1_3 = 0; j1_3 <= 1; ++j1_3)
        t133[j1_3] = t133[j1_3] + t43[ip1_3 + 2 * j1_3] * t132;
    }
    for (int32_t j0_0 = 0; j0_0 <= 1; ++j0_0)
    {
      for (int32_t j2_6 = 0; j2_6 <= 1; ++j2_6)
        t134[2 * j0_0 + j2_6] = t134[2 * j0_0 + j2_6] + t43[ip0_0 + 2 * j0_0] * t131[j2_6];
      for (int32_t j1_4 = 0; j1_4 <= 1; ++j1_4)
        t135[2 * j0_0 + j1_4] = t135[2 * j0_0 + j1_4] + t43[ip0_0 + 2 * j0_0] * t133[j1_4];
    }
  }
  for (int32_t j0_1 = 0; j0_1 <= 1; ++j0_1)
    for (int32_t j1_5 = 0; j1_5 <= 1; ++j1_5)
      for (int32_t j2_7 = 0; j2_7 <= 1; ++j2_7)
        A[4 * j0_1 + 2 * j1_5 + j2_7] = A[4 * j0_1 + 2 * j1_5 + j2_7] + t129[j0_1] * t128[2 * j1_5 + j2_7] + t129[j1_5] * t134[2 * j0_1 + j2_7] + t129[j2_7] * t135[2 * j0_1 + j1_5];

}