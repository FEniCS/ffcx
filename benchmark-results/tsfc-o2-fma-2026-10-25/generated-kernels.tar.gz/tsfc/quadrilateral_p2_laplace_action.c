#include <stdint.h>
#include <stdbool.h>
#include <math.h>

void k_cell_integral(double *__restrict__ A, double const *__restrict__ coords_0, double const *__restrict__ w_0)
{
  double t0;
  double t1;
  double t10;
  double t11[3] = { 0.6872983346207417, 0.0, -0.0872983346207417 };
  double t12[3] = { 0.4, 1.0, 0.4 };
  double t13[3] = { -0.0872983346207417, 0.0, 0.6872983346207417 };
  double t14;
  double t15[3] = { 0.1127016653792583, 0.5, 0.8872983346207416 };
  double t16;
  double t17[3] = { 0.8872983346207416, 0.5, 0.1127016653792583 };
  double t18[3] = { -2.549193338482967, -1.0, 0.5491933384829668 };
  double t19[3] = { 3.0983866769659336, 0.0, -3.0983866769659336 };
  double t2;
  double t20[3] = { -0.5491933384829669, 1.0, 2.549193338482967 };
  double t21[3];
  double t22[3];
  double t23[3];
  double t24;
  double t25;
  double t26;
  double t27;
  double t28;
  double t29;
  double t3;
  double t30;
  double t31;
  double t32;
  double t33;
  double t34;
  double t35;
  double t36;
  double t37;
  double t38;
  double t39;
  double t4;
  double t40;
  double t41;
  double t42;
  double t43;
  double t44;
  double t45;
  double t46[3];
  double t47[3];
  double t5;
  double t6[3 * 3] = { 0.6872983346207417, 0.0, -0.0872983346207417, 0.4, 1.0, 0.4, -0.0872983346207417, 0.0, 0.6872983346207417 };
  double t7[3 * 3] = { -2.549193338482967, -1.0, 0.5491933384829668, 3.0983866769659336, 0.0, -3.0983866769659336, -0.5491933384829669, 1.0, 2.549193338482967 };
  double t8[3] = { 0.2777777777777779, 0.4444444444444444, 0.2777777777777779 };
  double t9;

  t0 = -1.0 * coords_0[5] + coords_0[7];
  t1 = -1.0 * coords_0[1];
  t2 = t1 + coords_0[3];
  t3 = -1.0 * coords_0[4] + coords_0[6];
  t4 = -1.0 * coords_0[0];
  t5 = t4 + coords_0[2];
  t9 = -1.0 * coords_0[2] + coords_0[6];
  t10 = t4 + coords_0[4];
  t14 = -1.0 * coords_0[3] + coords_0[7];
  t16 = t1 + coords_0[5];
  for (int32_t ip1 = 0; ip1 <= 2; ++ip1)
  {
    t21[ip1] = t17[ip1] * t16 + t15[ip1] * t14;
    t22[ip1] = -1.0 * t21[ip1];
    t23[ip1] = t17[ip1] * t10 + t15[ip1] * t9;
  }
  for (int32_t ip0 = 0; ip0 <= 2; ++ip0)
  {
    t24 = t17[ip0] * t5 + t15[ip0] * t3;
    t25 = -1.0 * t24;
    t26 = t11[ip0] * w_0[2] + t12[ip0] * w_0[5] + t13[ip0] * w_0[8];
    t27 = t11[ip0] * w_0[1] + t12[ip0] * w_0[4] + t13[ip0] * w_0[7];
    t28 = t11[ip0] * w_0[0] + t12[ip0] * w_0[3] + t13[ip0] * w_0[6];
    t29 = t18[ip0] * w_0[2] + t19[ip0] * w_0[5] + t20[ip0] * w_0[8];
    t30 = t18[ip0] * w_0[1] + t19[ip0] * w_0[4] + t20[ip0] * w_0[7];
    t31 = t18[ip0] * w_0[0] + t19[ip0] * w_0[3] + t20[ip0] * w_0[6];
    t32 = t17[ip0] * t2 + t15[ip0] * t0;
    for (int32_t j1 = 0; j1 <= 2; ++j1)
    {
      t47[j1] = (double) (0.0);
      t46[j1] = (double) (0.0);
    }
    for (int32_t ip1_0 = 0; ip1_0 <= 2; ++ip1_0)
    {
      t33 = t23[ip1_0] * t32 + -1.0 * t24 * t21[ip1_0];
      t34 = t8[ip0] * t8[ip1_0] * fabs(t33);
      t35 = 1.0 / t33;
      t36 = t32 * t35;
      t37 = t11[ip1_0] * t31 + t12[ip1_0] * t30 + t13[ip1_0] * t29;
      t38 = t22[ip1_0] * t35;
      t39 = t18[ip1_0] * t28 + t19[ip1_0] * t27 + t20[ip1_0] * t26;
      t40 = t36 * t37 + t38 * t39;
      t41 = t25 * t35;
      t42 = t23[ip1_0] * t35;
      t43 = t41 * t37 + t42 * t39;
      t44 = t34 * (t40 * t38 + t43 * t42);
      t45 = t34 * (t40 * t36 + t43 * t41);
      for (int32_t j1_0 = 0; j1_0 <= 2; ++j1_0)
      {
        t46[j1_0] = t46[j1_0] + t6[ip1_0 + 3 * j1_0] * t45;
        t47[j1_0] = t47[j1_0] + t7[ip1_0 + 3 * j1_0] * t44;
      }
    }
    for (int32_t j0 = 0; j0 <= 2; ++j0)
      for (int32_t j1_1 = 0; j1_1 <= 2; ++j1_1)
        A[3 * j0 + j1_1] = A[3 * j0 + j1_1] + t7[ip0 + 3 * j0] * t46[j1_1] + t6[ip0 + 3 * j0] * t47[j1_1];
  }

}