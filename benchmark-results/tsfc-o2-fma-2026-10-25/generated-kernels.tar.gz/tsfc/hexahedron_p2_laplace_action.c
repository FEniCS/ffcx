#include <stdint.h>
#include <stdbool.h>
#include <math.h>

void k_cell_integral(double *__restrict__ A, double const *__restrict__ coords_0, double const *__restrict__ w_0)
{
  double t0;
  double t1;
  double t10;
  double t100[3];
  double t101[3];
  double t102;
  double t103;
  double t104;
  double t105;
  double t106;
  double t107;
  double t108;
  double t109;
  double t11;
  double t110;
  double t111;
  double t112;
  double t113;
  double t114;
  double t115;
  double t116;
  double t117;
  double t118;
  double t119;
  double t12;
  double t120;
  double t121;
  double t122;
  double t123;
  double t124;
  double t125;
  double t126;
  double t127;
  double t128;
  double t129;
  double t13;
  double t130;
  double t131;
  double t132;
  double t133;
  double t134;
  double t135;
  double t136;
  double t137;
  double t138;
  double t139;
  double t14;
  double t140;
  double t141[3];
  double t142[3];
  double t143[3];
  double t144[3 * 3];
  double t145[3 * 3];
  double t15;
  double t16;
  double t17;
  double t18;
  double t19;
  double t2;
  double t20;
  double t21;
  double t22;
  double t23;
  double t24;
  double t25;
  double t26;
  double t27;
  double t28;
  double t29;
  double t3;
  double t30;
  double t31;
  double t32;
  double t33;
  double t34;
  double t35;
  double t36;
  double t37;
  double t38;
  double t39;
  double t4;
  double t40;
  double t41;
  double t42;
  double t43;
  double t44;
  double t45;
  double t46;
  double t47;
  double t48[3 * 3] = { 0.6872983346207417, 0.0, -0.0872983346207417, 0.4, 1.0, 0.4, -0.0872983346207417, 0.0, 0.6872983346207417 };
  double t49[3 * 3] = { -2.549193338482967, -1.0, 0.5491933384829668, 3.0983866769659336, 0.0, -3.0983866769659336, -0.5491933384829669, 1.0, 2.549193338482967 };
  double t5;
  double t50[3] = { 0.8872983346207416, 0.5, 0.1127016653792583 };
  double t51[3] = { 0.1127016653792583, 0.5, 0.8872983346207416 };
  double t52[3] = { 0.2777777777777779, 0.4444444444444444, 0.2777777777777779 };
  double t53[3] = { 0.6872983346207417, 0.0, -0.0872983346207417 };
  double t54[3] = { 0.4, 1.0, 0.4 };
  double t55[3] = { -0.0872983346207417, 0.0, 0.6872983346207417 };
  double t56[3] = { -2.549193338482967, -1.0, 0.5491933384829668 };
  double t57[3] = { 3.0983866769659336, 0.0, -3.0983866769659336 };
  double t58[3] = { -0.5491933384829669, 1.0, 2.549193338482967 };
  double t59;
  double t6;
  double t60;
  double t61;
  double t62;
  double t63;
  double t64;
  double t65[3 * 3];
  double t66[3 * 3];
  double t67[3 * 3];
  double t68;
  double t69;
  double t7;
  double t70;
  double t71;
  double t72;
  double t73;
  double t74;
  double t75;
  double t76;
  double t77;
  double t78;
  double t79;
  double t8;
  double t80;
  double t81;
  double t82;
  double t83;
  double t84;
  double t85;
  double t86;
  double t87;
  double t88;
  double t89;
  double t9;
  double t90;
  double t91;
  double t92;
  double t93;
  double t94;
  double t95;
  double t96;
  double t97;
  double t98[3];
  double t99[3];

  t0 = -1.0 * coords_0[12];
  t1 = t0 + coords_0[18];
  t2 = -1.0 * coords_0[0];
  t3 = t2 + coords_0[6];
  t4 = -1.0 * coords_0[15] + coords_0[21];
  t5 = -1.0 * coords_0[3];
  t6 = t5 + coords_0[9];
  t7 = -1.0 * coords_0[14];
  t8 = t7 + coords_0[20];
  t9 = -1.0 * coords_0[2];
  t10 = t9 + coords_0[8];
  t11 = -1.0 * coords_0[17] + coords_0[23];
  t12 = -1.0 * coords_0[5];
  t13 = t12 + coords_0[11];
  t14 = -1.0 * coords_0[13];
  t15 = t14 + coords_0[19];
  t16 = -1.0 * coords_0[1];
  t17 = t16 + coords_0[7];
  t18 = -1.0 * coords_0[16] + coords_0[22];
  t19 = -1.0 * coords_0[4];
  t20 = t19 + coords_0[10];
  t21 = t0 + coords_0[15];
  t22 = t2 + coords_0[3];
  t23 = -1.0 * coords_0[18] + coords_0[21];
  t24 = -1.0 * coords_0[6];
  t25 = t24 + coords_0[9];
  t26 = t7 + coords_0[17];
  t27 = t9 + coords_0[5];
  t28 = -1.0 * coords_0[20] + coords_0[23];
  t29 = -1.0 * coords_0[8];
  t30 = t29 + coords_0[11];
  t31 = t14 + coords_0[16];
  t32 = t16 + coords_0[4];
  t33 = -1.0 * coords_0[19] + coords_0[22];
  t34 = -1.0 * coords_0[7];
  t35 = t34 + coords_0[10];
  t36 = t29 + coords_0[20];
  t37 = t9 + coords_0[14];
  t38 = -1.0 * coords_0[11] + coords_0[23];
  t39 = t12 + coords_0[17];
  t40 = t34 + coords_0[19];
  t41 = t16 + coords_0[13];
  t42 = -1.0 * coords_0[10] + coords_0[22];
  t43 = t19 + coords_0[16];
  t44 = t24 + coords_0[18];
  t45 = t2 + coords_0[12];
  t46 = -1.0 * coords_0[9] + coords_0[21];
  t47 = t5 + coords_0[15];
  for (int32_t ip1 = 0; ip1 <= 2; ++ip1)
  {
    t59 = t50[ip1] * t47 + t51[ip1] * t46;
    t60 = t50[ip1] * t45 + t51[ip1] * t44;
    t61 = t50[ip1] * t43 + t51[ip1] * t42;
    t62 = t50[ip1] * t41 + t51[ip1] * t40;
    t63 = t50[ip1] * t39 + t51[ip1] * t38;
    t64 = t50[ip1] * t37 + t51[ip1] * t36;
    for (int32_t ip2 = 0; ip2 <= 2; ++ip2)
    {
      t65[3 * ip1 + ip2] = t50[ip2] * t64 + t51[ip2] * t63;
      t66[3 * ip1 + ip2] = t50[ip2] * t62 + t51[ip2] * t61;
      t67[3 * ip1 + ip2] = t50[ip2] * t60 + t51[ip2] * t59;
    }
  }
  for (int32_t ip0 = 0; ip0 <= 2; ++ip0)
  {
    t68 = t50[ip0] * t35 + t51[ip0] * t33;
    t69 = t50[ip0] * t32 + t51[ip0] * t31;
    t70 = t56[ip0] * w_0[6] + t57[ip0] * w_0[15] + t58[ip0] * w_0[24];
    t71 = t56[ip0] * w_0[3] + t57[ip0] * w_0[12] + t58[ip0] * w_0[21];
    t72 = t56[ip0] * w_0[0] + t57[ip0] * w_0[9] + t58[ip0] * w_0[18];
    t73 = t56[ip0] * w_0[7] + t57[ip0] * w_0[16] + t58[ip0] * w_0[25];
    t74 = t56[ip0] * w_0[4] + t57[ip0] * w_0[13] + t58[ip0] * w_0[22];
    t75 = t56[ip0] * w_0[1] + t57[ip0] * w_0[10] + t58[ip0] * w_0[19];
    t76 = t56[ip0] * w_0[8] + t57[ip0] * w_0[17] + t58[ip0] * w_0[26];
    t77 = t56[ip0] * w_0[5] + t57[ip0] * w_0[14] + t58[ip0] * w_0[23];
    t78 = t56[ip0] * w_0[2] + t57[ip0] * w_0[11] + t58[ip0] * w_0[20];
    t79 = t50[ip0] * t30 + t51[ip0] * t28;
    t80 = t50[ip0] * t27 + t51[ip0] * t26;
    t81 = t53[ip0] * w_0[6] + t54[ip0] * w_0[15] + t55[ip0] * w_0[24];
    t82 = t53[ip0] * w_0[3] + t54[ip0] * w_0[12] + t55[ip0] * w_0[21];
    t83 = t53[ip0] * w_0[0] + t54[ip0] * w_0[9] + t55[ip0] * w_0[18];
    t84 = t53[ip0] * w_0[7] + t54[ip0] * w_0[16] + t55[ip0] * w_0[25];
    t85 = t53[ip0] * w_0[4] + t54[ip0] * w_0[13] + t55[ip0] * w_0[22];
    t86 = t53[ip0] * w_0[1] + t54[ip0] * w_0[10] + t55[ip0] * w_0[19];
    t87 = t53[ip0] * w_0[8] + t54[ip0] * w_0[17] + t55[ip0] * w_0[26];
    t88 = t53[ip0] * w_0[5] + t54[ip0] * w_0[14] + t55[ip0] * w_0[23];
    t89 = t53[ip0] * w_0[2] + t54[ip0] * w_0[11] + t55[ip0] * w_0[20];
    t90 = t50[ip0] * t25 + t51[ip0] * t23;
    t91 = t50[ip0] * t22 + t51[ip0] * t21;
    t92 = t50[ip0] * t20 + t51[ip0] * t18;
    t93 = t50[ip0] * t17 + t51[ip0] * t15;
    t94 = t50[ip0] * t13 + t51[ip0] * t11;
    t95 = t50[ip0] * t10 + t51[ip0] * t8;
    t96 = t50[ip0] * t6 + t51[ip0] * t4;
    t97 = t50[ip0] * t3 + t51[ip0] * t1;
    for (int32_t ip2_0 = 0; ip2_0 <= 2; ++ip2_0)
    {
      t98[ip2_0] = t50[ip2_0] * t97 + t51[ip2_0] * t96;
      t99[ip2_0] = -1.0 * t98[ip2_0];
      t100[ip2_0] = t50[ip2_0] * t95 + t51[ip2_0] * t94;
      t101[ip2_0] = t50[ip2_0] * t93 + t51[ip2_0] * t92;
    }
    for (int32_t j1 = 0; j1 <= 2; ++j1)
      for (int32_t j2 = 0; j2 <= 2; ++j2)
      {
        t145[3 * j1 + j2] = (double) (0.0);
        t144[3 * j1 + j2] = (double) (0.0);
      }
    for (int32_t ip1_0 = 0; ip1_0 <= 2; ++ip1_0)
    {
      t102 = t50[ip1_0] * t91 + t51[ip1_0] * t90;
      t103 = -1.0 * t102;
      t104 = t53[ip1_0] * t89 + t54[ip1_0] * t88 + t55[ip1_0] * t87;
      t105 = t53[ip1_0] * t86 + t54[ip1_0] * t85 + t55[ip1_0] * t84;
      t106 = t53[ip1_0] * t83 + t54[ip1_0] * t82 + t55[ip1_0] * t81;
      t107 = t56[ip1_0] * t89 + t57[ip1_0] * t88 + t58[ip1_0] * t87;
      t108 = t56[ip1_0] * t86 + t57[ip1_0] * t85 + t58[ip1_0] * t84;
      t109 = t56[ip1_0] * t83 + t57[ip1_0] * t82 + t58[ip1_0] * t81;
      t110 = t50[ip1_0] * t80 + t51[ip1_0] * t79;
      t111 = -1.0 * t110;
      t112 = t53[ip1_0] * t78 + t54[ip1_0] * t77 + t55[ip1_0] * t76;
      t113 = t53[ip1_0] * t75 + t54[ip1_0] * t74 + t55[ip1_0] * t73;
      t114 = t53[ip1_0] * t72 + t54[ip1_0] * t71 + t55[ip1_0] * t70;
      t115 = t50[ip1_0] * t69 + t51[ip1_0] * t68;
      t116 = t52[ip0] * t52[ip1_0];
      for (int32_t j2_0 = 0; j2_0 <= 2; ++j2_0)
      {
        t143[j2_0] = (double) (0.0);
        t142[j2_0] = (double) (0.0);
        t141[j2_0] = (double) (0.0);
      }
      for (int32_t ip2_1 = 0; ip2_1 <= 2; ++ip2_1)
      {
        t117 = t101[ip2_1] * t110 + -1.0 * t115 * t100[ip2_1];
        t118 = t115 * t65[3 * ip1_0 + ip2_1];
        t119 = t66[3 * ip1_0 + ip2_1] * t100[ip2_1] + -1.0 * t101[ip2_1] * t65[3 * ip1_0 + ip2_1];
        t120 = t67[3 * ip1_0 + ip2_1] * t117 + (t66[3 * ip1_0 + ip2_1] * t110 + -1.0 * t118) * t99[ip2_1] + t102 * t119;
        t121 = t116 * t52[ip2_1] * fabs(t120);
        t122 = 1.0 / t120;
        t123 = t117 * t122;
        t124 = t53[ip2_1] * t114 + t54[ip2_1] * t113 + t55[ip2_1] * t112;
        t125 = (t118 + t66[3 * ip1_0 + ip2_1] * t111) * t122;
        t126 = t53[ip2_1] * t109 + t54[ip2_1] * t108 + t55[ip2_1] * t107;
        t127 = t119 * t122;
        t128 = t56[ip2_1] * t106 + t57[ip2_1] * t105 + t58[ip2_1] * t104;
        t129 = t123 * t124 + t125 * t126 + t127 * t128;
        t130 = (t102 * t100[ip2_1] + t110 * t99[ip2_1]) * t122;
        t131 = (t67[3 * ip1_0 + ip2_1] * t110 + t65[3 * ip1_0 + ip2_1] * t103) * t122;
        t132 = (t98[ip2_1] * t65[3 * ip1_0 + ip2_1] + -1.0 * t67[3 * ip1_0 + ip2_1] * t100[ip2_1]) * t122;
        t133 = t130 * t124 + t131 * t126 + t132 * t128;
        t134 = (t98[ip2_1] * t115 + -1.0 * t102 * t101[ip2_1]) * t122;
        t135 = (t102 * t66[3 * ip1_0 + ip2_1] + -1.0 * t67[3 * ip1_0 + ip2_1] * t115) * t122;
        t136 = (t67[3 * ip1_0 + ip2_1] * t101[ip2_1] + -1.0 * t98[ip2_1] * t66[3 * ip1_0 + ip2_1]) * t122;
        t137 = t134 * t124 + t135 * t126 + t136 * t128;
        t138 = t121 * (t129 * t127 + t133 * t132 + t137 * t136);
        t139 = t121 * (t129 * t125 + t133 * t131 + t137 * t135);
        t140 = t121 * (t129 * t123 + t133 * t130 + t137 * t134);
        for (int32_t j2_1 = 0; j2_1 <= 2; ++j2_1)
        {
          t141[j2_1] = t141[j2_1] + t48[ip2_1 + 3 * j2_1] * t140;
          t142[j2_1] = t142[j2_1] + t48[ip2_1 + 3 * j2_1] * t139;
          t143[j2_1] = t143[j2_1] + t49[ip2_1 + 3 * j2_1] * t138;
        }
      }
      for (int32_t j1_0 = 0; j1_0 <= 2; ++j1_0)
        for (int32_t j2_2 = 0; j2_2 <= 2; ++j2_2)
        {
          t144[3 * j1_0 + j2_2] = t144[3 * j1_0 + j2_2] + t48[ip1_0 + 3 * j1_0] * t141[j2_2];
          t145[3 * j1_0 + j2_2] = t145[3 * j1_0 + j2_2] + t49[ip1_0 + 3 * j1_0] * t142[j2_2] + t48[ip1_0 + 3 * j1_0] * t143[j2_2];
        }
    }
    for (int32_t j0 = 0; j0 <= 2; ++j0)
      for (int32_t j1_1 = 0; j1_1 <= 2; ++j1_1)
        for (int32_t j2_3 = 0; j2_3 <= 2; ++j2_3)
          A[9 * j0 + 3 * j1_1 + j2_3] = A[9 * j0 + 3 * j1_1 + j2_3] + t49[ip0 + 3 * j0] * t144[3 * j1_1 + j2_3] + t48[ip0 + 3 * j0] * t145[3 * j1_1 + j2_3];
  }

}