#include <stdint.h>
#include <stdbool.h>
#include <math.h>

void k_cell_integral(double *__restrict__ A, double const *__restrict__ coords_0, double const *__restrict__ w_0)
{
  double t0;
  double t1;
  double t10;
  double t100;
  double t101;
  double t102;
  double t103;
  double t104;
  double t105;
  double t106;
  double t107;
  double t108;
  double t109;
  double t11;
  double t110;
  double t111;
  double t112;
  double t113[5];
  double t114[5];
  double t115[5];
  double t116[5 * 5];
  double t117[5 * 5];
  double t12;
  double t13;
  double t14;
  double t15;
  double t16;
  double t17;
  double t18;
  double t19;
  double t2;
  double t20;
  double t21;
  double t22;
  double t23;
  double t24;
  double t25;
  double t26;
  double t27;
  double t28;
  double t29;
  double t3;
  double t30;
  double t31;
  double t32;
  double t33;
  double t34;
  double t35;
  double t36;
  double t37;
  double t38;
  double t39;
  double t4;
  double t40;
  double t41;
  double t42;
  double t43;
  double t44;
  double t45;
  double t46;
  double t47;
  double t48[5] = { 0.953089922969332, 0.7692346550528416, 0.5, 0.23076534494715836, 0.046910077030668074 };
  double t49[5] = { 0.046910077030668074, 0.23076534494715836, 0.5, 0.7692346550528416, 0.953089922969332 };
  double t5;
  double t50[5] = { 0.11846344252809438, 0.23931433524968326, 0.28444444444444456, 0.23931433524968326, 0.11846344252809438 };
  double t51[5 * 5] = { -7.410672907182903, -1.057430535960548, 0.7499999999999992, -0.48703604225920055, 0.2884728187359869, 8.665642337527858, -2.195315935656656, -2.6731691553909074, 1.499477140026576, -0.841352460855359, -1.8078490724643246, 4.265187569384579, 0.0, -4.26518756938458, 1.8078490724643266, 0.8413524608553576, -1.4994771400265745, 2.6731691553909065, 2.1953159356566556, -8.665642337527853, -0.2884728187359864, 0.48703604225919994, -0.749999999999999, 1.0574305359605494, 7.4106729071828985 };
  double t52[5 * 5] = { 0.593370696019946, -0.10048256880508269, 0.0, 0.03014411077187963, -0.029205077492916134, 0.5164351986496183, 0.9313661019373952, 0.0, -0.09069490469997664, 0.08322282221996015, -0.16382363939660827, 0.22966726079578437, 1.0, 0.22966726079578428, -0.16382363939660838, 0.08322282221996005, -0.09069490469997667, 0.0, 0.9313661019373954, 0.5164351986496182, -0.029205077492916103, 0.03014411077187963, 0.0, -0.10048256880508262, 0.5933706960199461 };
  double t53;
  double t54;
  double t55;
  double t56;
  double t57;
  double t58;
  double t59[5 * 5];
  double t6;
  double t60[5 * 5];
  double t61[5 * 5];
  double t62[5 * 5];
  double t63[5 * 5];
  double t64;
  double t65;
  double t66;
  double t67;
  double t68;
  double t69;
  double t7;
  double t70;
  double t71;
  double t72;
  double t73;
  double t74;
  double t75;
  double t76[5];
  double t77[5];
  double t78[5];
  double t79[5];
  double t8;
  double t80[5];
  double t81[5];
  double t82[5];
  double t83;
  double t84;
  double t85;
  double t86;
  double t87;
  double t88;
  double t89;
  double t9;
  double t90;
  double t91;
  double t92;
  double t93;
  double t94;
  double t95;
  double t96;
  double t97;
  double t98;
  double t99;

  t0 = -1.0 * coords_0[12];
  t1 = t0 + coords_0[18];
  t2 = -1.0 * coords_0[0];
  t3 = t2 + coords_0[6];
  t4 = -1.0 * coords_0[15] + coords_0[21];
  t5 = -1.0 * coords_0[3];
  t6 = t5 + coords_0[9];
  t7 = -1.0 * coords_0[14];
  t8 = t7 + coords_0[20];
  t9 = -1.0 * coords_0[2];
  t10 = t9 + coords_0[8];
  t11 = -1.0 * coords_0[17] + coords_0[23];
  t12 = -1.0 * coords_0[5];
  t13 = t12 + coords_0[11];
  t14 = -1.0 * coords_0[13];
  t15 = t14 + coords_0[19];
  t16 = -1.0 * coords_0[1];
  t17 = t16 + coords_0[7];
  t18 = -1.0 * coords_0[16] + coords_0[22];
  t19 = -1.0 * coords_0[4];
  t20 = t19 + coords_0[10];
  t21 = t0 + coords_0[15];
  t22 = t2 + coords_0[3];
  t23 = -1.0 * coords_0[18] + coords_0[21];
  t24 = -1.0 * coords_0[6];
  t25 = t24 + coords_0[9];
  t26 = t7 + coords_0[17];
  t27 = t9 + coords_0[5];
  t28 = -1.0 * coords_0[20] + coords_0[23];
  t29 = -1.0 * coords_0[8];
  t30 = t29 + coords_0[11];
  t31 = t14 + coords_0[16];
  t32 = t16 + coords_0[4];
  t33 = -1.0 * coords_0[19] + coords_0[22];
  t34 = -1.0 * coords_0[7];
  t35 = t34 + coords_0[10];
  t36 = t29 + coords_0[20];
  t37 = t9 + coords_0[14];
  t38 = -1.0 * coords_0[11] + coords_0[23];
  t39 = t12 + coords_0[17];
  t40 = t34 + coords_0[19];
  t41 = t16 + coords_0[13];
  t42 = -1.0 * coords_0[10] + coords_0[22];
  t43 = t19 + coords_0[16];
  t44 = t24 + coords_0[18];
  t45 = t2 + coords_0[12];
  t46 = -1.0 * coords_0[9] + coords_0[21];
  t47 = t5 + coords_0[15];
  for (int32_t ip1 = 0; ip1 <= 4; ++ip1)
  {
    t53 = t48[ip1] * t47 + t49[ip1] * t46;
    t54 = t48[ip1] * t45 + t49[ip1] * t44;
    t55 = t48[ip1] * t43 + t49[ip1] * t42;
    t56 = t48[ip1] * t41 + t49[ip1] * t40;
    t57 = t48[ip1] * t39 + t49[ip1] * t38;
    t58 = t48[ip1] * t37 + t49[ip1] * t36;
    for (int32_t ip2 = 0; ip2 <= 4; ++ip2)
    {
      t59[5 * ip1 + ip2] = t48[ip2] * t58 + t49[ip2] * t57;
      t60[5 * ip1 + ip2] = t48[ip2] * t56 + t49[ip2] * t55;
      t61[5 * ip1 + ip2] = t48[ip2] * t54 + t49[ip2] * t53;
    }
  }
  for (int32_t ip0 = 0; ip0 <= 4; ++ip0)
  {
    for (int32_t i = 0; i <= 4; ++i)
      for (int32_t i_0 = 0; i_0 <= 4; ++i_0)
      {
        t63[5 * i + i_0] = (double) (0.0);
        t62[5 * i + i_0] = (double) (0.0);
        for (int32_t i_1 = 0; i_1 <= 4; ++i_1)
        {
          t62[5 * i + i_0] = t62[5 * i + i_0] + t52[ip0 + 5 * i_1] * w_0[i + 5 * i_0 + 25 * i_1];
          t63[5 * i + i_0] = t63[5 * i + i_0] + t51[ip0 + 5 * i_1] * w_0[i + 5 * i_0 + 25 * i_1];
        }
      }
    t64 = t48[ip0] * t35 + t49[ip0] * t33;
    t65 = t48[ip0] * t32 + t49[ip0] * t31;
    t66 = t48[ip0] * t30 + t49[ip0] * t28;
    t67 = t48[ip0] * t27 + t49[ip0] * t26;
    t68 = t48[ip0] * t25 + t49[ip0] * t23;
    t69 = t48[ip0] * t22 + t49[ip0] * t21;
    t70 = t48[ip0] * t20 + t49[ip0] * t18;
    t71 = t48[ip0] * t17 + t49[ip0] * t15;
    t72 = t48[ip0] * t13 + t49[ip0] * t11;
    t73 = t48[ip0] * t10 + t49[ip0] * t8;
    t74 = t48[ip0] * t6 + t49[ip0] * t4;
    t75 = t48[ip0] * t3 + t49[ip0] * t1;
    for (int32_t ip2_0 = 0; ip2_0 <= 4; ++ip2_0)
    {
      t76[ip2_0] = t48[ip2_0] * t75 + t49[ip2_0] * t74;
      t77[ip2_0] = -1.0 * t76[ip2_0];
      t78[ip2_0] = t48[ip2_0] * t73 + t49[ip2_0] * t72;
      t79[ip2_0] = t48[ip2_0] * t71 + t49[ip2_0] * t70;
    }
    for (int32_t j1 = 0; j1 <= 4; ++j1)
      for (int32_t j2 = 0; j2 <= 4; ++j2)
      {
        t117[5 * j1 + j2] = (double) (0.0);
        t116[5 * j1 + j2] = (double) (0.0);
      }
    for (int32_t ip1_0 = 0; ip1_0 <= 4; ++ip1_0)
    {
      for (int32_t i_2 = 0; i_2 <= 4; ++i_2)
      {
        t82[i_2] = (double) (0.0);
        t81[i_2] = (double) (0.0);
        t80[i_2] = (double) (0.0);
        for (int32_t i_3 = 0; i_3 <= 4; ++i_3)
        {
          t80[i_2] = t80[i_2] + t52[ip1_0 + 5 * i_3] * t62[5 * i_2 + i_3];
          t81[i_2] = t81[i_2] + t51[ip1_0 + 5 * i_3] * t62[5 * i_2 + i_3];
          t82[i_2] = t82[i_2] + t52[ip1_0 + 5 * i_3] * t63[5 * i_2 + i_3];
        }
      }
      t83 = t48[ip1_0] * t69 + t49[ip1_0] * t68;
      t84 = -1.0 * t83;
      t85 = t48[ip1_0] * t67 + t49[ip1_0] * t66;
      t86 = -1.0 * t85;
      t87 = t48[ip1_0] * t65 + t49[ip1_0] * t64;
      t88 = t50[ip0] * t50[ip1_0];
      for (int32_t j2_0 = 0; j2_0 <= 4; ++j2_0)
      {
        t115[j2_0] = (double) (0.0);
        t114[j2_0] = (double) (0.0);
        t113[j2_0] = (double) (0.0);
      }
      for (int32_t ip2_1 = 0; ip2_1 <= 4; ++ip2_1)
      {
        t91 = (double) (0.0);
        t90 = (double) (0.0);
        t89 = (double) (0.0);
        for (int32_t i_4 = 0; i_4 <= 4; ++i_4)
        {
          t89 = t89 + t51[ip2_1 + 5 * i_4] * t80[i_4];
          t90 = t90 + t52[ip2_1 + 5 * i_4] * t81[i_4];
          t91 = t91 + t52[ip2_1 + 5 * i_4] * t82[i_4];
        }
        t92 = t79[ip2_1] * t85 + -1.0 * t87 * t78[ip2_1];
        t93 = t87 * t59[5 * ip1_0 + ip2_1];
        t94 = t60[5 * ip1_0 + ip2_1] * t78[ip2_1] + -1.0 * t79[ip2_1] * t59[5 * ip1_0 + ip2_1];
        t95 = t61[5 * ip1_0 + ip2_1] * t92 + (t60[5 * ip1_0 + ip2_1] * t85 + -1.0 * t93) * t77[ip2_1] + t83 * t94;
        t96 = t88 * t50[ip2_1] * fabs(t95);
        t97 = 1.0 / t95;
        t98 = t92 * t97;
        t99 = (t93 + t60[5 * ip1_0 + ip2_1] * t86) * t97;
        t100 = t94 * t97;
        t101 = t98 * t91 + t99 * t90 + t100 * t89;
        t102 = (t83 * t78[ip2_1] + t85 * t77[ip2_1]) * t97;
        t103 = (t61[5 * ip1_0 + ip2_1] * t85 + t59[5 * ip1_0 + ip2_1] * t84) * t97;
        t104 = (t76[ip2_1] * t59[5 * ip1_0 + ip2_1] + -1.0 * t61[5 * ip1_0 + ip2_1] * t78[ip2_1]) * t97;
        t105 = t102 * t91 + t103 * t90 + t104 * t89;
        t106 = (t76[ip2_1] * t87 + -1.0 * t83 * t79[ip2_1]) * t97;
        t107 = (t83 * t60[5 * ip1_0 + ip2_1] + -1.0 * t61[5 * ip1_0 + ip2_1] * t87) * t97;
        t108 = (t61[5 * ip1_0 + ip2_1] * t79[ip2_1] + -1.0 * t76[ip2_1] * t60[5 * ip1_0 + ip2_1]) * t97;
        t109 = t106 * t91 + t107 * t90 + t108 * t89;
        t110 = t96 * (t101 * t100 + t105 * t104 + t109 * t108);
        t111 = t96 * (t101 * t99 + t105 * t103 + t109 * t107);
        t112 = t96 * (t101 * t98 + t105 * t102 + t109 * t106);
        for (int32_t j2_1 = 0; j2_1 <= 4; ++j2_1)
        {
          t113[j2_1] = t113[j2_1] + t52[ip2_1 + 5 * j2_1] * t112;
          t114[j2_1] = t114[j2_1] + t52[ip2_1 + 5 * j2_1] * t111;
          t115[j2_1] = t115[j2_1] + t51[ip2_1 + 5 * j2_1] * t110;
        }
      }
      for (int32_t j1_0 = 0; j1_0 <= 4; ++j1_0)
        for (int32_t j2_2 = 0; j2_2 <= 4; ++j2_2)
        {
          t116[5 * j1_0 + j2_2] = t116[5 * j1_0 + j2_2] + t52[ip1_0 + 5 * j1_0] * t113[j2_2];
          t117[5 * j1_0 + j2_2] = t117[5 * j1_0 + j2_2] + t51[ip1_0 + 5 * j1_0] * t114[j2_2] + t52[ip1_0 + 5 * j1_0] * t115[j2_2];
        }
    }
    for (int32_t j0 = 0; j0 <= 4; ++j0)
      for (int32_t j1_1 = 0; j1_1 <= 4; ++j1_1)
        for (int32_t j2_3 = 0; j2_3 <= 4; ++j2_3)
          A[25 * j0 + 5 * j1_1 + j2_3] = A[25 * j0 + 5 * j1_1 + j2_3] + t51[ip0 + 5 * j0] * t116[5 * j1_1 + j2_3] + t52[ip0 + 5 * j0] * t117[5 * j1_1 + j2_3];
  }

}