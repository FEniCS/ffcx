#include <stdint.h>
#include <stdbool.h>
#include <math.h>

void k_cell_integral(double *__restrict__ A, double const *__restrict__ coords_0, double const *__restrict__ w_0)
{
  double t0;
  double t1;
  double t10;
  double t11;
  double t12;
  double t13;
  double t14;
  double t15;
  double t16;
  double t17;
  double t18;
  double t19;
  double t2;
  double t20;
  double t21;
  double t22;
  double t23;
  double t24;
  double t25;
  double t26;
  double t27;
  double t28;
  double t29;
  double t3;
  double t30;
  double t31;
  double t32;
  double t33;
  double t34;
  double t35;
  double t36;
  double t37;
  double t38;
  double t39;
  double t4;
  double t40;
  double t41;
  double t42;
  double t43;
  double t44;
  double t45;
  double t46;
  double t47;
  double t48[6] = { 0.9662347571015758, 0.8306046932331322, 0.6193095930415984, 0.38069040695840156, 0.16939530676686776, 0.03376524289842408 };
  double t49[6] = { 0.03376524289842408, 0.16939530676686776, 0.38069040695840156, 0.6193095930415983, 0.8306046932331322, 0.9662347571015758 };
  double t5;
  double t50[6] = { 0.08566224618958523, 0.18038078652406908, 0.23395696728634566, 0.23395696728634566, 0.18038078652406908, 0.08566224618958523 };
  double t51[6 * 6] = { 0.5681003371911977, -0.1149129888893822, 0.020974134603267955, 0.01289282763811809, -0.023435601993343144, 0.019852365830306078, 0.5460052990461834, 0.8932544371211691, -0.07227772737120565, -0.03791030585116988, 0.06503760749312357, -0.053848422698494894, -0.1710005937792825, 0.2987272976255432, 0.9883752612168262, 0.08794580976416352, -0.11867075135711054, 0.09089101441009012, 0.0908910144100901, -0.11867075135711054, 0.08794580976416332, 0.988375261216826, 0.2987272976255432, -0.17100059377928253, -0.05384842269849489, 0.06503760749312357, -0.037910305851169786, -0.07227772737120579, 0.8932544371211691, 0.5460052990461836, 0.019852365830306074, -0.023435601993343144, 0.012892827638118063, 0.020974134603267993, -0.1149129888893822, 0.5681003371911978 };
  double t52;
  double t53;
  double t54;
  double t55;
  double t56;
  double t57;
  double t58[6 * 6];
  double t59[6 * 6];
  double t6;
  double t60[6 * 6];
  double t61[6 * 6];
  double t62;
  double t63;
  double t64;
  double t65;
  double t66;
  double t67;
  double t68;
  double t69;
  double t7;
  double t70;
  double t71;
  double t72;
  double t73;
  double t74[6];
  double t75[6];
  double t76[6];
  double t77[6];
  double t78;
  double t79;
  double t8;
  double t80;
  double t81;
  double t82;
  double t83;
  double t84[6];
  double t85[6 * 6];
  double t9;

  t0 = -1.0 * coords_0[12];
  t1 = t0 + coords_0[18];
  t2 = -1.0 * coords_0[0];
  t3 = t2 + coords_0[6];
  t4 = -1.0 * coords_0[15] + coords_0[21];
  t5 = -1.0 * coords_0[3];
  t6 = t5 + coords_0[9];
  t7 = -1.0 * coords_0[14];
  t8 = t7 + coords_0[20];
  t9 = -1.0 * coords_0[2];
  t10 = t9 + coords_0[8];
  t11 = -1.0 * coords_0[17] + coords_0[23];
  t12 = -1.0 * coords_0[5];
  t13 = t12 + coords_0[11];
  t14 = -1.0 * coords_0[13];
  t15 = t14 + coords_0[19];
  t16 = -1.0 * coords_0[1];
  t17 = t16 + coords_0[7];
  t18 = -1.0 * coords_0[16] + coords_0[22];
  t19 = -1.0 * coords_0[4];
  t20 = t19 + coords_0[10];
  t21 = t0 + coords_0[15];
  t22 = t2 + coords_0[3];
  t23 = -1.0 * coords_0[18] + coords_0[21];
  t24 = -1.0 * coords_0[6];
  t25 = t24 + coords_0[9];
  t26 = t14 + coords_0[16];
  t27 = t16 + coords_0[4];
  t28 = -1.0 * coords_0[19] + coords_0[22];
  t29 = -1.0 * coords_0[7];
  t30 = t29 + coords_0[10];
  t31 = t7 + coords_0[17];
  t32 = t9 + coords_0[5];
  t33 = -1.0 * coords_0[20] + coords_0[23];
  t34 = -1.0 * coords_0[8];
  t35 = t34 + coords_0[11];
  t36 = t34 + coords_0[20];
  t37 = t9 + coords_0[14];
  t38 = -1.0 * coords_0[11] + coords_0[23];
  t39 = t12 + coords_0[17];
  t40 = t29 + coords_0[19];
  t41 = t16 + coords_0[13];
  t42 = -1.0 * coords_0[10] + coords_0[22];
  t43 = t19 + coords_0[16];
  t44 = t24 + coords_0[18];
  t45 = t2 + coords_0[12];
  t46 = -1.0 * coords_0[9] + coords_0[21];
  t47 = t5 + coords_0[15];
  for (int32_t ip1 = 0; ip1 <= 5; ++ip1)
  {
    t52 = t48[ip1] * t47 + t49[ip1] * t46;
    t53 = t48[ip1] * t45 + t49[ip1] * t44;
    t54 = t48[ip1] * t43 + t49[ip1] * t42;
    t55 = t48[ip1] * t41 + t49[ip1] * t40;
    t56 = t48[ip1] * t39 + t49[ip1] * t38;
    t57 = t48[ip1] * t37 + t49[ip1] * t36;
    for (int32_t ip2 = 0; ip2 <= 5; ++ip2)
    {
      t58[6 * ip1 + ip2] = t48[ip2] * t57 + t49[ip2] * t56;
      t59[6 * ip1 + ip2] = t48[ip2] * t55 + t49[ip2] * t54;
      t60[6 * ip1 + ip2] = t48[ip2] * t53 + t49[ip2] * t52;
    }
  }
  for (int32_t ip0 = 0; ip0 <= 5; ++ip0)
  {
    for (int32_t i = 0; i <= 5; ++i)
      for (int32_t i_0 = 0; i_0 <= 5; ++i_0)
      {
        t61[6 * i + i_0] = (double) (0.0);
        for (int32_t i_1 = 0; i_1 <= 5; ++i_1)
          t61[6 * i + i_0] = t61[6 * i + i_0] + t51[ip0 + 6 * i_1] * w_0[i + 6 * i_0 + 36 * i_1];
      }
    t62 = t48[ip0] * t35 + t49[ip0] * t33;
    t63 = t48[ip0] * t32 + t49[ip0] * t31;
    t64 = t48[ip0] * t30 + t49[ip0] * t28;
    t65 = t48[ip0] * t27 + t49[ip0] * t26;
    t66 = t48[ip0] * t25 + t49[ip0] * t23;
    t67 = t48[ip0] * t22 + t49[ip0] * t21;
    t68 = t48[ip0] * t20 + t49[ip0] * t18;
    t69 = t48[ip0] * t17 + t49[ip0] * t15;
    t70 = t48[ip0] * t13 + t49[ip0] * t11;
    t71 = t48[ip0] * t10 + t49[ip0] * t8;
    t72 = t48[ip0] * t6 + t49[ip0] * t4;
    t73 = t48[ip0] * t3 + t49[ip0] * t1;
    for (int32_t ip2_0 = 0; ip2_0 <= 5; ++ip2_0)
    {
      t74[ip2_0] = -1.0 * (t48[ip2_0] * t73 + t49[ip2_0] * t72);
      t75[ip2_0] = t48[ip2_0] * t71 + t49[ip2_0] * t70;
      t76[ip2_0] = t48[ip2_0] * t69 + t49[ip2_0] * t68;
    }
    for (int32_t j1 = 0; j1 <= 5; ++j1)
      for (int32_t j2 = 0; j2 <= 5; ++j2)
        t85[6 * j1 + j2] = (double) (0.0);
    for (int32_t ip1_0 = 0; ip1_0 <= 5; ++ip1_0)
    {
      for (int32_t i_2 = 0; i_2 <= 5; ++i_2)
      {
        t77[i_2] = (double) (0.0);
        for (int32_t i_3 = 0; i_3 <= 5; ++i_3)
          t77[i_2] = t77[i_2] + t51[ip1_0 + 6 * i_3] * t61[6 * i_2 + i_3];
      }
      t78 = t48[ip1_0] * t67 + t49[ip1_0] * t66;
      t79 = t48[ip1_0] * t65 + t49[ip1_0] * t64;
      t80 = t48[ip1_0] * t63 + t49[ip1_0] * t62;
      t81 = t50[ip0] * t50[ip1_0];
      for (int32_t j2_0 = 0; j2_0 <= 5; ++j2_0)
        t84[j2_0] = (double) (0.0);
      for (int32_t ip2_1 = 0; ip2_1 <= 5; ++ip2_1)
      {
        t82 = (double) (0.0);
        for (int32_t i_4 = 0; i_4 <= 5; ++i_4)
          t82 = t82 + t51[ip2_1 + 6 * i_4] * t77[i_4];
        t83 = t81 * t50[ip2_1] * fabs(t60[6 * ip1_0 + ip2_1] * (t76[ip2_1] * t80 + -1.0 * t79 * t75[ip2_1]) + (t59[6 * ip1_0 + ip2_1] * t80 + -1.0 * t79 * t58[6 * ip1_0 + ip2_1]) * t74[ip2_1] + t78 * (t59[6 * ip1_0 + ip2_1] * t75[ip2_1] + -1.0 * t76[ip2_1] * t58[6 * ip1_0 + ip2_1])) * t82;
        for (int32_t j2_1 = 0; j2_1 <= 5; ++j2_1)
          t84[j2_1] = t84[j2_1] + t51[ip2_1 + 6 * j2_1] * t83;
      }
      for (int32_t j1_0 = 0; j1_0 <= 5; ++j1_0)
        for (int32_t j2_2 = 0; j2_2 <= 5; ++j2_2)
          t85[6 * j1_0 + j2_2] = t85[6 * j1_0 + j2_2] + t51[ip1_0 + 6 * j1_0] * t84[j2_2];
    }
    for (int32_t j0 = 0; j0 <= 5; ++j0)
      for (int32_t j1_1 = 0; j1_1 <= 5; ++j1_1)
        for (int32_t j2_3 = 0; j2_3 <= 5; ++j2_3)
          A[36 * j0 + 6 * j1_1 + j2_3] = A[36 * j0 + 6 * j1_1 + j2_3] + t51[ip0 + 6 * j0] * t85[6 * j1_1 + j2_3];
  }

}