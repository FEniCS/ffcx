#include <stdint.h>
#include <stdbool.h>
#include <math.h>

void k_cell_integral(double *__restrict__ A, double const *__restrict__ coords_0, double const *__restrict__ w_0)
{
  double t0;
  double t1;
  double t10;
  double t11;
  double t12;
  double t13;
  double t14;
  double t15;
  double t16;
  double t17;
  double t18;
  double t19;
  double t2;
  double t20;
  double t21;
  double t22;
  double t23;
  double t24;
  double t25;
  double t26;
  double t27;
  double t28;
  double t29;
  double t3;
  double t30;
  double t31;
  double t32;
  double t33;
  double t34;
  double t35;
  double t36;
  double t37;
  double t38;
  double t39;
  double t4;
  double t40;
  double t41;
  double t42;
  double t43;
  double t44;
  double t45;
  double t46;
  double t47;
  double t48[2 * 2] = { 0.7886751345948128, 0.21132486540518713, 0.21132486540518713, 0.7886751345948128 };
  double t49[2] = { 0.7886751345948128, 0.21132486540518713 };
  double t5;
  double t50[2] = { 0.21132486540518713, 0.7886751345948128 };
  double t51[2] = { 0.4999999999999999, 0.4999999999999999 };
  double t52;
  double t53;
  double t54;
  double t55;
  double t56;
  double t57;
  double t58[2 * 2];
  double t59[2 * 2];
  double t6;
  double t60[2 * 2];
  double t61;
  double t62;
  double t63;
  double t64;
  double t65;
  double t66;
  double t67;
  double t68;
  double t69;
  double t7;
  double t70;
  double t71;
  double t72;
  double t73;
  double t74;
  double t75;
  double t76;
  double t77[2];
  double t78[2];
  double t79[2];
  double t8;
  double t80;
  double t81;
  double t82;
  double t83;
  double t84;
  double t85;
  double t86;
  double t87[2];
  double t88[2 * 2];
  double t9;

  t0 = -1.0 * coords_0[12];
  t1 = t0 + coords_0[18];
  t2 = -1.0 * coords_0[0];
  t3 = t2 + coords_0[6];
  t4 = -1.0 * coords_0[15] + coords_0[21];
  t5 = -1.0 * coords_0[3];
  t6 = t5 + coords_0[9];
  t7 = -1.0 * coords_0[14];
  t8 = t7 + coords_0[20];
  t9 = -1.0 * coords_0[2];
  t10 = t9 + coords_0[8];
  t11 = -1.0 * coords_0[17] + coords_0[23];
  t12 = -1.0 * coords_0[5];
  t13 = t12 + coords_0[11];
  t14 = -1.0 * coords_0[13];
  t15 = t14 + coords_0[19];
  t16 = -1.0 * coords_0[1];
  t17 = t16 + coords_0[7];
  t18 = -1.0 * coords_0[16] + coords_0[22];
  t19 = -1.0 * coords_0[4];
  t20 = t19 + coords_0[10];
  t21 = t0 + coords_0[15];
  t22 = t2 + coords_0[3];
  t23 = -1.0 * coords_0[18] + coords_0[21];
  t24 = -1.0 * coords_0[6];
  t25 = t24 + coords_0[9];
  t26 = t14 + coords_0[16];
  t27 = t16 + coords_0[4];
  t28 = -1.0 * coords_0[19] + coords_0[22];
  t29 = -1.0 * coords_0[7];
  t30 = t29 + coords_0[10];
  t31 = t7 + coords_0[17];
  t32 = t9 + coords_0[5];
  t33 = -1.0 * coords_0[20] + coords_0[23];
  t34 = -1.0 * coords_0[8];
  t35 = t34 + coords_0[11];
  t36 = t34 + coords_0[20];
  t37 = t9 + coords_0[14];
  t38 = -1.0 * coords_0[11] + coords_0[23];
  t39 = t12 + coords_0[17];
  t40 = t29 + coords_0[19];
  t41 = t16 + coords_0[13];
  t42 = -1.0 * coords_0[10] + coords_0[22];
  t43 = t19 + coords_0[16];
  t44 = t24 + coords_0[18];
  t45 = t2 + coords_0[12];
  t46 = -1.0 * coords_0[9] + coords_0[21];
  t47 = t5 + coords_0[15];
  for (int32_t ip1 = 0; ip1 <= 1; ++ip1)
  {
    t52 = t49[ip1] * t47 + t50[ip1] * t46;
    t53 = t49[ip1] * t45 + t50[ip1] * t44;
    t54 = t49[ip1] * t43 + t50[ip1] * t42;
    t55 = t49[ip1] * t41 + t50[ip1] * t40;
    t56 = t49[ip1] * t39 + t50[ip1] * t38;
    t57 = t49[ip1] * t37 + t50[ip1] * t36;
    for (int32_t ip2 = 0; ip2 <= 1; ++ip2)
    {
      t58[2 * ip1 + ip2] = t49[ip2] * t57 + t50[ip2] * t56;
      t59[2 * ip1 + ip2] = t49[ip2] * t55 + t50[ip2] * t54;
      t60[2 * ip1 + ip2] = t49[ip2] * t53 + t50[ip2] * t52;
    }
  }
  for (int32_t ip0 = 0; ip0 <= 1; ++ip0)
  {
    t61 = t49[ip0] * t35 + t50[ip0] * t33;
    t62 = t49[ip0] * t32 + t50[ip0] * t31;
    t63 = t49[ip0] * t30 + t50[ip0] * t28;
    t64 = t49[ip0] * t27 + t50[ip0] * t26;
    t65 = t49[ip0] * t25 + t50[ip0] * t23;
    t66 = t49[ip0] * t22 + t50[ip0] * t21;
    t67 = t49[ip0] * w_0[2] + t50[ip0] * w_0[6];
    t68 = t49[ip0] * w_0[0] + t50[ip0] * w_0[4];
    t69 = t49[ip0] * w_0[3] + t50[ip0] * w_0[7];
    t70 = t49[ip0] * w_0[1] + t50[ip0] * w_0[5];
    t71 = t49[ip0] * t20 + t50[ip0] * t18;
    t72 = t49[ip0] * t17 + t50[ip0] * t15;
    t73 = t49[ip0] * t13 + t50[ip0] * t11;
    t74 = t49[ip0] * t10 + t50[ip0] * t8;
    t75 = t49[ip0] * t6 + t50[ip0] * t4;
    t76 = t49[ip0] * t3 + t50[ip0] * t1;
    for (int32_t ip2_0 = 0; ip2_0 <= 1; ++ip2_0)
    {
      t77[ip2_0] = -1.0 * (t49[ip2_0] * t76 + t50[ip2_0] * t75);
      t78[ip2_0] = t49[ip2_0] * t74 + t50[ip2_0] * t73;
      t79[ip2_0] = t49[ip2_0] * t72 + t50[ip2_0] * t71;
    }
    for (int32_t j1 = 0; j1 <= 1; ++j1)
      for (int32_t j2 = 0; j2 <= 1; ++j2)
        t88[2 * j1 + j2] = (double) (0.0);
    for (int32_t ip1_0 = 0; ip1_0 <= 1; ++ip1_0)
    {
      t80 = t49[ip1_0] * t70 + t50[ip1_0] * t69;
      t81 = t49[ip1_0] * t68 + t50[ip1_0] * t67;
      t82 = t49[ip1_0] * t66 + t50[ip1_0] * t65;
      t83 = t49[ip1_0] * t64 + t50[ip1_0] * t63;
      t84 = t49[ip1_0] * t62 + t50[ip1_0] * t61;
      t85 = t51[ip0] * t51[ip1_0];
      for (int32_t j2_0 = 0; j2_0 <= 1; ++j2_0)
        t87[j2_0] = (double) (0.0);
      for (int32_t ip2_1 = 0; ip2_1 <= 1; ++ip2_1)
      {
        t86 = t85 * t51[ip2_1] * fabs(t60[2 * ip1_0 + ip2_1] * (t79[ip2_1] * t84 + -1.0 * t83 * t78[ip2_1]) + (t59[2 * ip1_0 + ip2_1] * t84 + -1.0 * t83 * t58[2 * ip1_0 + ip2_1]) * t77[ip2_1] + t82 * (t59[2 * ip1_0 + ip2_1] * t78[ip2_1] + -1.0 * t79[ip2_1] * t58[2 * ip1_0 + ip2_1])) * (t49[ip2_1] * t81 + t50[ip2_1] * t80);
        for (int32_t j2_1 = 0; j2_1 <= 1; ++j2_1)
          t87[j2_1] = t87[j2_1] + t48[ip2_1 + 2 * j2_1] * t86;
      }
      for (int32_t j1_0 = 0; j1_0 <= 1; ++j1_0)
        for (int32_t j2_2 = 0; j2_2 <= 1; ++j2_2)
          t88[2 * j1_0 + j2_2] = t88[2 * j1_0 + j2_2] + t48[ip1_0 + 2 * j1_0] * t87[j2_2];
    }
    for (int32_t j0 = 0; j0 <= 1; ++j0)
      for (int32_t j1_1 = 0; j1_1 <= 1; ++j1_1)
        for (int32_t j2_3 = 0; j2_3 <= 1; ++j2_3)
          A[4 * j0 + 2 * j1_1 + j2_3] = A[4 * j0 + 2 * j1_1 + j2_3] + t48[ip0 + 2 * j0] * t88[2 * j1_1 + j2_3];
  }

}