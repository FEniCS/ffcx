#include <stdint.h>
#include <stdbool.h>
#include <math.h>

void k_cell_integral(double *__restrict__ A, double const *__restrict__ coords_0, double const *__restrict__ w_0)
{
  double t0;
  double t1;
  double t10;
  double t11[2] = { 0.21132486540518713, 0.7886751345948128 };
  double t12;
  double t13[2] = { 0.7886751345948128, 0.21132486540518713 };
  double t14[2];
  double t15[2];
  double t16;
  double t17;
  double t18;
  double t19;
  double t2;
  double t20;
  double t21[2];
  double t3;
  double t4;
  double t5;
  double t6[2 * 2] = { 0.7886751345948128, 0.21132486540518713, 0.21132486540518713, 0.7886751345948128 };
  double t7[2] = { 0.4999999999999999, 0.4999999999999999 };
  double t8;
  double t9;

  t0 = -1.0 * coords_0[5] + coords_0[7];
  t1 = -1.0 * coords_0[1];
  t2 = t1 + coords_0[3];
  t3 = -1.0 * coords_0[4] + coords_0[6];
  t4 = -1.0 * coords_0[0];
  t5 = t4 + coords_0[2];
  t8 = -1.0 * coords_0[2] + coords_0[6];
  t9 = t4 + coords_0[4];
  t10 = -1.0 * coords_0[3] + coords_0[7];
  t12 = t1 + coords_0[5];
  for (int32_t ip1 = 0; ip1 <= 1; ++ip1)
  {
    t14[ip1] = t13[ip1] * t12 + t11[ip1] * t10;
    t15[ip1] = t13[ip1] * t9 + t11[ip1] * t8;
  }
  for (int32_t ip0 = 0; ip0 <= 1; ++ip0)
  {
    t16 = t13[ip0] * w_0[1] + t11[ip0] * w_0[3];
    t17 = t13[ip0] * w_0[0] + t11[ip0] * w_0[2];
    t18 = t13[ip0] * t5 + t11[ip0] * t3;
    t19 = t13[ip0] * t2 + t11[ip0] * t0;
    for (int32_t j1 = 0; j1 <= 1; ++j1)
      t21[j1] = (double) (0.0);
    for (int32_t ip1_0 = 0; ip1_0 <= 1; ++ip1_0)
    {
      t20 = t7[ip0] * t7[ip1_0] * fabs(t15[ip1_0] * t19 + -1.0 * t18 * t14[ip1_0]) * (t13[ip1_0] * t17 + t11[ip1_0] * t16);
      for (int32_t j1_0 = 0; j1_0 <= 1; ++j1_0)
        t21[j1_0] = t21[j1_0] + t6[ip1_0 + 2 * j1_0] * t20;
    }
    for (int32_t j0 = 0; j0 <= 1; ++j0)
      for (int32_t j1_1 = 0; j1_1 <= 1; ++j1_1)
        A[2 * j0 + j1_1] = A[2 * j0 + j1_1] + t6[ip0 + 2 * j0] * t21[j1_1];
  }

}