#include <stdint.h>
#include <stdbool.h>
#include <math.h>

void k_cell_integral(double *__restrict__ A, double const *__restrict__ coords_0, double const *__restrict__ w_0)
{
  double t0;
  double t1;
  double t10;
  double t11;
  double t12;
  double t13;
  double t14;
  double t15[2] = { 0.21132486540518713, 0.7886751345948128 };
  double t16;
  double t17[2] = { 0.7886751345948128, 0.21132486540518713 };
  double t18[2];
  double t19[2];
  double t2;
  double t20[2];
  double t21[2];
  double t22;
  double t23;
  double t24;
  double t25;
  double t26;
  double t27[2 * 2];
  double t28;
  double t29;
  double t3;
  double t30[2 * 2];
  double t31[2 * 2];
  double t32;
  double t33[2 * 2];
  double t34[2 * 2];
  double t35[2];
  double t36[2] = { -1.0, 1.0 };
  double t37[2 * 2] = { 0.7886751345948128, 0.21132486540518713, 0.21132486540518713, 0.7886751345948128 };
  double t38[2];
  double t39;
  double t4;
  double t40[2];
  double t5;
  double t6;
  double t7;
  double t8;
  double t9[2] = { 0.4999999999999999, 0.4999999999999999 };

  t0 = -1.0 * coords_0[5] + coords_0[7];
  t1 = -1.0 * coords_0[1];
  t2 = t1 + coords_0[3];
  t3 = -1.0 * w_0[2] + w_0[3];
  t4 = -1.0 * w_0[0];
  t5 = t4 + w_0[1];
  t6 = -1.0 * coords_0[4] + coords_0[6];
  t7 = -1.0 * coords_0[0];
  t8 = t7 + coords_0[2];
  t10 = -1.0 * coords_0[2] + coords_0[6];
  t11 = t7 + coords_0[4];
  t12 = -1.0 * w_0[1] + w_0[3];
  t13 = t4 + w_0[2];
  t14 = -1.0 * coords_0[3] + coords_0[7];
  t16 = t1 + coords_0[5];
  for (int32_t ip1 = 0; ip1 <= 1; ++ip1)
  {
    t35[ip1] = (double) (0.0);
    t18[ip1] = t17[ip1] * t16 + t15[ip1] * t14;
    t19[ip1] = -1.0 * t18[ip1];
    t20[ip1] = t17[ip1] * t13 + t15[ip1] * t12;
    t21[ip1] = t17[ip1] * t11 + t15[ip1] * t10;
  }
  for (int32_t ip0 = 0; ip0 <= 1; ++ip0)
  {
    t22 = t17[ip0] * t8 + t15[ip0] * t6;
    t23 = -1.0 * t22;
    t24 = t17[ip0] * t5 + t15[ip0] * t3;
    t25 = t17[ip0] * t2 + t15[ip0] * t0;
    for (int32_t ip1_0 = 0; ip1_0 <= 1; ++ip1_0)
    {
      t26 = t21[ip1_0] * t25 + -1.0 * t22 * t18[ip1_0];
      t27[2 * ip0 + ip1_0] = t9[ip0] * t9[ip1_0] * fabs(t26);
      t28 = 1.0 / t26;
      t29 = t25 * t28;
      t30[2 * ip0 + ip1_0] = t19[ip1_0] * t28;
      t31[2 * ip0 + ip1_0] = t29 * t20[ip1_0] + t30[2 * ip0 + ip1_0] * t24;
      t32 = t23 * t28;
      t33[2 * ip0 + ip1_0] = t21[ip1_0] * t28;
      t34[2 * ip0 + ip1_0] = t32 * t20[ip1_0] + t33[2 * ip0 + ip1_0] * t24;
      t35[ip1_0] = t35[ip1_0] + t27[2 * ip0 + ip1_0] * (t31[2 * ip0 + ip1_0] * t29 + t34[2 * ip0 + ip1_0] * t32);
    }
  }
  for (int32_t j1 = 0; j1 <= 1; ++j1)
    t38[j1] = (double) (0.0);
  for (int32_t j0 = 0; j0 <= 1; ++j0)
    t40[j0] = (double) (0.0);
  for (int32_t ip1_1 = 0; ip1_1 <= 1; ++ip1_1)
    for (int32_t j1_0 = 0; j1_0 <= 1; ++j1_0)
      t38[j1_0] = t38[j1_0] + t37[ip1_1 + 2 * j1_0] * t35[ip1_1];
  for (int32_t ip0_0 = 0; ip0_0 <= 1; ++ip0_0)
  {
    t39 = (double) (0.0);
    for (int32_t ip1_2 = 0; ip1_2 <= 1; ++ip1_2)
      t39 = t39 + t27[2 * ip0_0 + ip1_2] * (t31[2 * ip0_0 + ip1_2] * t30[2 * ip0_0 + ip1_2] + t34[2 * ip0_0 + ip1_2] * t33[2 * ip0_0 + ip1_2]);
    for (int32_t j0_0 = 0; j0_0 <= 1; ++j0_0)
      t40[j0_0] = t40[j0_0] + t37[ip0_0 + 2 * j0_0] * t39;
  }
  for (int32_t j0_1 = 0; j0_1 <= 1; ++j0_1)
    for (int32_t j1_1 = 0; j1_1 <= 1; ++j1_1)
      A[2 * j0_1 + j1_1] = A[2 * j0_1 + j1_1] + t36[j0_1] * t38[j1_1] + t36[j1_1] * t40[j0_1];

}