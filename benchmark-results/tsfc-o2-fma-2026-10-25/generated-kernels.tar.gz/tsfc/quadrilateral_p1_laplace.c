#include <stdint.h>
#include <stdbool.h>
#include <math.h>

void k_cell_integral(double *__restrict__ A, double const *__restrict__ coords_0)
{
  double t0;
  double t1;
  double t10[2] = { 0.21132486540518713, 0.7886751345948128 };
  double t11;
  double t12[2] = { 0.7886751345948128, 0.21132486540518713 };
  double t13[2];
  double t14[2];
  double t15;
  double t16;
  double t17;
  double t18;
  double t19[2 * 2];
  double t2;
  double t20[2 * 2];
  double t21[2 * 2];
  double t22[2 * 2];
  double t23[2];
  double t24[2] = { -1.0, 1.0 };
  double t25[2 * 2] = { 0.7886751345948128, 0.21132486540518713, 0.21132486540518713, 0.7886751345948128 };
  double t26[2];
  double t27;
  double t28[2 * 2];
  double t29;
  double t3;
  double t30;
  double t31;
  double t32;
  double t33;
  double t34[2];
  double t35[2];
  double t36[2 * 2];
  double t37;
  double t38[2 * 2];
  double t39[2 * 2];
  double t4;
  double t40[2 * 2 * 2];
  double t41[2 * 2];
  double t5;
  double t6[2] = { 0.4999999999999999, 0.4999999999999999 };
  double t7;
  double t8;
  double t9;

  t0 = -1.0 * coords_0[5] + coords_0[7];
  t1 = -1.0 * coords_0[1];
  t2 = t1 + coords_0[3];
  t3 = -1.0 * coords_0[4] + coords_0[6];
  t4 = -1.0 * coords_0[0];
  t5 = t4 + coords_0[2];
  t7 = -1.0 * coords_0[2] + coords_0[6];
  t8 = t4 + coords_0[4];
  t9 = -1.0 * coords_0[3] + coords_0[7];
  t11 = t1 + coords_0[5];
  for (int32_t ip1 = 0; ip1 <= 1; ++ip1)
  {
    t23[ip1] = (double) (0.0);
    t13[ip1] = t12[ip1] * t11 + t10[ip1] * t9;
    t14[ip1] = t12[ip1] * t8 + t10[ip1] * t7;
  }
  for (int32_t ip0 = 0; ip0 <= 1; ++ip0)
  {
    t15 = t12[ip0] * t5 + t10[ip0] * t3;
    t16 = -1.0 * t15;
    t17 = t12[ip0] * t2 + t10[ip0] * t0;
    for (int32_t ip1_0 = 0; ip1_0 <= 1; ++ip1_0)
    {
      t18 = t14[ip1_0] * t17 + -1.0 * t15 * t13[ip1_0];
      t19[2 * ip0 + ip1_0] = t6[ip0] * t6[ip1_0] * fabs(t18);
      t20[2 * ip0 + ip1_0] = 1.0 / t18;
      t21[2 * ip0 + ip1_0] = t17 * t20[2 * ip0 + ip1_0];
      t22[2 * ip0 + ip1_0] = t16 * t20[2 * ip0 + ip1_0];
      t23[ip1_0] = t23[ip1_0] + t19[2 * ip0 + ip1_0] * (t21[2 * ip0 + ip1_0] * t21[2 * ip0 + ip1_0] + t22[2 * ip0 + ip1_0] * t22[2 * ip0 + ip1_0]);
    }
  }
  for (int32_t j1 = 0; j1 <= 1; ++j1)
  {
    for (int32_t k1 = 0; k1 <= 1; ++k1)
      t28[2 * j1 + k1] = (double) (0.0);
    for (int32_t k0 = 0; k0 <= 1; ++k0)
      t36[2 * j1 + k0] = (double) (0.0);
  }
  for (int32_t j0 = 0; j0 <= 1; ++j0)
  {
    for (int32_t k1_0 = 0; k1_0 <= 1; ++k1_0)
      t38[2 * j0 + k1_0] = (double) (0.0);
    for (int32_t k0_0 = 0; k0_0 <= 1; ++k0_0)
      t39[2 * j0 + k0_0] = (double) (0.0);
  }
  for (int32_t ip1_1 = 0; ip1_1 <= 1; ++ip1_1)
  {
    t26[ip1_1] = -1.0 * t13[ip1_1];
    for (int32_t j1_0 = 0; j1_0 <= 1; ++j1_0)
    {
      t27 = t25[ip1_1 + 2 * j1_0] * t23[ip1_1];
      for (int32_t k1_1 = 0; k1_1 <= 1; ++k1_1)
        t28[2 * j1_0 + k1_1] = t28[2 * j1_0 + k1_1] + t25[ip1_1 + 2 * k1_1] * t27;
    }
  }
  for (int32_t ip0_0 = 0; ip0_0 <= 1; ++ip0_0)
  {
    t31 = (double) (0.0);
    for (int32_t k1_2 = 0; k1_2 <= 1; ++k1_2)
      t34[k1_2] = (double) (0.0);
    for (int32_t j1_1 = 0; j1_1 <= 1; ++j1_1)
      t35[j1_1] = (double) (0.0);
    for (int32_t ip1_2 = 0; ip1_2 <= 1; ++ip1_2)
    {
      t29 = t26[ip1_2] * t20[2 * ip0_0 + ip1_2];
      t30 = t14[ip1_2] * t20[2 * ip0_0 + ip1_2];
      t31 = t31 + t19[2 * ip0_0 + ip1_2] * (t29 * t29 + t30 * t30);
      t32 = t19[2 * ip0_0 + ip1_2] * (t29 * t21[2 * ip0_0 + ip1_2] + t30 * t22[2 * ip0_0 + ip1_2]);
      t33 = t19[2 * ip0_0 + ip1_2] * (t21[2 * ip0_0 + ip1_2] * t29 + t22[2 * ip0_0 + ip1_2] * t30);
      for (int32_t k1_3 = 0; k1_3 <= 1; ++k1_3)
        t34[k1_3] = t34[k1_3] + t25[ip1_2 + 2 * k1_3] * t33;
      for (int32_t j1_2 = 0; j1_2 <= 1; ++j1_2)
        t35[j1_2] = t35[j1_2] + t25[ip1_2 + 2 * j1_2] * t32;
    }
    for (int32_t j1_3 = 0; j1_3 <= 1; ++j1_3)
      for (int32_t k0_1 = 0; k0_1 <= 1; ++k0_1)
        t36[2 * j1_3 + k0_1] = t36[2 * j1_3 + k0_1] + t25[ip0_0 + 2 * k0_1] * t35[j1_3];
    for (int32_t j0_0 = 0; j0_0 <= 1; ++j0_0)
    {
      t37 = t25[ip0_0 + 2 * j0_0] * t31;
      for (int32_t k1_4 = 0; k1_4 <= 1; ++k1_4)
        t38[2 * j0_0 + k1_4] = t38[2 * j0_0 + k1_4] + t25[ip0_0 + 2 * j0_0] * t34[k1_4];
      for (int32_t k0_2 = 0; k0_2 <= 1; ++k0_2)
        t39[2 * j0_0 + k0_2] = t39[2 * j0_0 + k0_2] + t25[ip0_0 + 2 * k0_2] * t37;
    }
  }
  for (int32_t j1_4 = 0; j1_4 <= 1; ++j1_4)
    for (int32_t k0_3 = 0; k0_3 <= 1; ++k0_3)
      for (int32_t k1_5 = 0; k1_5 <= 1; ++k1_5)
        t40[4 * j1_4 + 2 * k0_3 + k1_5] = t24[k0_3] * t28[2 * j1_4 + k1_5] + t24[k1_5] * t36[2 * j1_4 + k0_3];
  for (int32_t j0_1 = 0; j0_1 <= 1; ++j0_1)
  {
    for (int32_t k0_4 = 0; k0_4 <= 1; ++k0_4)
      for (int32_t k1_6 = 0; k1_6 <= 1; ++k1_6)
        t41[2 * k0_4 + k1_6] = t24[k0_4] * t38[2 * j0_1 + k1_6] + t24[k1_6] * t39[2 * j0_1 + k0_4];
    for (int32_t j1_5 = 0; j1_5 <= 1; ++j1_5)
      for (int32_t k0_5 = 0; k0_5 <= 1; ++k0_5)
        for (int32_t k1_7 = 0; k1_7 <= 1; ++k1_7)
          A[8 * j0_1 + 4 * j1_5 + 2 * k0_5 + k1_7] = A[8 * j0_1 + 4 * j1_5 + 2 * k0_5 + k1_7] + t40[4 * j1_5 + 2 * k0_5 + k1_7] * t24[j0_1] + t41[2 * k0_5 + k1_7] * t24[j1_5];
  }

}